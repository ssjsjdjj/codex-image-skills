﻿[CmdletBinding()]
param(
    [string]$PythonPath,
    [string]$InstallRoot,
    [string]$RuntimeRoot,
    [string]$ModelPath,
    [string]$Wheelhouse,
    [switch]$ReusePython,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
# Codex may pass PowerShell 7 module search paths to Windows PowerShell 5.1.
# Import built-ins from this interpreter, without changing global PSModulePath.
foreach ($ModuleName in @('Microsoft.PowerShell.Utility','Microsoft.PowerShell.Management','Microsoft.PowerShell.Host')) {
    Import-Module (Join-Path $PSHOME ('Modules\'+$ModuleName+'\'+$ModuleName+'.psd1')) -Force
}
$PackageRoot = $PSScriptRoot
$SkillName = 'chutu-baidi-touming-v2'
$ModelMD5 = '60024c5c889badc19c04ad937298a77b'
$ModelURL = 'https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net.onnx'
function Assert-ChildPath([string]$Path, [string]$Root) {
    $FullPath = [IO.Path]::GetFullPath($Path)
    $Boundary = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    if (-not $FullPath.StartsWith($Boundary, [StringComparison]::OrdinalIgnoreCase)) { throw "Path outside selected root: $FullPath" }
}
function Write-Json($Path, $Value) {
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 12), (New-Object Text.UTF8Encoding($false)))
}
function Invoke-Python([string]$Exe, [string[]]$Arguments) {
    & $Exe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Python command failed (exit $LASTEXITCODE): $($Arguments[0])" }
}
function Assert-Python([string]$Exe) {
    if (-not (Test-Path -LiteralPath $Exe -PathType Leaf)) { throw "Python not found: $Exe" }
    $Output = & $Exe -c "import sys,struct; assert sys.version_info[:2]==(3,12) and struct.calcsize('P')==8; print(sys.executable)" 2>$null
    if ($LASTEXITCODE -ne 0) { throw 'A 64-bit Python 3.12 interpreter is required.' }
    return [IO.Path]::GetFullPath(([string]($Output | Select-Object -Last 1)).Trim())
}
function Find-Python {
    if ($PythonPath) { return (Assert-Python $PythonPath) }
    $Candidates = @()
    $RuntimeSearch = Join-Path $env:USERPROFILE '.cache\codex-runtimes'
    if (Test-Path -LiteralPath $RuntimeSearch) {
        foreach ($Item in Get-ChildItem -LiteralPath $RuntimeSearch -Directory) {
            $Candidates += Join-Path $Item.FullName 'dependencies\python\python.exe'
        }
    }
    $Py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($Py) {
        $Found = & $Py.Source -3.12 -c 'import sys; print(sys.executable)' 2>$null
        if ($LASTEXITCODE -eq 0) { $Candidates += [string]($Found | Select-Object -Last 1) }
    }
    $PythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($PythonCommand -and $PythonCommand.Source -notmatch 'WindowsApps') { $Candidates += $PythonCommand.Source }
    foreach ($Candidate in $Candidates) {
        try { return (Assert-Python $Candidate) } catch { }
    }
    throw 'Python 3.12 x64 was not found. Ask Codex to locate its bundled Python via load_workspace_dependencies, then pass -PythonPath. No system Python is changed.'
}
if (-not $InstallRoot) {
    $CodexDirectory = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
    $InstallRoot = Join-Path $CodexDirectory 'skills'
}
if (-not $RuntimeRoot) { $RuntimeRoot = Join-Path $env:LOCALAPPDATA 'ChutuBaidiToumingV2' }
$InstallRoot = [IO.Path]::GetFullPath($InstallRoot)
$RuntimeRoot = [IO.Path]::GetFullPath($RuntimeRoot)
$Target = Join-Path $InstallRoot $SkillName
$Manifest = Get-Content -LiteralPath (Join-Path $PackageRoot 'package-manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$SkillVersion = [string]$Manifest.version
foreach ($File in $Manifest.files) {
    $Source = [IO.Path]::GetFullPath((Join-Path $PackageRoot $File.path))
    if (-not $Source.StartsWith($PackageRoot.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe manifest path.' }
    if (-not (Test-Path -LiteralPath $Source -PathType Leaf)) { throw "Missing package file: $($File.path)" }
    if ((Get-Item -LiteralPath $Source).Length -ne $File.bytes) { throw "Package size mismatch: $($File.path)" }
    if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne $File.sha256) { throw "Package hash mismatch: $($File.path)" }
}
$ListedFiles = @($Manifest.files | ForEach-Object { $_.path.Replace('/','\').ToLowerInvariant() })
$ActualFiles = @(Get-ChildItem -LiteralPath $PackageRoot -File -Recurse | ForEach-Object {
    $_.FullName.Substring($PackageRoot.TrimEnd('\').Length+1).ToLowerInvariant()
} | Where-Object { $_ -ne 'package-manifest.json' })
if (@(Compare-Object $ListedFiles $ActualFiles).Count) { throw 'Package files differ from the manifest.' }
Assert-ChildPath $Target $InstallRoot
$BasePython = Find-Python
if (Test-Path -LiteralPath $Target) {
    if ((Get-Item -LiteralPath $Target).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Skill target is a link; select a normal install directory.' }
}
if ($ModelPath) {
    $ModelPath = (Resolve-Path -LiteralPath $ModelPath).Path
    if ((Get-FileHash -LiteralPath $ModelPath -Algorithm MD5).Hash -ne $ModelMD5) { throw 'Supplied model checksum mismatch.' }
}
if ($Wheelhouse) { $Wheelhouse = (Resolve-Path -LiteralPath $Wheelhouse).Path }
if ($DryRun) {
    [ordered]@{dry_run=$true;package_verified=$true;incoming_version=$SkillVersion;python=$BasePython;target=$Target;runtime=$RuntimeRoot;reuse_python=[bool]$ReusePython;model_url=$ModelURL;model_md5=$ModelMD5;existing_skill_will_be_backed_up=(Test-Path -LiteralPath $Target)} | ConvertTo-Json
    exit 0
}
$RunID = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8)
$RunDirectory = Join-Path $RuntimeRoot ('installs\' + $RunID)
New-Item -ItemType Directory -Path $RunDirectory -Force | Out-Null
$TranscriptStarted = $false
$Backup = $null
$Published = $false
$SavedEnv = @{}
foreach ($Name in @('PYTHONUTF8','PYTHONIOENCODING','PYTHONDONTWRITEBYTECODE','NUMBA_DISABLE_JIT','OMP_NUM_THREADS','U2NET_HOME','PIP_DISABLE_PIP_VERSION_CHECK')) {
    $SavedEnv[$Name] = [Environment]::GetEnvironmentVariable($Name, 'Process')
}
try {
    Start-Transcript -Path (Join-Path $RunDirectory 'install.log') | Out-Null
    $TranscriptStarted = $true
    $env:PYTHONUTF8='1'; $env:PYTHONIOENCODING='utf-8'; $env:PYTHONDONTWRITEBYTECODE='1'
    $env:NUMBA_DISABLE_JIT='1'; $env:OMP_NUM_THREADS='2'; $env:PIP_DISABLE_PIP_VERSION_CHECK='1'
    if ($ReusePython) {
        $RuntimePython = $BasePython
        Write-Host 'Reusing the explicitly selected environment; validating all pinned dependencies.'
    } else {
        $VenvDirectory = Join-Path $RunDirectory 'venv'
        Invoke-Python $BasePython @('-m','venv',$VenvDirectory)
        $RuntimePython = Join-Path $VenvDirectory 'Scripts\python.exe'
        $PipArgs = @('-m','pip','install','--only-binary=:all:','-r',(Join-Path $PackageRoot 'requirements.lock.txt'))
        if ($Wheelhouse) { $PipArgs += @('--no-index','--find-links',$Wheelhouse) }
        Invoke-Python $RuntimePython $PipArgs
    }
    $Probe = @'
import importlib.metadata as m, pathlib, sys
for line in pathlib.Path(sys.argv[1]).read_text(encoding='utf-8-sig').splitlines():
    if not line.strip() or line.startswith('#'): continue
    name, version = line.strip().split('==')
    assert m.version(name)==version, f'{name}: expected {version}, got {m.version(name)}'
import numpy, PIL, scipy, cv2, onnxruntime, rembg, psd_tools, yaml
assert 'CPUExecutionProvider' in onnxruntime.get_available_providers()
print('Dependency versions and CPU provider: PASS')
'@
    Invoke-Python $RuntimePython @('-c',$Probe,(Join-Path $PackageRoot 'requirements.lock.txt'))
    Invoke-Python $RuntimePython @('-m','pip','check')
    $ModelDirectory = Join-Path $RuntimeRoot 'models'
    New-Item -ItemType Directory -Path $ModelDirectory -Force | Out-Null
    $InstalledModel = Join-Path $ModelDirectory 'u2net.onnx'
    if (Test-Path -LiteralPath $InstalledModel) {
        if ((Get-FileHash -LiteralPath $InstalledModel -Algorithm MD5).Hash -ne $ModelMD5) { throw "Existing model is invalid; preserved at $InstalledModel. Select a new -RuntimeRoot or supply a valid model after resolving it." }
    } else {
        $PendingModel = Join-Path $RunDirectory 'u2net.onnx.download'
        if ($ModelPath) { Copy-Item -LiteralPath $ModelPath -Destination $PendingModel }
        else {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $ModelURL -OutFile $PendingModel -UseBasicParsing
        }
        if ((Get-FileHash -LiteralPath $PendingModel -Algorithm MD5).Hash -ne $ModelMD5) { throw 'Downloaded model checksum mismatch; installation stopped.' }
        Move-Item -LiteralPath $PendingModel -Destination $InstalledModel
    }
    $StageSkill = Join-Path $RunDirectory $SkillName
    Copy-Item -LiteralPath (Join-Path $PackageRoot ('skill\'+$SkillName)) -Destination $StageSkill -Recurse
    $CacheDirectory = Join-Path $RuntimeRoot 'cache'
    New-Item -ItemType Directory -Path $CacheDirectory -Force | Out-Null
    Write-Json (Join-Path $StageSkill 'runtime.json') ([ordered]@{schema=1;installed_at=(Get-Date -Format o);python=$RuntimePython;cache_dir=$CacheDirectory;cpu_threads=2;model='u2net';model_dir=$ModelDirectory;disable_numba_jit=$true;skill_version=$SkillVersion})
    $env:U2NET_HOME=$ModelDirectory
    $ValidateMetadata = @'
from pathlib import Path
import sys, yaml
meta = yaml.safe_load((Path(sys.argv[1])/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1])
assert meta['name']=='chutu-baidi-touming-v2'
assert meta['metadata']['version']==sys.argv[2], 'Package/skill version mismatch'
'@
    Invoke-Python $RuntimePython @('-c',$ValidateMetadata,$StageSkill,$SkillVersion)
    $TestDirectory = Join-Path $RunDirectory 'selftest'
    Invoke-Python $RuntimePython @((Join-Path $StageSkill 'scripts\selftest.py'),'--skill',$StageSkill,'--work',$TestDirectory)
    $Report = Get-Content -LiteralPath (Join-Path $TestDirectory 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $Report.passed -or -not $Report.model_inference) { throw 'Selftest or local model inference failed.' }
    $CompressionTestDirectory = Join-Path $RunDirectory 'compression-selftest'
    Invoke-Python $RuntimePython @((Join-Path $StageSkill 'scripts\selftest_image_size.py'),'--work',$CompressionTestDirectory)
    $CompressionReport = Get-Content -LiteralPath (Join-Path $CompressionTestDirectory 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $CompressionReport.passed -or @($CompressionReport.checks | Where-Object { -not $_.passed }).Count) { throw 'Automatic compression selftest failed.' }
    $QueueTestDirectory = Join-Path $RunDirectory 'queue-selftest'
    Invoke-Python $RuntimePython @((Join-Path $StageSkill 'scripts\selftest_ps_queue.py'),'--work',$QueueTestDirectory)
    $QueueReport = Get-Content -LiteralPath (Join-Path $QueueTestDirectory 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not $QueueReport.passed -or $QueueReport.failed_checks -ne 0 -or $QueueReport.passed_checks -ne $QueueReport.checks -or $QueueReport.actual_photoshop_invoked -or $QueueReport.global_queue_used) { throw 'Isolated PS queue selftest failed.' }
    $HDTestDirectory = $null
    $HDChecks = 0
    if (Test-Path -LiteralPath (Join-Path $StageSkill 'scripts\selftest_hd_masks.py')) {
        $HDTestDirectory = Join-Path $RunDirectory 'hd-mask-selftest'
        Invoke-Python $RuntimePython @((Join-Path $StageSkill 'scripts\selftest_hd_masks.py'),'--skill',$StageSkill,'--work',$HDTestDirectory)
        $HDReport = Get-Content -LiteralPath (Join-Path $HDTestDirectory 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $HDReport.passed -or @($HDReport.checks | Where-Object { -not $_.passed }).Count) { throw 'High-resolution mask selftest failed.' }
        $HDChecks = @($HDReport.checks).Count
    }
    New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
    if (Test-Path -LiteralPath $Target) {
        $Backup = Join-Path $RunDirectory 'previous-skill'
        Assert-ChildPath $Target $InstallRoot
        Assert-ChildPath $Backup $RuntimeRoot
        Move-Item -LiteralPath $Target -Destination $Backup
    }
    Assert-ChildPath $StageSkill $RuntimeRoot
    Assert-ChildPath $Target $InstallRoot
    Move-Item -LiteralPath $StageSkill -Destination $Target
    $Published = $true
    Invoke-Python $RuntimePython @((Join-Path $Target 'scripts\launch.py'),'-h','--journal-root',(Join-Path $RunDirectory 'smoke-timing'))
    Write-Json (Join-Path $RunDirectory 'result.json') ([ordered]@{success=$true;package_version=$SkillVersion;queue_checks=$QueueReport.passed_checks;queue_selftest=(Join-Path $QueueTestDirectory 'report.json');hd_mask_checks=$HDChecks;hd_mask_selftest=$(if ($HDTestDirectory) { Join-Path $HDTestDirectory 'report.json' });max_image_bytes=500000;compression_checks=@($CompressionReport.checks).Count;compression_selftest=(Join-Path $CompressionTestDirectory 'report.json');skill=$Target;python=$RuntimePython;model=$InstalledModel;model_md5=$ModelMD5;passed_checks=$Report.passed_checks;total_checks=$Report.total_checks;model_inference=$Report.model_inference;backup=$Backup;selftest=(Join-Path $TestDirectory 'report.json')})
    Write-Host "INSTALL PASS: $Target"
    Write-Host "Checks: $($Report.passed_checks)/$($Report.total_checks); compression: $(@($CompressionReport.checks).Count), queue: $($QueueReport.passed_checks), HD masks: $HDChecks passed. Logs: $RunDirectory"
} catch {
    $Failure = $_
    if ($Published -and (Test-Path -LiteralPath $Target)) {
        $FailedSkill = Join-Path $RunDirectory 'failed-skill'
        Assert-ChildPath $Target $InstallRoot
        Assert-ChildPath $FailedSkill $RuntimeRoot
        Move-Item -LiteralPath $Target -Destination $FailedSkill
    }
    if ($Backup -and (Test-Path -LiteralPath $Backup) -and -not (Test-Path -LiteralPath $Target)) {
        Assert-ChildPath $Backup $RuntimeRoot
        Assert-ChildPath $Target $InstallRoot
        Move-Item -LiteralPath $Backup -Destination $Target
    }
    Write-Json (Join-Path $RunDirectory 'failure.json') ([ordered]@{success=$false;error=[string]$Failure;artifacts=$RunDirectory})
    throw $Failure
} finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
    foreach ($Name in $SavedEnv.Keys) { [Environment]::SetEnvironmentVariable($Name,$SavedEnv[$Name],'Process') }
}
