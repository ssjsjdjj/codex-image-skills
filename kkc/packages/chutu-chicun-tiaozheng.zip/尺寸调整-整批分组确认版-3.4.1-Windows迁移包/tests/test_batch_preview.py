"""Isolated, real batch galleries and human confirmation; no real profile."""
import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

PACKAGE=Path(os.environ.get('RESIZE_TEST_SKILL',Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng'))
sys.path.insert(0,str(PACKAGE/'scripts'))
import user_profile as profile
from review_queue import ReviewQueue
from test_workflow import snapshot_at
from validate_candidate import load_engine,validate_snapshot


class BatchPreviewTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture=tempfile.TemporaryDirectory(prefix='batch-preview-seed-')
        cls.seed=snapshot_at(Path(cls.fixture.name)/'snapshot')
        cls.validation=validate_snapshot(cls.seed,Path(cls.fixture.name)/'validation')
        assert cls.validation['passed'],cls.validation

    @classmethod
    def tearDownClass(cls):cls.fixture.cleanup()

    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='batch-preview-');self.root=Path(self.temp.name).resolve()
        self.store=profile.Store(self.root/'state');self.revision=self.store.initialize(self.seed,'隔离测试人工初始批准',self.validation)
        self.engine=load_engine(self.seed);self.engine.native_cache_root=self.store.root/'native-cache'
        self.queue=ReviewQueue(self.store,self.engine);self.output=self.root/'output'
        self.sources=[]
        for number in range(1,6):
            path=self.root/f'source-{number}.png';Image.new('RGB',(128,160),(30*number,70,170)).save(path);self.sources.append(path)
        self.hashes={str(path):profile.file_hash(path) for path in self.sources}

    def tearDown(self):self.temp.cleanup()

    def task(self,sizes=('40x40','60x60','50x70'),paths=None):
        spec=self.root/'jobs.json'
        profile.write_json(spec,{'delivery':{'kind':'scene','style_id':'BATCH','out_dir':str(self.output),
                                            'sizes':list(sizes),'naming':'style_size_index','format':'jpg'},
                                 'product_focus':{'category':'隔离样例'},
                                 'jobs':[{'input':str(path)} for path in (self.sources if paths is None else paths)]})
        result=self.queue.start(spec);self.assertIn('review-preview-all',result['next']);return result['review_id']

    def assert_sources_unchanged(self):
        self.assertEqual({path:profile.file_hash(path) for path in self.hashes},self.hashes)

    def test_five_sources_three_sizes_all_fifteen_grouped_without_confirmation(self):
        rid=self.task()
        with patch.object(self.engine,'_render',wraps=self.engine._render) as render:result=self.queue.preview_all(rid)
        self.assertEqual(render.call_count,15);self.assertFalse(result['requires_backend_choice']);self.assertFalse(result['ready'])
        self.assertEqual([group['size'] for group in result['groups']],['40x40','60x60','50x70'])
        positions=[]
        for group in result['groups']:
            self.assertEqual([row['number'] for row in group['items']],[1,2,3,4,5])
            self.assertEqual([Path(row['preview']).name for row in group['items']],['1.jpg','2.jpg','3.jpg','4.jpg','5.jpg'])
            self.assertEqual(len({Path(row['preview']).parent for row in group['items']}),1)
            self.assertEqual(Path(group['items'][0]['preview']).parent.name,group['size'])
            self.assertEqual(len(group['contact_sheets']),1)
            for row in group['items']:
                with Image.open(row['preview']) as opened:self.assertEqual(opened.size,tuple(map(int,group['size'].split('x'))))
                self.assertEqual(row['preview_kind'],'target')
            positions.extend(row['index'] for row in group['items'])
        self.assertEqual(sorted(positions),list(range(1,16)))
        record=self.queue.load(rid);self.assertEqual(record['review_mode'],'batch')
        self.assertTrue(all(item['status']=='previewed' for item in record['items']))
        self.assertTrue(all(item['preview_kind']=='target' and item['preview_only'] is True for item in record['items']))
        self.assertNotIn('batch_confirmation',record)
        self.assertEqual(record['batch_preview']['digest'],result['batch_digest'])
        self.assertTrue(Path(result['manifest']).resolve().is_relative_to(self.output/'预览'/rid))
        self.assertFalse((self.output/'图片').exists());self.assertFalse((self.output/'源文件').exists())
        with self.assertRaises(ValueError):self.queue.ready(rid)
        self.assert_sources_unchanged()

    def test_all_risks_aggregated_before_any_render_cache_or_gallery(self):
        rid=self.task(('180x180','200x200','160x240'))
        with patch.object(self.engine,'_render',side_effect=AssertionError('preflight cannot render')) as render:
            result=self.queue.preview_all(rid)
        render.assert_not_called();self.assertTrue(result['requires_backend_choice']);self.assertEqual(len(result['risks']),15)
        self.assertEqual(len(result['groups']),3);self.assertTrue(all(len(group['risks'])==5 for group in result['groups']))
        self.assertFalse(self.output.exists());self.assertFalse(self.engine.native_cache_root.exists())
        self.assertTrue(all(item['status']=='awaiting_backend_choice' and item['attempts']==[] for item in self.queue.load(rid)['items']))
        self.assert_sources_unchanged()

    def test_safe_candidates_also_wait_and_arbitrary_backend_indices_bind_scope(self):
        rid=self.task(('40x40','180x180','50x70'))
        with patch.object(self.engine,'_render',side_effect=AssertionError('safe rows must wait too')):result=self.queue.preview_all(rid)
        indices=[row['index'] for row in result['risks']]
        expected=[index for index,item in enumerate(self.queue.load(rid)['items'],1) if item['job']['size']=='180x180']
        self.assertEqual(indices,expected);self.assertEqual(len(indices),5)
        selection=self.queue.select_backend(rid,'python','本批这些放大项选Python，接受风险',indices=indices)
        self.assertEqual(selection['indices'],indices)
        record=self.queue.load(rid)
        self.assertEqual([index for index,item in enumerate(record['items'],1) if item['job'].get('_backend_choice')],indices)
        self.assertEqual({choice['scope']['size'] for choice in selection['choices']},{'180x180'})
        with patch.object(self.engine,'_render',wraps=self.engine._render) as render:result=self.queue.preview_all(rid)
        self.assertEqual(render.call_count,15);self.assertFalse(result['requires_backend_choice'])
        self.assertTrue(all(item['status']=='previewed' for item in self.queue.load(rid)['items']))

    def test_partial_choices_do_not_partially_render(self):
        rid=self.task(('180x180','200x200','160x240'));self.queue.preview_all(rid)
        self.queue.select_backend(rid,'python','只同意第2第5候选',indices=[2,5])
        with patch.object(self.engine,'_render',side_effect=AssertionError('remaining risks prohibit all pixels')):
            result=self.queue.preview_all(rid)
        self.assertEqual(len(result['risks']),13);self.assertFalse(self.output.exists())
        for indices in ([],[0],[16],[1,1],[True]):
            with self.assertRaises(ValueError):self.queue.select_backend(rid,'python','范围非法',indices=indices)

    def test_one_human_confirmation_marks_all_ready_but_not_delivered(self):
        rid=self.task();preview=self.queue.preview_all(rid);text='已查看3个尺寸全部15张总览，这批集中确认。\n保持这些版本。'
        result=self.queue.confirm_all(rid,preview['batch_digest'],text)
        self.assertTrue(result['ready']);record=self.queue.ready(rid)
        self.assertTrue(all(item['status']=='confirmed' and item['confirmation_kind']=='human_batch_preview_confirmation' for item in record['items']))
        self.assertEqual(record['batch_confirmation']['text'],text)
        self.assertEqual(record['batch_confirmation']['digest'],preview['batch_digest'])
        self.assertIsNone(record['execution_batch']);self.assertFalse((self.output/'图片').exists())
        self.assertTrue((self.queue.path(rid).parent/'approved-spec.json').is_file())
        self.queue.bind_batch(rid,'b-isolated-test');self.assertEqual(self.queue.ready(rid)['execution_batch'],'b-isolated-test')
        with self.assertRaises(ValueError):self.queue.adjust_item(rid,1,{'focus':[.5,.4]})

    def test_tampered_preview_contact_sheet_or_manifest_cannot_be_confirmed(self):
        for target in ('preview','contact','manifest'):
            with self.subTest(target=target):
                rid=self.task();result=self.queue.preview_all(rid)
                path=(result['groups'][0]['items'][0]['preview'] if target=='preview' else
                      result['groups'][0]['contact_sheets'][0] if target=='contact' else result['manifest'])
                Path(path).write_bytes(b'tampered')
                with self.assertRaises(ValueError):self.queue.confirm_all(rid,result['batch_digest'],'旧总览不能确认')
                self.assertTrue(all(item['status']!='confirmed' for item in self.queue.load(rid)['items']))

    def test_source_or_revision_change_and_missing_preview_block_confirmation(self):
        rid=self.task();result=self.queue.preview_all(rid)
        Path(result['groups'][0]['items'][0]['preview']).unlink()
        with self.assertRaises(ValueError):self.queue.confirm_all(rid,result['batch_digest'],'缺文件不能确认')
        result=self.queue.preview_all(rid);Image.new('RGB',(128,160),'green').save(self.sources[0])
        with self.assertRaises(ValueError):self.queue.confirm_all(rid,result['batch_digest'],'源改了不能确认')
        record=profile.read_json(self.queue.path(rid));record['revision']='v-wrong-version';profile.write_json(self.queue.path(rid),record)
        with self.assertRaises(ValueError):self.queue.confirm_all(rid,result['batch_digest'],'版本改了不能确认')

    def test_adjust_only_one_item_reuses_others_into_one_new_generation(self):
        rid=self.task();old=self.queue.preview_all(rid);old_paths={row['index']:row['preview'] for group in old['groups'] for row in group['items']}
        with patch.object(self.engine,'_render',side_effect=AssertionError('adjust does not render')):
            adjusted=self.queue.adjust_item(rid,7,{'focus':[.5,.4]})
        self.assertTrue(adjusted['requires_preview_all'])
        with self.assertRaises(ValueError):self.queue.confirm_all(rid,old['batch_digest'],'旧总览已失效')
        with patch.object(self.engine,'_render',wraps=self.engine._render) as render:new=self.queue.preview_all(rid)
        self.assertEqual(render.call_count,1);self.assertNotEqual(old['batch_digest'],new['batch_digest'])
        generations={Path(row['preview']).parent.parent for group in new['groups'] for row in group['items']};self.assertEqual(len(generations),1)
        for group in new['groups']:
            for row in group['items']:
                self.assertNotEqual(row['preview'],old_paths[row['index']]);self.assertTrue(Path(old_paths[row['index']]).exists())
                if row['index']!=7:self.assertEqual(profile.file_hash(row['preview']),profile.file_hash(old_paths[row['index']]))
        self.queue.confirm_all(rid,new['batch_digest'],'修改后全批重新集中确认');self.queue.ready(rid)

    def test_adjust_after_confirmation_invalidates_batch_and_changed_basis_requires_choice(self):
        rid=self.task(('180x180',));risk=self.queue.preview_all(rid)
        self.queue.select_backend(rid,'python','本批5张放大选Python',indices=[1,2,3,4,5])
        preview=self.queue.preview_all(rid);self.queue.confirm_all(rid,preview['batch_digest'],'首次集中确认')
        self.queue.adjust_item(rid,3,{'crop_box':[.1,.1,.9,.9]})
        with self.assertRaises(ValueError):self.queue.ready(rid)
        with patch.object(self.engine,'_render',side_effect=AssertionError('new crop needs new choice')):result=self.queue.preview_all(rid)
        self.assertEqual([row['index'] for row in result['risks']],[3])
        self.queue.select_backend(rid,'python','只确认改后第3张新取景放大',indices=[3])
        new=self.queue.preview_all(rid);self.queue.confirm_all(rid,new['batch_digest'],'改后全批集中确认')
        self.assertTrue(self.queue.ready(rid)['batch_confirmation'])
        self.assertEqual(len(self.queue.load(rid)['batch_confirmation_history']),1)

    def test_frozen_specs_and_invalid_indices_rejected_without_other_changes(self):
        rid=self.task();before=profile.file_hash(self.queue.path(rid))
        for index,patch_value in [(0,{'focus':[.5,.5]}),(16,{'zoom':1.1}),(True,{'zoom':1.1}),
                                  (1,{'size':'80x80'}),(1,{'input':str(self.sources[1])}),(1,{'name':'changed'}),
                                  (1,{'format':'png'}),(1,{'out_dir':str(self.root/'other')}),(1,{})]:
            with self.assertRaises(ValueError):self.queue.adjust_item(rid,index,patch_value)
        self.assertEqual(profile.file_hash(self.queue.path(rid)),before)

    def test_over_twenty_sources_paginate_without_losing_numbers(self):
        paths=self.sources+[self.sources[0]]*20;rid=self.task(('40x40',),paths)
        result=self.queue.preview_all(rid);group=result['groups'][0]
        self.assertEqual([row['number'] for row in group['items']],list(range(1,26)))
        self.assertEqual(len(group['contact_sheets']),2)
        manifest=profile.read_json(result['manifest'])
        self.assertEqual(len(manifest['files']),27);self.assertEqual(len(manifest['items_binding']),25)
        self.queue.confirm_all(rid,result['batch_digest'],'25张两页都已查看确认');self.assertEqual(len(self.queue.ready(rid)['items']),25)

    def test_existing_gallery_reused_without_render_and_extra_file_blocks_approval(self):
        rid=self.task();first=self.queue.preview_all(rid)
        with patch.object(self.engine,'_render',side_effect=AssertionError('valid previews reused')):second=self.queue.preview_all(rid)
        self.assertTrue(second['reused']);self.assertEqual(second['batch_digest'],first['batch_digest'])
        Path(first['manifest']).with_name('unbound.jpg').write_bytes(b'unbound')
        with self.assertRaises(ValueError):self.queue.confirm_all(rid,first['batch_digest'],'额外文件不能混入总览')

    def test_confirm_requires_exact_digest_and_confirmed_gallery_still_protects_delivery(self):
        rid=self.task();result=self.queue.preview_all(rid)
        for value in (None,'','wrong'):
            with self.assertRaises(ValueError):self.queue.confirm_all(rid,value,'没有当前摘要不能集中确认')
        self.queue.confirm_all(rid,result['batch_digest'],'确认全部总览')
        self.assertTrue(self.queue.next(rid)['ready'])
        self.assertEqual(self.queue.load(rid)['review_mode'],'batch')
        Path(result['groups'][0]['contact_sheets'][0]).write_bytes(b'tampered after human approval')
        with self.assertRaises(ValueError):self.queue.ready(rid)
        with self.assertRaises(ValueError):self.queue.next(rid)
        self.assertEqual(self.queue.load(rid)['review_mode'],'batch')

    def test_unsupported_psd_structure_blocks_other_safe_psd_before_render(self):
        from psd_tools import PSDImage
        from psd_tools.api.layers import PixelLayer,Group
        paths=[]
        for index in range(2):
            path=self.root/f'pixel-{index}.psd';document=PSDImage.new('RGB',(80,80))
            PixelLayer.frompil(Image.new('RGB',(80,80),'red'),document,'Pixels')
            if index==1:Group.new(document,'Unsupported group')
            document.save(path);paths.append(path)
        rid=self.task(('40x40',),paths)
        with patch.object(self.engine,'_render',side_effect=AssertionError('unsupported blocks whole batch')):result=self.queue.preview_all(rid)
        self.assertEqual(len(result['risks']),1);self.assertFalse(result['risks'][0]['risk']['python_supported'])
        self.assertFalse(self.output.exists());self.assertFalse(self.engine.native_cache_root.exists())

    def test_legacy_comparison_approval_is_not_reused_as_target_batch_approval(self):
        rid=self.task(('40x40',));first=self.queue.next(rid)
        with Image.open(first['preview']) as opened:self.assertEqual(opened.size,(1020,600))
        self.queue.confirm(rid,first['digest'],'只确认旧单张原图对照')
        with patch.object(self.engine,'_render',wraps=self.engine._render) as render:batch=self.queue.preview_all(rid)
        self.assertEqual(render.call_count,5)
        record=self.queue.load(rid);self.assertEqual(record['review_mode'],'batch')
        self.assertTrue(all(item['status']=='previewed' for item in record['items']))
        self.assertNotIn('confirmation',record['items'][0]);self.assertNotIn('confirmation_kind',record['items'][0])
        self.assertEqual(record['items'][0]['confirmation_history'][0]['confirmation'],'只确认旧单张原图对照')
        self.assertFalse(batch['ready']);self.assertNotIn('batch_confirmation',record)
        for row in batch['groups'][0]['items']:
            with Image.open(row['preview']) as opened:self.assertEqual(opened.size,(40,40))
        with self.assertRaises(ValueError):self.queue.ready(rid)
        self.queue.confirm_all(rid,batch['batch_digest'],'现已查看全部目标尺寸预览并集中确认')
        self.queue.ready(rid)

    def test_transparent_preview_only_checker_for_png_and_white_for_jpg(self):
        from batch_preview import save_target_preview
        transparent=Image.new('RGBA',(48,32),(240,0,0,0));before=transparent.tobytes()
        jpg=self.root/'white-preview.jpg';png=self.root/'checker-preview.jpg'
        self.assertEqual(save_target_preview(transparent,jpg,{'format':'jpg'}),'white')
        self.assertEqual(save_target_preview(transparent,png,{'format':'png'}),'checkerboard_preview_only')
        with Image.open(jpg) as opened:
            self.assertEqual(opened.size,(48,32));self.assertGreater(min(opened.getpixel((24,8))),250)
        with Image.open(png) as opened:
            self.assertGreater(min(opened.getpixel((8,8))),250)
            self.assertLess(max(opened.getpixel((24,8))),215)
        self.assertEqual(transparent.tobytes(),before)

    def test_failed_transition_from_legacy_cannot_deliver_unseen_new_targets(self):
        rid=self.task(('40x40',))
        for _ in range(5):
            individual=self.queue.next(rid);self.queue.confirm(rid,individual['digest'],'旧单张对照确认')
        self.queue.ready(rid)
        render=self.engine._render;calls=[]
        def fail_second(job):
            calls.append(job)
            if len(calls)==2:raise RuntimeError('隔离测试模拟第2张预览失败')
            return render(job)
        with patch.object(self.engine,'_render',side_effect=fail_second):
            with self.assertRaises(RuntimeError):self.queue.preview_all(rid)
        record=self.queue.load(rid)
        self.assertEqual(record['review_mode'],'batch');self.assertNotIn('batch_preview',record)
        self.assertTrue(all(item['status']=='pending' and 'confirmation' not in item for item in record['items']))
        with self.assertRaises(ValueError):self.queue.ready(rid)


if __name__=='__main__':unittest.main()
