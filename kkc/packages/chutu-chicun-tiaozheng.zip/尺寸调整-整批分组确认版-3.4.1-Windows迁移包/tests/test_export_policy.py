import io
import os
import random
import sys
import unittest
from pathlib import Path

from PIL import Image, ImageCms

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = Path(os.environ.get("RESIZE_TEST_SKILL", ROOT / "skills/chutu-chicun-tiaozheng"))
sys.path.insert(0, str(PACKAGE / "scripts"))
from export_policy import DEFAULT_MAX_BYTES, encode_image


def noise(size=(800, 800), mode="RGB"):
    channels = 4 if mode == "RGBA" else 3
    return Image.frombytes(mode, size, random.Random(1759).randbytes(size[0] * size[1] * channels))


def opened(data):
    image = Image.open(io.BytesIO(data))
    image.load()
    return image


class ExportPolicyTests(unittest.TestCase):
    def test_real_noise_jpg_reduces_quality_to_actual_500000_byte_budget(self):
        image = noise()
        initial, high = encode_image(image, "jpg", max_bytes=4_000_000, min_quality=95, max_quality=95)
        self.assertGreater(len(initial), DEFAULT_MAX_BYTES)
        data, meta = encode_image(image, "jpg")
        self.assertLessEqual(len(data), 500_000)
        self.assertLess(meta["quality"], high["quality"])
        self.assertGreaterEqual(meta["quality"], 60)
        self.assertEqual(meta["bytes"], len(data))
        self.assertEqual(meta["max_bytes"], 500_000)
        self.assertEqual(opened(data).size, (800, 800))

    def test_jpeg_alias_and_custom_size(self):
        data, meta = encode_image(Image.new("RGB", (313, 157), "blue"), " JPEG ")
        self.assertEqual(meta["format"], "jpg")
        self.assertEqual(opened(data).format, "JPEG")
        self.assertEqual(opened(data).size, (313, 157))
        self.assertEqual(meta["quality"], 95)

    def test_jpg_transparent_background_becomes_white(self):
        image = Image.new("RGBA", (64, 64), (255, 0, 0, 0))
        original = image.tobytes()
        data, _ = encode_image(image, "jpg")
        result = opened(data)
        self.assertEqual(result.mode, "RGB")
        self.assertTrue(all(channel >= 250 for channel in result.getpixel((0, 0))))
        self.assertEqual(image.tobytes(), original)

    def test_jpg_half_transparent_black_is_composited_over_white(self):
        data, _ = encode_image(Image.new("RGBA", (64, 64), (0, 0, 0, 128)), "jpg")
        self.assertTrue(all(abs(value - 127) <= 1 for value in opened(data).getpixel((32, 32))))

    def test_png_retains_every_rgba_sample_including_hidden_rgb(self):
        image = noise((200, 200), "RGBA")
        original = image.tobytes()
        data, meta = encode_image(image, "PNG")
        result = opened(data)
        self.assertEqual(result.mode, "RGBA")
        self.assertEqual(result.size, image.size)
        self.assertEqual(result.tobytes(), original)
        self.assertEqual(image.tobytes(), original)
        self.assertIsNone(meta["quality"])
        self.assertEqual(meta["format"], "png")
        self.assertEqual(meta["bytes"], len(data))
        self.assertLessEqual(meta["bytes"], 500_000)

    def test_png_palette_transparency_and_colors_are_unchanged(self):
        image = Image.frombytes("P", (16, 16), bytes(range(256)))
        image.putpalette([value for i in range(256) for value in (i, 255-i, (i*7) % 256)])
        image.info["transparency"] = bytes(range(256))
        expected = image.convert("RGBA").tobytes()
        data, _ = encode_image(image, "png")
        self.assertEqual(opened(data).convert("RGBA").tobytes(), expected)

    def test_png_refuses_oversized_noise_without_lossy_fallback(self):
        image = noise((400, 400), "RGBA")
        original = image.tobytes()
        with self.assertRaisesRegex(ValueError, "PNG.*超过预算"):
            encode_image(image, "png")
        self.assertEqual(image.size, (400, 400))
        self.assertEqual(image.mode, "RGBA")
        self.assertEqual(image.tobytes(), original)

    def test_unattainable_jpg_budget_is_rejected_without_resizing(self):
        image = noise((128, 128))
        with self.assertRaisesRegex(ValueError, "JPG.*超过预算"):
            encode_image(image, "jpg", max_bytes=100)
        self.assertEqual(image.size, (128, 128))

    def test_byte_limit_is_inclusive(self):
        image = Image.new("RGBA", (50, 31), (2, 4, 6, 78))
        data, _ = encode_image(image, "png")
        exact, meta = encode_image(image, "png", max_bytes=len(data))
        self.assertEqual(exact, data)
        self.assertEqual(meta["bytes"], meta["max_bytes"])
        with self.assertRaises(ValueError):
            encode_image(image, "png", max_bytes=len(data)-1)

    def test_embedded_rgb_icc_is_preserved_for_both_formats(self):
        icc = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
        image = Image.new("RGB", (81, 37), (12, 40, 90))
        image.info["icc_profile"] = icc
        for fmt in ("jpg", "png"):
            with self.subTest(fmt=fmt):
                data, _ = encode_image(image, fmt)
                result = opened(data)
                self.assertEqual(result.size, image.size)
                self.assertEqual(result.info["icc_profile"], icc)

    def test_explicit_icc_overrides_embedded_profile(self):
        image = Image.new("RGB", (30, 20), "red")
        image.info["icc_profile"] = b"old profile metadata"
        icc = ImageCms.ImageCmsProfile(ImageCms.createProfile("sRGB")).tobytes()
        for fmt in ("jpg", "png"):
            data, _ = encode_image(image, fmt, icc_profile=bytearray(icc))
            self.assertEqual(opened(data).info["icc_profile"], icc)
        self.assertEqual(image.info["icc_profile"], b"old profile metadata")

    def test_custom_quality_bounds_are_respected(self):
        data, meta = encode_image(Image.new("RGB", (50, 50), "red"), "jpg", min_quality=72, max_quality=72)
        self.assertTrue(data)
        self.assertEqual(meta["quality"], 72)

    def test_invalid_byte_budgets(self):
        for value in (0, -1, True, False, 500_000.0, "500000", None):
            with self.subTest(value=value), self.assertRaises(ValueError):
                encode_image(Image.new("RGB", (2, 2)), "jpg", max_bytes=value)

    def test_invalid_quality_parameters(self):
        cases = [{"min_quality":0}, {"max_quality":101}, {"min_quality":96,"max_quality":95},
                 {"min_quality":True}, {"max_quality":95.5}, {"min_quality":"60"}, {"max_quality":None}]
        for kwargs in cases:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                encode_image(Image.new("RGB", (2, 2)), "jpg", **kwargs)

    def test_invalid_format_image_and_profile(self):
        image = Image.new("RGB", (2, 2))
        for fmt in ("webp", "gif", "", None, 5):
            with self.subTest(fmt=fmt), self.assertRaises(ValueError):
                encode_image(image, fmt)
        for value in (None, object(), Image.new("RGB", (0, 0))):
            with self.subTest(image=type(value)), self.assertRaises(ValueError):
                encode_image(value, "jpg")
        with self.assertRaises(ValueError):
            encode_image(image, "png", icc_profile="not bytes")

    def test_unsupported_color_modes_do_not_silently_quantize(self):
        with self.assertRaises(ValueError):
            encode_image(Image.new("CMYK", (5, 5)), "jpg")
        with self.assertRaises(ValueError):
            encode_image(Image.new("F", (5, 5)), "png")
        with self.assertRaises(ValueError):
            encode_image(Image.new("I", (5, 5), 100_000), "png")


if __name__ == "__main__":
    unittest.main(verbosity=2)
