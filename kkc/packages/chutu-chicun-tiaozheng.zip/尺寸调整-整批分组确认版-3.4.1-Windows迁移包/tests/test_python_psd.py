import hashlib
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageChops, ImageCms
from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer, Group
from psd_tools.constants import Compression, Resource, Tag

PACKAGE=Path(os.environ.get('RESIZE_TEST_SKILL',Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng'))
sys.path.insert(0,str(PACKAGE/'scripts'))
import python_psd


def fixture(path,size=20,icc=None):
    document=PSDImage.new('RGB',(size,size))
    PixelLayer.frompil(Image.new('RGB',(size,size),'white'),document,'Background')
    rgb=Image.new('RGB',(12,14))
    rgb.putdata([(x*17,y*15,(x+y)*8) for y in range(14) for x in range(12)])
    layer=PixelLayer.frompil(rgb,document,'Pixels',top=3,left=4)
    alpha=Image.new('L',rgb.size);alpha.putdata([30+(i*13)%226 for i in range(12*14)])
    for info,channel in zip(layer._record.channel_info,layer._channels):
        if int(info.id)==-1:
            channel.compression=Compression.RLE;channel.set_data(alpha.tobytes(),12,14,8,1);info.length=channel._length
    mask=Image.new('L',rgb.size);mask.putdata([(i*7)%256 for i in range(12*14)])
    layer.create_mask(mask,top=3,left=4);layer.opacity=173
    hidden=PixelLayer.frompil(Image.new('RGB',(3,3),'blue'),document,'Hidden',top=2,left=2);hidden.visible=False
    if icc is not None:document.image_resources[Resource.ICC_PROFILE]=python_psd.copy.deepcopy(_resource(icc))
    document.mark_updated();document.save(path)
    return path


def _resource(icc):
    from psd_tools.psd.image_resources import ImageResource
    return ImageResource(key=Resource.ICC_PROFILE,data=icc)


def plan(side,target,viewport=None):
    return {'source_size':[side,side],'output_size':[target,target],'effective_fit':'cover',
            'source_domain_px':[0,0,side,side],'source_viewport_px':viewport or [0,0,side,side],'warnings':[]}


class PythonPSDTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='python-psd-test-');self.root=Path(self.temp.name)
        self.source=fixture(self.root/'source.psd');self.before=python_psd.file_hash(self.source)

    def tearDown(self):self.temp.cleanup()

    def render(self,target=36,viewport=None,**job):
        return python_psd.render_python_psd({'input':str(self.source),'size':f'{target}x{target}',**job},self.root/'cache',plan(20,target,viewport))

    def low_alpha_source(self):
        document=PSDImage.open(self.source);layer=document[1]
        # Nonzero hidden RGB at alpha=0, and non-round-trippable colors at
        # alpha=1/128, expose an unnecessary RGB -> RGBa -> RGB conversion.
        for info,channel in zip(layer._record.channel_info,layer._channels):
            identifier=int(info.id)
            if identifier in (0,1,2,-1):
                values=[(0,1,128,255)[index%4] if identifier==-1 else 31+(index*17+identifier*53)%210
                        for index in range(12*14)]
                channel.compression=Compression.RLE;channel.set_data(bytes(values),12,14,8,1);info.length=channel._length
        document.mark_updated();self.source=self.root/'low-alpha.psd';document.save(self.source)
        return PSDImage.open(self.source)

    def decoded_channels(self,layer):
        result={};record=layer._record
        for info,channel in zip(record.channel_info,layer._channels):
            size=(record.right-record.left,record.bottom-record.top)
            if int(info.id)==-2:
                mask=record.mask_data;size=(mask.right-mask.left,mask.bottom-mask.top)
            result[int(info.id)]=(size,channel.get_data(*size,8,1))
        return result

    def test_identity_preserves_all_native_channel_bytes_including_hidden_rgb(self):
        source=self.low_alpha_source();before=python_psd.file_hash(self.source)
        alpha=self.decoded_channels(source[1])[-1][1]
        self.assertEqual(set(alpha),{0,1,128,255});self.assertNotEqual(self.decoded_channels(source[1])[0][1][0],0)
        _,_,metadata=self.render(20);output=PSDImage.open(metadata['variant_psd'])
        for original,actual in zip(source,output):
            self.assertEqual(self.decoded_channels(actual),self.decoded_channels(original))
            self.assertEqual(actual.bbox,original.bbox)
        self.assertIn(-2,self.decoded_channels(output[1]))
        self.assertEqual(python_psd.file_hash(self.source),before)

    def test_scale_one_crop_only_translates_geometry_without_resampling_channels(self):
        source=self.low_alpha_source();before=python_psd.file_hash(self.source)
        _,executed,metadata=self.render(10,[5,5,15,15]);output=PSDImage.open(metadata['variant_psd'])
        self.assertEqual(executed['source_viewport_px'],[5,5,15,15]);self.assertEqual(metadata['scale'],1)
        for original,actual in zip(source,output):
            self.assertEqual(self.decoded_channels(actual),self.decoded_channels(original))
            self.assertEqual(actual.bbox,tuple(value-5 for value in original.bbox))
            if original._record.mask_data is not None:
                wanted=original._record.mask_data;got=actual._record.mask_data
                self.assertEqual((got.left,got.top,got.right,got.bottom),tuple(value-5 for value in (wanted.left,wanted.top,wanted.right,wanted.bottom)))
        self.assertEqual(output[0].bbox,(-5,-5,15,15));self.assertEqual(output.size,(10,10))
        self.assertEqual(python_psd.file_hash(self.source),before)

    def test_global_mask_rejected_before_render_or_group_artifacts(self):
        from psd_tools.psd.layer_and_mask import GlobalLayerMaskInfo
        document=PSDImage.open(self.source)
        document._record.layer_and_mask_information.global_layer_mask_info=GlobalLayerMaskInfo(overlay_color=[0,65535,0,0,0],opacity=100)
        self.source=self.root/'global-mask.psd';document.save(self.source);before=python_psd.file_hash(self.source)
        self.assertFalse(python_psd.check_python_support(self.source)['supports'])
        with self.assertRaises(python_psd.PythonPSDUnsupported):self.render(20)
        self.assertFalse((self.root/'cache').exists())
        destination=self.root/'global-mask-group.psd'
        with self.assertRaises(python_psd.PythonPSDUnsupported):python_psd.group_python_psd_sources(destination,[self.source])
        self.assertFalse(destination.exists());self.assertEqual(python_psd.file_hash(self.source),before)

    def test_native_channels_mask_and_metadata_retained(self):
        with patch('psd_source._invoke_photoshop',side_effect=AssertionError('must not call Photoshop')):
            image,executed,metadata=self.render()
        output=PSDImage.open(metadata['variant_psd']);source=PSDImage.open(self.source)
        self.assertEqual(image.size,(36,36));self.assertEqual(output.size,(36,36))
        self.assertEqual([x.name for x in output],['Background','Pixels','Hidden'])
        self.assertEqual([x.visible for x in output],[True,True,False])
        self.assertEqual(output[1].opacity,173);self.assertEqual(output[1]._record.flags,source[1]._record.flags)
        self.assertEqual(python_psd.file_hash(self.source),self.before)
        original=python_psd.read_channels(source[1]);actual=python_psd.read_channels(output[1]);size=output[1].size
        reference=Image.merge('RGBA',tuple(original[i] for i in (0,1,2,-1))).convert('RGBa').resize(size,Image.Resampling.LANCZOS).convert('RGBA')
        for identifier,expected in zip((0,1,2,-1),reference.split()):self.assertEqual(actual[identifier].tobytes(),expected.tobytes())
        self.assertEqual(actual[-2].tobytes(),original[-2].resize(actual[-2].size,Image.Resampling.LANCZOS).tobytes())
        self.assertEqual(metadata['backend'],'python-pixel-psd');self.assertTrue(metadata['native_structure_verified'])
        self.assertTrue(metadata['all_layers_preserved']);self.assertEqual(metadata['variant_sha256'],python_psd.file_hash(metadata['variant_psd']))
        self.assertLessEqual(metadata['merged_verified']['color_max_lsb'],1)

    def test_crop_translates_absolute_bounds_preserves_off_canvas_channels(self):
        image,executed,metadata=self.render(40,[5,5,15,15]);output=PSDImage.open(metadata['variant_psd'])
        self.assertEqual(output[0].bbox,(-20,-20,60,60))
        self.assertEqual(output[1].bbox,(-4,-8,44,48))
        self.assertEqual([output[1]._record.mask_data.left,output[1]._record.mask_data.top,output[1]._record.mask_data.right,output[1]._record.mask_data.bottom],[-4,-8,44,48])
        self.assertEqual(python_psd.read_channels(output[0])[0].size,(80,80))
        self.assertEqual(image.size,(40,40));self.assertEqual(executed['source_viewport_px'],[5,5,15,15])

    def test_strict_geometry_failure_not_unsupported_structure(self):
        for viewport in ([-1,0,19,20],[0,0,10,20]):
            with self.assertRaises(ValueError) as error:self.render(36,viewport)
            self.assertNotIsInstance(error.exception,python_psd.PythonPSDUnsupported)
        self.assertFalse((self.root/'cache').exists())

    def test_groups_retain_child_pixel_channels_masks_and_visibility(self):
        _,_,one=self.render();_,_,two=self.render()
        destination=self.root/'groups.psd';result=python_psd.group_python_psd_sources(destination,[one,two])
        output=PSDImage.open(destination)
        self.assertEqual([x.name for x in output],['2','1']);self.assertEqual([x.name for x in output if x.visible],['1'])
        self.assertEqual(result['panel_order'],['1','2']);self.assertEqual(len(output[0]),3)
        for group in output:
            self.assertEqual([x.name for x in group],['Background','Pixels','Hidden'])
            self.assertEqual([x.visible for x in group],[True,True,False])
            reference=PSDImage.open(one['variant_psd'])
            self.assertEqual(python_psd.read_channels(group[1])[-2].tobytes(),python_psd.read_channels(reference[1])[-2].tobytes())
        before=destination.read_bytes()
        with self.assertRaises(FileExistsError):python_psd.group_python_psd_sources(destination,[one])
        self.assertEqual(destination.read_bytes(),before)

    def test_unsupported_groups_and_resources_explicit_without_fallback(self):
        document=PSDImage.open(self.source);Group.new(document,'Complex');document.save(self.root/'group-source.psd')
        with self.assertRaises(python_psd.PythonPSDUnsupported):python_psd.render_python_psd({'input':str(self.root/'group-source.psd'),'size':'20x20'},self.root/'cache')
        document=PSDImage.open(self.source)
        from psd_tools.psd.image_resources import ImageResource
        document.image_resources[2000]=ImageResource(key=2000,data=b'unsupported')
        document.save(self.root/'resource.psd')
        self.assertFalse(python_psd.check_python_support(self.root/'resource.psd')['supports'])
        with self.assertRaises(python_psd.PythonPSDUnsupported):python_psd.render_python_psd({'input':str(self.root/'resource.psd'),'size':'20x20'},self.root/'cache')
        broken=self.root/'broken.psd';broken.write_bytes(b'8BPS damaged')
        with self.assertRaises(Exception) as error:python_psd.check_python_support(broken)
        self.assertNotIsInstance(error.exception,python_psd.PythonPSDUnsupported)

    def test_explicit_selection_records_master_and_selected_layers(self):
        _,_,metadata=self.render(source_layers=['Background','Pixels'])
        self.assertFalse(metadata['all_layers_preserved']);self.assertTrue(metadata['source_selection']['enabled'])
        self.assertEqual(metadata['source_selection']['master_sha256'],self.before)
        self.assertEqual([x.name for x in PSDImage.open(metadata['variant_psd'])],['Background','Pixels'])
        for names in ([],['Pixels','Pixels'],['missing']):
            with self.assertRaises(ValueError):self.render(source_layers=names)

    def test_group_rejects_hash_tampering_mixed_sizes_and_names(self):
        _,_,one=self.render();_,_,two=self.render(30)
        with self.assertRaises(ValueError):python_psd.group_python_psd_sources(self.root/'mixed.psd',[one,two])
        with self.assertRaises(ValueError):python_psd.group_python_psd_sources(self.root/'bad.psd',[dict(one,variant_sha256='bad')])
        for names in (['x','x'],['x',' X'],['x']):
            with self.assertRaises(ValueError):python_psd.group_python_psd_sources(self.root/'bad.psd',[one,one],names)

    def test_icc_preserved_in_preview_variant_and_groups(self):
        profile=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
        self.source=fixture(self.root/'icc.psd',icc=profile)
        image,_,metadata=self.render();self.assertEqual(image.info['icc_profile'],profile)
        self.assertEqual(PSDImage.open(metadata['variant_psd']).image_resources.get_data(Resource.ICC_PROFILE),profile)
        destination=self.root/'icc-group.psd';python_psd.group_python_psd_sources(destination,[metadata])
        self.assertEqual(PSDImage.open(destination).image_resources.get_data(Resource.ICC_PROFILE),profile)
        _,_,plain=python_psd.render_python_psd({'input':str(self.root/'source.psd'),'size':'36x36'},self.root/'cache',plan(20,36))
        with self.assertRaises(ValueError):python_psd.group_python_psd_sources(self.root/'icc-mixed.psd',[metadata,plain])

    def test_group_reissues_duplicate_source_layer_ids_only(self):
        document=PSDImage.open(self.source)
        for index,layer in enumerate(document,1):layer._record.tagged_blocks.set_data(Tag.LAYER_ID,index)
        document.save(self.root/'ids.psd');self.source=self.root/'ids.psd'
        _,_,metadata=self.render();destination=self.root/'ids-group.psd'
        report=python_psd.group_python_psd_sources(destination,[metadata,metadata])
        output=PSDImage.open(destination)
        identifiers=[layer._record.tagged_blocks.get_data(Tag.LAYER_ID) for layer in output.descendants()]
        self.assertEqual(len(identifiers),len(set(identifiers)));self.assertTrue(report['layer_ids_reissued'])
        self.assertEqual(report['source_layer_ids'],[[1,2,3],[1,2,3]])

    def test_rgba_merged_alpha_and_transparent_group(self):
        document=PSDImage.frompil(Image.new('RGBA',(20,20),(0,0,0,0)));document._merged_alpha=True
        image=Image.new('RGBA',(12,14),(200,35,120,120))
        PixelLayer.frompil(image,document,'Transparent',top=3,left=4)
        document._record.layer_and_mask_information.layer_info.layer_count=-1
        document.mark_updated()
        self.source=self.root/'rgba.psd';document.save(self.source)
        _,_,metadata=self.render();variant=PSDImage.open(metadata['variant_psd'])
        self.assertEqual(variant.channels,4);self.assertLess(variant._record.layer_and_mask_information.layer_info.layer_count,0)
        destination=self.root/'rgba-group.psd';python_psd.group_python_psd_sources(destination,[metadata,metadata])
        output=PSDImage.open(destination);self.assertEqual(output.channels,4)
        forced=output.composite(force=True,ignore_preview=True,apply_icc=False)
        self.assertEqual(forced.convert('RGBA').getchannel('A').getpixel((0,0)),0)
        self.assertLessEqual(max(hi for _,hi in ImageChops.difference(variant.composite().convert('RGBA'),output.composite().convert('RGBA')).getextrema()),1)


if __name__=='__main__':unittest.main()
