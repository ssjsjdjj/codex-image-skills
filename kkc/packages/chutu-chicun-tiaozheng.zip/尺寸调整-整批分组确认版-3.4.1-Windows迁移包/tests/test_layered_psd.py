import hashlib
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageCms, ImageDraw
from psd_tools import PSDImage
from psd_tools.constants import Resource

PACKAGE = Path(os.environ.get('RESIZE_TEST_SKILL', Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng'))
sys.path.insert(0, str(PACKAGE/'scripts'))
import layered_psd
from layered_psd import write_layered_psd


class LayeredPSDTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='resize-layered-psd-')
        self.root = Path(self.temp.name)
        self.path = self.root/'多图层源文件.psd'

    def tearDown(self):
        self.temp.cleanup()

    @staticmethod
    def rgb_images(count=3, size=(67, 83)):
        images = []
        for index in range(count):
            image = Image.new('RGB', size, (index*29+5, index*39+10, index*49+20))
            ImageDraw.Draw(image).rectangle((3+index, 5, 18+index, 21), fill=(220, 60+index, 90))
            images.append(image)
        return images

    @staticmethod
    def rgba_images():
        images = []
        for index in range(3):
            image = Image.new('RGBA', (256, 11))
            image.putdata([((x*17+index)%256, (x*37+index*5)%256, (x*13+index*9)%256, x)
                           for y in range(11) for x in range(256)])
            images.append(image)
        return images

    def assert_pixels_by_name(self, document, images, names):
        by_name = {layer.name:layer for layer in document}
        for image, name in zip(images, names):
            self.assertEqual(by_name[name].topil(apply_icc=False).convert('RGBA').tobytes(), image.convert('RGBA').tobytes())

    def test_rgb_layers_top_to_bottom_names_and_only_first_visible(self):
        images = self.rgb_images()
        result = write_layered_psd(self.path, images)
        document = PSDImage.open(self.path)
        self.assertEqual(document.size, images[0].size)
        self.assertEqual([layer.name for layer in document], ['3','2','1'])
        self.assertEqual([layer.name for layer in document if layer.visible], ['1'])
        self.assertEqual(result['panel_order'], ['1','2','3'])
        self.assertEqual(result['api_layer_order'], ['3','2','1'])
        self.assertTrue(result['verified'])
        self.assert_pixels_by_name(document, images, ['1','2','3'])
        self.assertEqual(document.composite(apply_icc=False).convert('RGB').tobytes(), images[0].tobytes())

    def test_each_hidden_layer_can_be_shown_independently(self):
        images = self.rgb_images(); write_layered_psd(self.path, images)
        document = PSDImage.open(self.path)
        for index, source in enumerate(images):
            for layer in document: layer.visible = layer.name == str(index+1)
            composite = document.composite(force=True, ignore_preview=True, apply_icc=False)
            self.assertEqual(composite.convert('RGB').tobytes(), source.tobytes())

    def test_rgba_exact_layer_pixels_and_default_preview_transparency(self):
        images = self.rgba_images(); write_layered_psd(self.path, images)
        document = PSDImage.open(self.path)
        self.assert_pixels_by_name(document, images, ['1','2','3'])
        preview = document.composite(apply_icc=False)
        self.assertEqual(preview.mode, 'RGBA')
        self.assertEqual(preview.getchannel('A').tobytes(), images[0].getchannel('A').tobytes())
        self.assertEqual(document[2].topil(apply_icc=False).getpixel((0,0)), images[0].getpixel((0,0)))
        self.assertTrue(layered_psd._new_document('RGBA', (2,3))._merged_alpha)

    def test_rgb_and_rgba_layers_keep_source_pixels(self):
        sources = [self.rgb_images(1, (256,11))[0], self.rgba_images()[0]]
        write_layered_psd(self.path, sources)
        self.assert_pixels_by_name(PSDImage.open(self.path), sources, ['1','2'])

    def test_custom_names_and_visible_index(self):
        images = self.rgb_images()
        names = ['正面','侧面','背面']
        metadata = write_layered_psd(self.path, images, names=names, visible_index=2)
        document = PSDImage.open(self.path)
        self.assertEqual([l.name for l in document], list(reversed(names)))
        self.assertEqual([l.name for l in document if l.visible], ['背面'])
        self.assertEqual(metadata['visible_index'], 2)
        self.assert_pixels_by_name(document, images, names)
        self.assertEqual(document.composite(apply_icc=False).convert('RGB').tobytes(), images[2].tobytes())

    def test_five_1440_layers_are_lossless_and_not_limited_to_500kb(self):
        size = (1440,1440)
        images = [Image.frombytes('RGB', size, random.Random(17+index).randbytes(size[0]*size[1]*3)) for index in range(5)]
        originals = [hashlib.sha256(image.tobytes()).hexdigest() for image in images]
        result = write_layered_psd(self.path, images)
        document = PSDImage.open(self.path)
        self.assertEqual(document.size, size); self.assertEqual(len(document), 5)
        self.assertGreater(self.path.stat().st_size, 500*1024)
        self.assertEqual(result['layer_count'],5)
        self.assert_pixels_by_name(document, images, [str(n) for n in range(1,6)])
        self.assertEqual([hashlib.sha256(image.tobytes()).hexdigest() for image in images], originals)

    def test_identical_rgb_icc_profile_preserved(self):
        images = self.rgb_images()
        icc = ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
        for image in images: image.info['icc_profile'] = icc
        result = write_layered_psd(self.path, images)
        document = PSDImage.open(self.path)
        self.assertEqual(document.image_resources.get_data(Resource.ICC_PROFILE), icc)
        self.assertTrue(result['icc_preserved'])
        self.assert_pixels_by_name(document, images, ['1','2','3'])

    def test_inconsistent_or_missing_icc_is_rejected_before_write(self):
        for profiles in [(b'one',b'two'), (b'one',None)]:
            images = self.rgb_images(2)
            for image, profile in zip(images, profiles):
                if profile is not None:image.info['icc_profile'] = profile
            with self.assertRaisesRegex(ValueError,'ICC'):write_layered_psd(self.path, images)
            self.assertFalse(self.path.exists())

    def test_invalid_icc_type_is_rejected(self):
        images = self.rgb_images(1); images[0].info['icc_profile'] = 'not bytes'
        with self.assertRaises(ValueError):write_layered_psd(self.path, images)

    def test_existing_psd_remains_unchanged(self):
        self.path.write_bytes(b'original PSD must stay untouched')
        before = self.path.read_bytes()
        with self.assertRaises(FileExistsError):write_layered_psd(self.path, self.rgb_images())
        self.assertEqual(self.path.read_bytes(),before)

    def test_late_destination_race_never_overwrites(self):
        original_link = os.link
        def competing_link(src, dst):
            Path(dst).write_bytes(b'other writer')
            return original_link(src,dst)
        with patch.object(layered_psd.os,'link',side_effect=competing_link):
            with self.assertRaises(FileExistsError):write_layered_psd(self.path, self.rgb_images())
        self.assertEqual(self.path.read_bytes(),b'other writer')
        self.assertEqual(list(self.root.glob('.layered-psd-*')),[])

    def test_invalid_inputs_are_rejected(self):
        cases = [[], [object()], [Image.new('L',(5,5))], [Image.new('RGB',(5,5)),Image.new('RGB',(6,5))]]
        for images in cases:
            with self.subTest(images=images):
                with self.assertRaises(ValueError):write_layered_psd(self.path,images)
                self.assertFalse(self.path.exists())

    def test_invalid_and_duplicate_layer_names_are_rejected(self):
        invalid = ['12', 123, ['only-one'], ['1','1'], ['A','a'], ['', '2'], ['  ','2'], ['1\n','2'], ['a\x00b','2'],
                   [' leading','2'], ['trailing ','2'], ['x'*256,'2'], [1,'2'], ['é','e\u0301']]
        for names in invalid:
            with self.subTest(names=names):
                with self.assertRaises(ValueError):write_layered_psd(self.path,self.rgb_images(2),names=names)
                self.assertFalse(self.path.exists())

    def test_invalid_visible_index_is_rejected(self):
        for index in (-1,2,1.5,'0',True,None):
            with self.subTest(index=index):
                with self.assertRaises(ValueError):write_layered_psd(self.path,self.rgb_images(2),visible_index=index)
                self.assertFalse(self.path.exists())

    def test_write_or_verification_failure_does_not_publish_or_leave_temp(self):
        for target in ('_verify',):
            with patch.object(layered_psd,target,side_effect=ValueError('simulated verification failure')):
                with self.assertRaises(ValueError):write_layered_psd(self.path,self.rgb_images())
            self.assertFalse(self.path.exists()); self.assertEqual(list(self.root.glob('.layered-psd-*')),[])
        with patch.object(PSDImage,'save',side_effect=OSError('simulated write failure')):
            with self.assertRaises(OSError):write_layered_psd(self.path,self.rgb_images())
        self.assertFalse(self.path.exists()); self.assertEqual(list(self.root.glob('.layered-psd-*')),[])


if __name__=='__main__':
    unittest.main(verbosity=2)
