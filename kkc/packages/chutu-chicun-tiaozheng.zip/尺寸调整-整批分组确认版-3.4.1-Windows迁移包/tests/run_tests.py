"""Reproducible test driver; runtime.json and state always use a temporary copy."""
import argparse
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--group', choices=['workflow', 'installer', 'all'], default='all')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    sys.dont_write_bytecode = True
    with tempfile.TemporaryDirectory(prefix='resize-tests-') as directory:
        skill = Path(directory) / 'skill'
        source = Path(os.environ.get('RESIZE_TEST_SKILL', root/'skills/chutu-chicun-tiaozheng'))
        shutil.copytree(source, skill)
        (skill/'runtime.json').write_text(json.dumps({'schema':1,'python':sys.executable,'runtime':directory}), encoding='utf-8')
        os.environ['RESIZE_TEST_SKILL'] = str(skill)
        os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
        os.environ['PYTHONUTF8'] = '1'
        sys.path[:0] = [str(skill/'scripts'), str(root/'tests')]
        suite = unittest.TestSuite()
        names = []
        if args.group in ('workflow', 'all'):
            names += ['test_workflow', 'test_optimized', 'test_export_policy', 'test_layered_psd',
                      'test_delivery_spec', 'test_delivery_notes', 'test_delivery_flow', 'test_rule_context',
                      'test_style_authorization','test_psd_source','test_backend_policy','test_python_psd',
                      'test_backend_workflow','test_batch_preview','test_batch_preview_cli','test_main_photo_update']
        if args.group in ('installer', 'all'):
            names += ['test_deployment']
        for name in names:
            suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name))
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        print(json.dumps({'group':args.group, 'tests':result.testsRun, 'failures':len(result.failures),
                          'errors':len(result.errors), 'skipped':len(result.skipped), 'passed':result.wasSuccessful()}))
        return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
