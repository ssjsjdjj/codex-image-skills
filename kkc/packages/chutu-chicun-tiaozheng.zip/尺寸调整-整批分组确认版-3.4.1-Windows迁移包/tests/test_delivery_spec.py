import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

from PIL import Image

PACKAGE = Path(os.environ.get('RESIZE_TEST_SKILL', Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng'))
sys.path.insert(0, str(PACKAGE/'scripts'))
from delivery_spec import normalize_delivery,size_options


class DeliverySpecTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='resize-delivery-spec-')
        self.root = Path(self.temp.name).resolve()
        self.spec_path = self.root/'任务单.json'
        self.output = self.root/'交付包'

    def tearDown(self):
        self.temp.cleanup()

    def spec(self, kind='main', count=5, **delivery):
        extension='psd' if kind == 'main' else 'jpg'
        return {'delivery': {'kind':kind, 'style_id':'KCT-款01', 'out_dir':str(self.output), 'naming':'numbered',
                             'sizes':['800x800','1440x1440','750x1000'], **delivery},
                'jobs':[{'input':str(self.root/f'原图{i}.{extension}'), 'focus':[.5,.4], 'protect_box':[.2,.3,.8,.8]} for i in range(1,count+1)]}

    def normalize(self, spec):
        self.spec_path.write_text(json.dumps(spec,ensure_ascii=False),encoding='utf-8')
        return normalize_delivery(self.spec_path)

    def test_legacy_without_delivery_is_unchanged(self):
        self.assertIsNone(self.normalize({'jobs':[{'input':'old.png','size':'800x800'}]}))

    def test_five_sources_expand_size_major_to_fifteen_numbered_jpgs_and_three_psd_groups(self):
        original = self.spec()
        result = self.normalize(original)
        jobs = result['jobs']
        self.assertEqual(len(jobs),15)
        self.assertEqual([j['size'] for j in jobs],['800x800']*5+['1440x1440']*5+['750x1000']*5)
        self.assertEqual([j['_delivery']['index'] for j in jobs],list(range(1,6))*3)
        self.assertEqual(len({j['_delivery']['psd_path'] for j in jobs}),3)
        for i,j in enumerate(jobs):
            index=i%5+1
            self.assertEqual(j['input'],original['jobs'][index-1]['input'])
            self.assertEqual(j['name'],str(index))
            self.assertEqual(Path(j['out_dir']),self.output/'图片'/j['size'])
            self.assertEqual(j['format'],'jpg');self.assertFalse(j['psd']);self.assertEqual(j['max_bytes'],500000)
            self.assertEqual(j['_delivery']['layer_name'],str(index));self.assertEqual(j['_delivery']['source_count'],5)
            self.assertEqual(Path(j['_delivery']['psd_path']),self.output/'源文件'/f'KCT-款01_{j["size"]}.psd')
            self.assertEqual(j['focus'],[.5,.4]);self.assertEqual(j['protect_box'],[.2,.3,.8,.8])
        self.assertEqual(result['policy']['naming'],'numbered')
        self.assertFalse(self.output.exists())

    def test_scene_uses_only_the_explicitly_selected_sizes(self):
        result=self.normalize(self.spec(kind='scene',count=1))
        self.assertEqual([j['size'] for j in result['jobs']],['800x800','1440x1440','750x1000'])

    def test_main_and_scene_have_separate_exact_preset_menus_with_custom(self):
        main=size_options('main');scene=size_options('scene')
        self.assertEqual(main['kind'],'main');self.assertEqual(scene['kind'],'scene')
        self.assertEqual(main['presets'],['800x800','1440x1440','750x1000'])
        self.assertEqual(scene['presets'],['750x1000','800x800','800x1200'])
        self.assertNotIn('1440x1440',scene['presets']);self.assertNotIn('800x1200',main['presets'])
        self.assertEqual(main['custom'],{'enabled':True,'min':1,'max':10000})
        self.assertEqual(scene['custom'],main['custom']);json.dumps([main,scene])

    def test_size_options_reject_unknown_entry_and_return_independent_data(self):
        for kind in ['white','transparent','MAIN',None,[],True]:
            with self.subTest(kind=kind),self.assertRaises(ValueError):size_options(kind)
        altered=size_options('scene');altered['presets'].append('wrong');altered['custom']['enabled']=False
        self.assertEqual(size_options('scene')['presets'],['750x1000','800x800','800x1200'])
        self.assertTrue(size_options('scene')['custom']['enabled'])

    def test_scene_1440_is_valid_custom_and_each_size_records_menu_source(self):
        result=self.normalize(self.spec(kind='scene',count=2,
                  sizes=['1440x1440','750x1000','800x1200','800x800','1200x1600']))
        self.assertEqual(result['policy']['presets'],size_options('scene')['presets'])
        selections=[{'size':size,'source':source} for size,source in
                    [('1440x1440','custom'),('750x1000','preset'),('800x1200','preset'),
                     ('800x800','preset'),('1200x1600','custom')]]
        self.assertEqual(result['policy']['size_selections'],selections)
        self.assertEqual([job['_delivery']['size_source'] for job in result['jobs']],
                         [item['source'] for item in selections for _ in range(2)])
        self.assertEqual([job['size'] for job in result['jobs']],
                         [item['size'] for item in selections for _ in range(2)])

    def test_scene_800x1200_preset_is_custom_for_main_without_being_rejected(self):
        result=self.normalize(self.spec(count=1,sizes=['800×1200','1440x1440']))
        self.assertEqual(result['policy']['presets'],size_options('main')['presets'])
        self.assertEqual(result['policy']['size_selections'],[
            {'size':'800x1200','source':'custom'},{'size':'1440x1440','source':'preset'}])

    def test_numbered_groups_support_arbitrary_source_count_not_only_five(self):
        result=self.normalize(self.spec(kind='scene',count=8,naming='numbered',sizes=['800x1200','1200x1600']))
        self.assertEqual(len(result['jobs']),16)
        self.assertEqual(result['policy']['source_count'],8)
        self.assertEqual(result['policy']['naming_source'],'explicit')
        paths=set()
        for size in ['800x1200','1200x1600']:
            group=[job for job in result['jobs'] if job['size']==size]
            self.assertEqual([job['name'] for job in group],[str(i) for i in range(1,9)])
            self.assertEqual([job['_delivery']['index'] for job in group],list(range(1,9)))
            self.assertEqual([job['_delivery']['layer_name'] for job in group],[str(i) for i in range(1,9)])
            self.assertEqual(len({job['_delivery']['psd_path'] for job in group}),1)
            paths.update(str(Path(job['out_dir'])/(job['name']+'.'+job['format'])) for job in group)
        self.assertEqual(len(paths),16);self.assertFalse(self.output.exists())

    def test_numbered_mixed_formats_share_source_sequence_per_size_without_paths_colliding(self):
        spec=self.spec(kind='scene',count=3,sizes=['750x1000','800x1200']);spec['delivery'].pop('naming')
        for job,suffix in zip(spec['jobs'],['.png','.jpg','.JPEG']):job['input']=str(self.root/('同名'+suffix))
        result=self.normalize(spec)
        self.assertEqual(result['policy']['format'],'source')
        self.assertEqual([job['name'] for job in result['jobs']],['1','2','3']*2)
        self.assertEqual([job['format'] for job in result['jobs']],['png','jpg','jpg']*2)
        self.assertEqual([job['_delivery']['index'] for job in result['jobs']],[1,2,3]*2)
        paths=[str(Path(job['out_dir'])/(job['name']+'.'+job['format'])) for job in result['jobs']]
        self.assertEqual(len(set(paths)),6)
        self.assertEqual([Path(path).name for path in paths],['1.png','2.jpg','3.jpg']*2)
        self.assertEqual(len({job['_delivery']['psd_path'] for job in result['jobs']}),2)

    def test_default_numbering_replaces_old_safe_job_stem_without_claiming_authorization(self):
        spec=self.spec(count=1,sizes=['800x800']);spec['delivery'].pop('naming')
        spec['jobs'][0]['name']='旧任务图片名'
        result=self.normalize(spec)
        self.assertEqual(result['jobs'][0]['name'],'1')
        self.assertEqual(result['policy']['naming_source'],'default')
        self.assertNotIn('human_confirmed',result['policy'])

    def test_explicit_legacy_naming_is_a_compatible_override_not_human_authorization(self):
        result=self.normalize(self.spec(count=2,sizes=['800x800'],naming='style_size_index'))
        self.assertEqual([job['name'] for job in result['jobs']],['KCT-款01_800x800_1','KCT-款01_800x800_2'])
        self.assertEqual(result['policy']['naming_source'],'explicit')
        self.assertNotIn('authorization',result['policy']);self.assertNotIn('confirmation',result['policy'])

    def test_style_id_is_still_required_with_default_numbering(self):
        spec=self.spec(kind='scene',count=1);spec['delivery'].pop('naming');spec['delivery'].pop('style_id')
        with self.assertRaisesRegex(ValueError,'style_id'):self.normalize(spec)
        self.assertFalse(self.output.exists())

    def test_explicit_null_naming_is_invalid_instead_of_a_silent_override(self):
        with self.assertRaises(ValueError):self.normalize(self.spec(naming=None))

    def test_white_and_transparent_have_no_operation_entry(self):
        for kind in ['white','transparent']:
            with self.subTest(kind=kind),self.assertRaisesRegex(ValueError,'仅支持main/scene'):
                self.normalize(self.spec(kind=kind,count=1,sizes=['800x800']))

    def test_main_explicit_png_is_preserved(self):
        spec=self.spec(count=1);spec['jobs'][0]['format']='png'
        self.assertTrue(all(j['format']=='png' for j in self.normalize(spec)['jobs']))

    def test_delivery_level_png_is_supported(self):
        result=self.normalize(self.spec(count=1,format='png'))
        self.assertEqual(result['policy']['format'],'png')
        self.assertTrue(all(j['format']=='png' for j in result['jobs']))

    def test_original_naming_uses_input_stem_with_size_directories(self):
        result=self.normalize(self.spec(count=2,naming='original'))
        self.assertEqual([j['name'] for j in result['jobs']],['原图1','原图2']*3)
        self.assertEqual(len({str(Path(j['out_dir'])/(j['name']+'.'+j['format'])) for j in result['jobs']}),6)

    def test_windows_original_stem_is_supported(self):
        spec=self.spec(kind='scene',count=1,naming='original');spec['jobs'][0]['input']='C:\\素材\\原名01.JPG'
        self.assertEqual(self.normalize(spec)['jobs'][0]['name'],'原名01')

    def test_two_styles_have_isolated_names_and_psd_groups(self):
        a=self.normalize(self.spec(count=1,naming='style_size_index'))
        b=self.normalize(self.spec(count=1,style_id='KCT-款02',naming='style_size_index'))
        self.assertTrue({j['name'] for j in a['jobs']}.isdisjoint({j['name'] for j in b['jobs']}))
        self.assertTrue({j['_delivery']['psd_path'] for j in a['jobs']}.isdisjoint({j['_delivery']['psd_path'] for j in b['jobs']}))

    def test_shared_defaults_are_merged_by_fixed_loader(self):
        spec=self.spec(count=1);spec['defaults']={'zoom':1.1,'format':'png','size':'300x200','psd':True}
        result=self.normalize(spec)
        self.assertEqual([j['size'] for j in result['jobs']],['800x800','1440x1440','750x1000'])
        self.assertTrue(all(j['zoom']==1.1 and j['format']=='png' and j['psd'] is False for j in result['jobs']))

    def test_custom_scene_sizes_and_cap(self):
        result=self.normalize(self.spec(kind='scene',count=1,sizes=['800×800','1200X1600'],max_bytes=450000))
        self.assertEqual(result['policy']['sizes'],['800x800','1200x1600'])
        self.assertTrue(all(j['max_bytes']==450000 for j in result['jobs']))

    def test_mixed_style_is_rejected(self):
        spec=self.spec();spec['jobs'][1]['style_id']='OTHER'
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_mixed_kind_is_rejected(self):
        spec=self.spec();spec['jobs'][1]['kind']='transparent'
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_style_path_injection_and_reserved_names_are_rejected(self):
        for style in ['../other','..\\other','x/y','x:y','NUL','con.txt',' bad','bad.','bad\u200b']:
            with self.subTest(style=style),self.assertRaises(ValueError):self.normalize(self.spec(style_id=style))

    def test_unsafe_original_stem_is_rejected(self):
        for name in ['CON.jpg','bad?.png','bad:.jpg']:
            spec=self.spec(kind='scene',count=1,naming='original');spec['jobs'][0]['input']=str(self.root/name)
            with self.subTest(name=name),self.assertRaises(ValueError):self.normalize(spec)

    def test_unsafe_explicit_job_name_is_rejected(self):
        spec=self.spec(count=1);spec['jobs'][0]['name']='../escape'
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_duplicate_original_names_case_insensitive_are_rejected(self):
        spec=self.spec(kind='scene',count=2,naming='original')
        spec['jobs'][0]['input']=str(self.root/'one/Same.jpg');spec['jobs'][1]['input']=str(self.root/'two/same.jpg')
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_duplicate_normalized_sizes_are_rejected(self):
        with self.assertRaises(ValueError):self.normalize(self.spec(sizes=['800x800','800×800']))

    def test_existing_image_is_rejected_without_mutation(self):
        existing=self.output/'图片/800x800/1.jpg';existing.parent.mkdir(parents=True);existing.write_bytes(b'keep')
        with self.assertRaises(ValueError):self.normalize(self.spec(count=1))
        self.assertEqual(existing.read_bytes(),b'keep')

    def test_existing_psd_is_rejected_without_mutation(self):
        existing=self.output/'源文件/KCT-款01_800x800.psd';existing.parent.mkdir(parents=True);existing.write_bytes(b'keep')
        with self.assertRaises(ValueError):self.normalize(self.spec(count=1))
        self.assertEqual(existing.read_bytes(),b'keep')

    def test_output_root_cannot_be_a_file(self):
        self.output.write_bytes(b'keep')
        with self.assertRaises(ValueError):self.normalize(self.spec(count=1))
        self.assertEqual(self.output.read_bytes(),b'keep')

    def test_invalid_delivery_shapes_and_fields_are_rejected(self):
        for delivery in [None, [], {}, {'kind':'unknown','style_id':'A','out_dir':str(self.output)},
                         {'kind':'main','out_dir':str(self.output)}, {'kind':'main','style_id':'A'},
                         {'kind':'main','style_id':'A','out_dir':str(self.output),'typo':True}]:
            with self.subTest(delivery=delivery),self.assertRaises(ValueError):self.normalize({'delivery':delivery,'jobs':[{'input':'x.jpg'}]})

    def test_empty_and_invalid_jobs_are_rejected(self):
        for jobs in [[],None,[{}],[{'input':''}],['wrong']]:
            spec=self.spec();spec['jobs']=jobs
            with self.subTest(jobs=jobs),self.assertRaises(ValueError):self.normalize(spec)

    def test_invalid_cap_is_rejected(self):
        for cap in [0,-1,500001,True,500000.0,'500000']:
            with self.subTest(cap=cap),self.assertRaises(ValueError):self.normalize(self.spec(max_bytes=cap))

    def test_invalid_sizes_and_naming_are_rejected(self):
        for sizes in [[], '800x800', ['0x800'],['10001x800'],[800],['bad']]:
            with self.subTest(sizes=sizes),self.assertRaises(ValueError):self.normalize(self.spec(sizes=sizes))
        with self.assertRaises(ValueError):self.normalize(self.spec(naming='freeform'))

    def test_existing_png_can_be_used_for_scene_with_png_output(self):
        spec=self.spec(kind='scene',count=1,format='png',sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'现有透明素材.png')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['source_type'],'photos')
        self.assertEqual(result['jobs'][0]['format'],'png')
        self.assertEqual(result['jobs'][0]['_delivery']['source_type'],'photos')

    def test_reserved_metadata_injection_is_rejected(self):
        for key in ['_delivery','delivery']:
            spec=self.spec(count=1);spec['jobs'][0][key]={'style_id':'OTHER'}
            with self.subTest(key=key),self.assertRaises(ValueError):self.normalize(spec)

    def test_missing_naming_defaults_to_numbered_without_inventing_authorization(self):
        spec=self.spec();spec['delivery'].pop('naming')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['naming'],'numbered')
        self.assertEqual(result['policy']['naming_source'],'default')
        self.assertEqual([job['name'] for job in result['jobs']],['1','2','3','4','5']*3)
        self.assertNotIn('confirmation',result['policy'])
        self.assertNotIn('authorization',result['policy'])
        self.assertFalse(self.output.exists())

    def test_naming_object_requires_both_fields(self):
        for naming in [{},{'image':'{original_stem}'},{'psd':'{style_id}_{size}'},
                       {'image':'{original_stem}','psd':'{style_id}_{size}','extra':'bad'}]:
            with self.subTest(naming=naming),self.assertRaises(ValueError):self.normalize(self.spec(naming=naming))

    def test_explicit_templates_support_padded_index_and_psd_name(self):
        naming={'image':'{style_id}_{size}_{index:02d}_{original_stem}', 'psd':'{style_id}_{size}_分层源文件'}
        result=self.normalize(self.spec(count=2,naming=naming))
        self.assertEqual(result['policy']['naming'],naming)
        self.assertEqual(result['jobs'][0]['name'],'KCT-款01_800x800_01_原图1')
        self.assertEqual(result['jobs'][1]['name'],'KCT-款01_800x800_02_原图2')
        self.assertTrue(result['jobs'][0]['_delivery']['psd_path'].endswith('KCT-款01_800x800_分层源文件.psd'))
        self.assertEqual(result['jobs'][1]['_delivery']['layer_name'],'2')

    def test_psd_templates_cannot_use_index_or_original_stem(self):
        for template in ['{style_id}_{size}_{index}','{original_stem}_{size}']:
            with self.subTest(template=template),self.assertRaises(ValueError):
                self.normalize(self.spec(naming={'image':'{original_stem}','psd':template}))

    def test_templates_cannot_inject_fields_attributes_or_paths(self):
        for template in ['{unknown}','{style_id.__class__}','{style_id[0]}','{index!r}','../{index}',
                         '..\\{index}','{index:{style_id}}','{index:999999999d}','{unclosed']:
            with self.subTest(template=template),self.assertRaises(ValueError):
                self.normalize(self.spec(naming={'image':template,'psd':'{style_id}_{size}'}))

    def test_template_image_collisions_are_rejected(self):
        with self.assertRaises(ValueError):
            self.normalize(self.spec(naming={'image':'{style_id}_{size}','psd':'{style_id}_{size}'}))

    def test_template_psd_collisions_between_sizes_are_rejected(self):
        with self.assertRaises(ValueError):
            self.normalize(self.spec(count=1,naming={'image':'{style_id}_{size}_{index}','psd':'{style_id}'}))

    def test_output_subdirectories_cannot_be_files(self):
        self.output.mkdir()
        (self.output/'图片').write_bytes(b'keep')
        with self.assertRaises(ValueError):self.normalize(self.spec(count=1))
        self.assertEqual((self.output/'图片').read_bytes(),b'keep')

    def test_sizes_missing_requires_human_selection(self):
        spec=self.spec();spec['delivery'].pop('sizes')
        with self.assertRaisesRegex(ValueError,'人工选择输出尺寸'):self.normalize(spec)
        self.assertFalse(self.output.exists())

    def test_one_size_does_not_force_other_sizes(self):
        result=self.normalize(self.spec(count=5,sizes=['1440x1440']))
        self.assertEqual(len(result['jobs']),5)
        self.assertEqual({j['size'] for j in result['jobs']},{'1440x1440'})
        self.assertEqual(len({j['_delivery']['psd_path'] for j in result['jobs']}),1)

    def test_custom_dimension_limits_are_supported(self):
        result=self.normalize(self.spec(count=1,sizes=['1x1','10000x10000','1200x1600']))
        self.assertEqual([j['size'] for j in result['jobs']],['1x1','10000x10000','1200x1600'])

    def test_policy_has_all_fields_for_main_integration(self):
        result=self.normalize(self.spec(count=5,sizes=['800x800']))
        required={'out_dir','sizes','kind','style_id','naming','source_count','max_bytes','source_type'}
        self.assertTrue(required.issubset(result['policy']))
        self.assertEqual(result['policy']['source_count'],5)
        self.assertEqual(result['policy']['source_type'],'psd')
        self.assertTrue(all(j['_delivery']['source_type']=='psd' for j in result['jobs']))

    def test_main_accepts_jpg_and_png_without_an_intermediate_psd(self):
        for suffix in ['jpg','png']:
            for declared in [None,'photos']:
                spec=self.spec(count=1);spec['jobs'][0]['input']=str(self.root/f'主图.{suffix}')
                if declared is not None:spec['delivery']['source_type']=declared
                with self.subTest(suffix=suffix,declared=declared):
                    result=self.normalize(spec)
                    self.assertEqual(result['policy']['kind'],'main')
                    self.assertEqual(result['policy']['source_type'],'photos')
                    self.assertEqual([job['format'] for job in result['jobs']],[suffix]*3)
                    self.assertEqual(len({job['_delivery']['psd_path'] for job in result['jobs']}),3)
        self.assertFalse(self.output.exists())

    def test_main_still_rejects_photo_falsely_declared_as_psd(self):
        spec=self.spec(count=1,source_type='psd');spec['jobs'][0]['input']=str(self.root/'主图.jpg')
        with self.assertRaisesRegex(ValueError,'source_type与实际输入扩展名不一致'):self.normalize(spec)

    def test_scene_accepts_psd_source(self):
        spec=self.spec(kind='scene',count=2)
        for i,job in enumerate(spec['jobs'],1):job['input']=str(self.root/f'场景{i}.PSD')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['source_type'],'psd')
        self.assertTrue(all(j['_delivery']['source_type']=='psd' for j in result['jobs']))

    def test_scene_rejects_mixed_photo_and_psd_sources(self):
        spec=self.spec(kind='scene',count=2);spec['jobs'][1]['input']=str(self.root/'场景.psd')
        with self.assertRaisesRegex(ValueError,'不能混合照片和PSD'):self.normalize(spec)

    def test_scene_declared_source_type_must_match_files(self):
        with self.assertRaises(ValueError):self.normalize(self.spec(kind='scene',source_type='psd'))
        result=self.normalize(self.spec(kind='scene',source_type='photos'))
        self.assertEqual(result['policy']['source_type'],'photos')

    def test_job_source_type_cannot_misrepresent_input(self):
        spec=self.spec(count=1);spec['jobs'][0]['source_type']='photos'
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_unknown_source_type_or_extension_is_rejected(self):
        with self.assertRaises(ValueError):self.normalize(self.spec(source_type='vectors'))
        spec=self.spec(kind='scene',count=1);spec['jobs'][0]['input']=str(self.root/'unsupported.pdf')
        with self.assertRaises(ValueError):self.normalize(spec)

    def test_existing_fake_psd_signature_is_rejected(self):
        fake=self.root/'fake.psd';fake.write_bytes(b'\xff\xd8\xff\xe0JPEGbytes')
        spec=self.spec(count=1);spec['jobs'][0]['input']=str(fake)
        with self.assertRaisesRegex(ValueError,'PSD输入文件头不正确'):self.normalize(spec)
        self.assertEqual(fake.read_bytes(),b'\xff\xd8\xff\xe0JPEGbytes')

    def test_existing_psd_signature_is_read_only(self):
        psd=self.root/'source.psd';psd.write_bytes(b'8BPS\x00\x01header-only-fixture')
        spec=self.spec(count=1);spec['jobs'][0]['input']=str(psd)
        before=psd.read_bytes()
        self.assertEqual(self.normalize(spec)['policy']['source_type'],'psd')
        self.assertEqual(psd.read_bytes(),before)

    def test_matching_explicit_extensions_are_removed_from_job_stems(self):
        naming={'image':'{style_id}_{size}_{index:02d}.JPG','psd':'{style_id}_{size}.PSD'}
        result=self.normalize(self.spec(count=1,naming=naming))
        self.assertEqual(result['jobs'][0]['name'],'KCT-款01_800x800_01')
        self.assertTrue(result['jobs'][0]['_delivery']['psd_path'].endswith('KCT-款01_800x800.psd'))
        self.assertFalse(result['jobs'][0]['_delivery']['psd_path'].endswith('.psd.psd'))

    def test_matching_png_extension_is_removed(self):
        naming={'image':'{original_stem}_{size}.png','psd':'{style_id}_{size}.psd'}
        result=self.normalize(self.spec(kind='scene',count=1,naming=naming,format='png'))
        self.assertEqual(result['jobs'][0]['name'],'原图1_800x800')
        self.assertEqual(result['jobs'][0]['format'],'png')

    def test_conflicting_explicit_extensions_are_rejected(self):
        for image,psd in [('{style_id}_{size}_{index}.png','{style_id}_{size}.psd'),
                          ('{style_id}_{size}_{index}.jpg','{style_id}_{size}.jpg'),
                          ('{style_id}_{size}_{index}.webp','{style_id}_{size}.psd'),
                          ('{style_id}_{size}_{index}.wrong','{style_id}_{size}.psd')]:
            with self.subTest(image=image,psd=psd),self.assertRaises(ValueError):
                self.normalize(self.spec(count=1,naming={'image':image,'psd':psd}))

    def test_job_format_conflict_is_not_hidden_by_policy_default(self):
        spec=self.spec(count=1,naming={'image':'{style_id}_{size}_{index}.jpg','psd':'{style_id}_{size}.psd'})
        spec['jobs'][0]['format']='png'
        with self.assertRaisesRegex(ValueError,'不匹配'):self.normalize(spec)

    def test_dot_within_style_id_is_not_treated_as_template_extension(self):
        result=self.normalize(self.spec(count=1,style_id='KCT.01',naming='style_size_index'))
        self.assertEqual(result['jobs'][0]['name'],'KCT.01_800x800_1')

    def test_missing_format_keeps_png_output_and_original_alpha(self):
        source=self.root/'原有半透明.PNG'
        image=Image.new('RGBA',(8,8),(40,80,120,128));image.putpixel((0,0),(0,0,0,0));image.save(source)
        original=source.read_bytes()
        spec=self.spec(kind='scene',count=1,sizes=['800x800']);spec['jobs'][0]['input']=str(source)
        result=self.normalize(spec);job=result['jobs'][0]
        self.assertEqual(result['policy']['format'],'png');self.assertEqual(job['format'],'png')
        self.assertEqual(job['_delivery']['format_source'],'input_suffix')
        self.assertFalse(job['_delivery']['format_explicit'])
        with Image.open(source) as unchanged:
            self.assertEqual(unchanged.mode,'RGBA');self.assertEqual(unchanged.getchannel('A').getextrema(),(0,128))
        self.assertEqual(source.read_bytes(),original);self.assertFalse(self.output.exists())

    def test_missing_format_keeps_jpg_and_jpeg_as_jpg(self):
        spec=self.spec(kind='scene',count=2,sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'源图1.JPG');spec['jobs'][1]['input']=str(self.root/'源图2.JPEG')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['format'],'jpg')
        self.assertTrue(all(j['format']=='jpg' and not j['_delivery']['format_explicit'] for j in result['jobs']))

    def test_psd_without_export_format_keeps_main_jpg_default(self):
        result=self.normalize(self.spec(count=1,sizes=['800x800']))
        self.assertEqual(result['policy']['format'],'jpg');self.assertEqual(result['jobs'][0]['format'],'jpg')
        self.assertEqual(result['jobs'][0]['_delivery']['format_source'],'psd_default')
        self.assertFalse(result['jobs'][0]['_delivery']['format_explicit'])

    def test_explicit_delivery_jpg_overrides_png_with_recorded_selection(self):
        spec=self.spec(kind='scene',count=1,format='jpg',sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'原有透明.png')
        result=self.normalize(spec);job=result['jobs'][0]
        self.assertEqual(result['policy']['format'],'jpg');self.assertEqual(job['format'],'jpg')
        self.assertEqual(job['_delivery']['format_source'],'delivery');self.assertTrue(job['_delivery']['format_explicit'])

    def test_explicit_job_jpg_has_precedence_over_delivery_png(self):
        spec=self.spec(kind='scene',count=1,format='png',sizes=['800x800'])
        spec['jobs'][0].update(input=str(self.root/'原有透明.png'),format='jpg')
        result=self.normalize(spec);job=result['jobs'][0]
        self.assertEqual(result['policy']['format'],'jpg');self.assertEqual(job['format'],'jpg')
        self.assertEqual(job['_delivery']['format_source'],'job');self.assertTrue(job['_delivery']['format_explicit'])

    def test_mixed_png_and_jpg_same_stem_use_distinct_source_extensions(self):
        spec=self.spec(kind='scene',count=2,naming='original',sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'a/同名.png');spec['jobs'][1]['input']=str(self.root/'b/同名.jpg')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['format'],'source')
        self.assertEqual([j['format'] for j in result['jobs']],['png','jpg'])
        self.assertEqual([j['name'] for j in result['jobs']],['同名','同名'])
        paths={str(Path(j['out_dir'])/(j['name']+'.'+j['format'])) for j in result['jobs']}
        self.assertEqual(len(paths),2)

    def test_explicit_jpg_can_make_mixed_same_stems_collide(self):
        spec=self.spec(kind='scene',count=2,naming='original',format='jpg',sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'a/同名.png');spec['jobs'][1]['input']=str(self.root/'b/同名.jpg')
        with self.assertRaisesRegex(ValueError,'重复生成路径'):self.normalize(spec)

    def test_mixed_input_extensions_reject_a_single_wrong_suffix_template(self):
        for suffix in ['jpg','png']:
            naming={'image':'{style_id}_{size}_{index}.'+suffix,'psd':'{style_id}_{size}.psd'}
            spec=self.spec(kind='scene',count=2,naming=naming,sizes=['800x800'])
            spec['jobs'][0]['input']=str(self.root/'source.jpg');spec['jobs'][1]['input']=str(self.root/'source.png')
            with self.subTest(suffix=suffix),self.assertRaisesRegex(ValueError,'不匹配'):self.normalize(spec)

    def test_explicit_format_and_matching_template_can_unify_mixed_inputs(self):
        naming={'image':'{style_id}_{size}_{index}.jpg','psd':'{style_id}_{size}.psd'}
        spec=self.spec(kind='scene',count=2,format='jpg',naming=naming,sizes=['800x800'])
        spec['jobs'][0]['input']=str(self.root/'source.jpg');spec['jobs'][1]['input']=str(self.root/'source.png')
        result=self.normalize(spec)
        self.assertEqual(result['policy']['format'],'jpg')
        self.assertTrue(all(j['format']=='jpg' and j['_delivery']['format_explicit'] for j in result['jobs']))


if __name__ == '__main__':
    unittest.main(verbosity=2)
