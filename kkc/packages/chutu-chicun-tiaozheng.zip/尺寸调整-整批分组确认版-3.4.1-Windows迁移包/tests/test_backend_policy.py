import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

PACKAGE=Path(os.environ.get('RESIZE_TEST_SKILL',Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng'))
sys.path.insert(0,str(PACKAGE/'scripts'))
from backend_policy import BackendChoiceRequired, assess_risk, make_choice, resolve_backend


class BackendPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='backend-policy-')
        self.root=Path(self.temp.name).resolve()
        self.source=self.root/'source.psd';self.source.write_bytes(b'isolated source fixture; hashing only')
        self.job={'input':str(self.source),'size':'1440x1440'}
        self.plan={'source_size':[800,800],'output_size':[1440,1440],
                   'source_domain_px':[0,0,800,800],'source_viewport_px':[0,0,800,800],'effective_fit':'cover'}

    def tearDown(self):self.temp.cleanup()

    def selected(self,backend='python',confirmation='本张用Python，放大显软风险已知'):
        job=copy.deepcopy(self.job);job['_backend_choice']=make_choice(job,self.plan,backend,confirmation)
        return job

    def test_800_to_1440_requires_choice_at_scale_1_8(self):
        report=assess_risk(self.job,self.plan)
        self.assertAlmostEqual(report['scale'],1.8);self.assertTrue(report['risk']);self.assertTrue(report['needs_choice'])
        with self.assertRaises(BackendChoiceRequired) as caught:resolve_backend(self.job,self.plan)
        self.assertEqual(caught.exception.report['basis_digest'],report['basis_digest'])
        self.assertIsNone(caught.exception.report['backend'])

    def test_800_to_800_defaults_to_python_without_human_approval(self):
        self.plan['output_size']=[800,800]
        report=resolve_backend(self.job,self.plan)
        self.assertEqual(report['backend'],'python');self.assertEqual(report['selection'],'default')
        self.assertFalse(report['choice_valid']);self.assertFalse(report['needs_choice']);self.assertFalse(report['risk'])
        self.assertIsNone(report['confirmation'])

    def test_800_source_viewport_600x800_to_750x1000_is_1_25(self):
        self.plan.update(source_viewport_px=[100,0,700,800],output_size=[750,1000])
        self.assertAlmostEqual(assess_risk(self.job,self.plan)['scale'],1.25)
        with self.assertRaises(BackendChoiceRequired):resolve_backend(self.job,self.plan)

    def test_custom_2000_to_1440_does_not_depend_on_1440_label(self):
        self.plan.update(source_size=[2000,2000],source_domain_px=[0,0,2000,2000],source_viewport_px=[0,0,2000,2000])
        report=resolve_backend(self.job,self.plan)
        self.assertEqual(report['backend'],'python');self.assertFalse(report['risk']);self.assertAlmostEqual(report['scale'],.72)

    def test_crop_1000_source_to_600_viewport_then_800_is_upscale(self):
        self.plan.update(source_size=[1000,1000],source_domain_px=[0,0,1000,1000],
                         source_viewport_px=[200,200,800,800],output_size=[800,800])
        self.assertAlmostEqual(assess_risk(self.job,self.plan)['scale'],4/3)
        with self.assertRaises(BackendChoiceRequired):resolve_backend(self.job,self.plan)

    def test_python_human_selection_resolves_upscale(self):
        report=resolve_backend(self.selected(),self.plan)
        self.assertEqual(report['backend'],'python');self.assertTrue(report['choice_valid']);self.assertFalse(report['needs_choice'])
        self.assertTrue(report['risk']);self.assertEqual(report['selection'],'human')

    def test_photoshop_human_selection_resolves_upscale(self):
        report=resolve_backend(self.selected('photoshop','本张选PS'),self.plan)
        self.assertEqual(report['backend'],'photoshop');self.assertEqual(report['confirmation'],'本张选PS')
        self.assertIn('不能凭空恢复',report['detail_notice'])

    def test_non_upscale_still_allows_explicit_photoshop(self):
        self.plan['output_size']=[800,800]
        report=resolve_backend(self.selected('photoshop','这张即使不放大也用PS'),self.plan)
        self.assertEqual(report['backend'],'photoshop');self.assertTrue(report['choice_valid']);self.assertFalse(report['risk'])

    def test_empty_or_non_string_confirmation_is_never_accepted(self):
        for text in ['', ' \n\t', None, True, 42]:
            with self.subTest(text=text),self.assertRaises(ValueError):make_choice(self.job,self.plan,'python',text)
            choice={'backend':'python','confirmation':text,'basis_digest':assess_risk(self.job,self.plan)['basis_digest']}
            with self.subTest(resolve_text=text),self.assertRaises(BackendChoiceRequired):
                resolve_backend({**self.job,'_backend_choice':choice},self.plan)

    def test_default_python_label_is_not_a_human_approval(self):
        for choice in [None, {'backend':'python'}, {'backend':'python','basis_digest':assess_risk(self.job,self.plan)['basis_digest']}]:
            with self.subTest(choice=choice),self.assertRaises(BackendChoiceRequired):
                resolve_backend({**self.job,'_backend_choice':choice},self.plan)

    def test_changed_input_hash_invalidates_previous_selection(self):
        job=self.selected();self.source.write_bytes(b'new source contents')
        with self.assertRaises(BackendChoiceRequired) as caught:resolve_backend(job,self.plan)
        self.assertIn('失效',str(caught.exception));self.assertFalse(caught.exception.report['choice_valid'])

    def test_different_input_path_even_with_identical_content_invalidates_choice(self):
        job=self.selected();other=self.root/'other.psd';other.write_bytes(self.source.read_bytes());job['input']=str(other)
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_viewport_change_invalidates_previous_selection(self):
        job=self.selected();self.plan['source_viewport_px']=[50,50,750,750]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_domain_change_invalidates_selection_even_when_viewport_is_same(self):
        job=self.selected();self.plan['source_domain_px']=[10,10,790,790]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_target_size_change_invalidates_selection(self):
        job=self.selected();self.plan['output_size']=[1200,1200]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_source_size_change_invalidates_selection(self):
        job=self.selected();self.plan['source_size']=[900,900]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_effective_fit_change_invalidates_selection(self):
        job=self.selected();self.plan['effective_fit']='subject'
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_delivery_row_scope_cannot_leak_to_another_job(self):
        self.job['_delivery']={'style_id':'A','kind':'main','index':1}
        job=self.selected();job['_delivery']['index']=2
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_psd_source_layer_selection_change_invalidates_choice(self):
        self.job['source_layers']=[1,3]
        job=self.selected();job['source_layers']=[1,4]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_explicit_psd_layer_selection_binds_without_changing_geometry(self):
        job=self.selected();job['source_layers']=[1]
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_backend_choice_itself_is_not_in_basis_digest(self):
        digest=assess_risk(self.job,self.plan)['basis_digest']
        job=self.selected();job['_backend_choice']['confirmation']='本次切换PS'
        job['_backend_choice']['backend']='photoshop'
        self.assertEqual(assess_risk(job,self.plan)['basis_digest'],digest)
        self.assertEqual(resolve_backend(job,self.plan)['backend'],'photoshop')

    def test_scope_is_current_input_and_size_only(self):
        report=resolve_backend(self.selected(),self.plan)
        self.assertEqual(report['scope']['kind'],'current_job_and_size')
        self.assertEqual(report['scope']['input'],str(self.source));self.assertEqual(report['scope']['size'],'1440x1440')
        self.assertNotIn('long_term',report['scope'])

    def test_original_confirmation_text_is_preserved_exactly(self):
        text='  当前图片选 Python。\n保留这段实际原文。  '
        job=self.selected(confirmation=text)
        self.assertEqual(job['_backend_choice']['confirmation'],text)
        self.assertEqual(resolve_backend(job,self.plan)['confirmation'],text)

    def test_invalid_backend_and_forged_scope_are_rejected(self):
        with self.assertRaises(ValueError):make_choice(self.job,self.plan,'automatic','同意')
        job=self.selected();job['_backend_choice']['scope']['size']='all future sizes'
        with self.assertRaises(BackendChoiceRequired):resolve_backend(job,self.plan)

    def test_report_lists_geometry_two_options_and_detail_limit(self):
        report=assess_risk(self.job,self.plan)
        self.assertEqual(report['source_size'],[800,800]);self.assertEqual(report['viewport_size'],[800.,800.])
        self.assertEqual(report['target_size'],[1440,1440]);self.assertEqual(len(report['basis_digest']),64)
        self.assertEqual({o['backend'] for o in report['options']},{'python','photoshop'})
        self.assertIn('不能凭空恢复',report['detail_notice']);json.dumps(report,ensure_ascii=False,allow_nan=False)

    def test_anisotropic_risk_uses_maximum_axis_scale(self):
        self.plan.update(output_size=[800,500],source_viewport_px=[0,0,400,1000])
        self.assertAlmostEqual(assess_risk(self.job,self.plan)['scale'],2.)

    def test_tiny_numeric_noise_is_not_treated_as_upscale(self):
        self.plan.update(output_size=[800,800],source_viewport_px=[0,0,799.9999,800])
        self.assertFalse(assess_risk(self.job,self.plan)['risk'])

    def test_integer_and_float_box_coordinates_have_stable_digest(self):
        first=assess_risk(self.job,self.plan)['basis_digest']
        self.plan['source_domain_px']=[0.,0.,800.,800.];self.plan['source_viewport_px']=[0.,0.,800.,800.]
        self.assertEqual(assess_risk(self.job,self.plan)['basis_digest'],first)

    def test_bad_geometry_and_missing_input_are_rejected(self):
        for field,value in [('source_size',[0,800]),('output_size',[True,800]),
                            ('source_viewport_px',[0,0,0,800]),('source_domain_px',[0,0,float('nan'),800])]:
            plan=copy.deepcopy(self.plan);plan[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):assess_risk(self.job,plan)
        with self.assertRaises(ValueError):assess_risk({'input':str(self.root/'missing.psd')},self.plan)

    def test_assessment_and_resolution_never_mutate_job_plan_or_files(self):
        job=self.selected();old_job=copy.deepcopy(job);old_plan=copy.deepcopy(self.plan)
        paths=set(self.root.iterdir());before=self.source.read_bytes()
        assess_risk(job,self.plan);resolve_backend(job,self.plan)
        self.assertEqual(job,old_job);self.assertEqual(self.plan,old_plan)
        self.assertEqual(set(self.root.iterdir()),paths);self.assertEqual(self.source.read_bytes(),before)


if __name__=='__main__':unittest.main(verbosity=2)
