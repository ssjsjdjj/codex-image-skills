"""Main photo delivery and choice gating in an explicitly isolated test account."""
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
from psd_tools import PSDImage

from test_delivery_flow import DeliveryFlowTests
from backend_policy import make_choice, resolve_backend
import user_profile as profile


class MainPhotoUpdateTests(unittest.TestCase):
    def setUp(self):
        self.flow = DeliveryFlowTests(methodName='runTest')
        self.flow.setUp()

    def tearDown(self):
        self.flow.tearDown()

    def start(self, paths, sizes):
        f = self.flow
        spec = f.task(paths, sizes=sizes, kind='main', naming='numbered')
        spec['delivery'].pop('format')
        profile.write_json(f.spec_path, spec)
        return f.queue.start(f.spec_path)['review_id']

    def finish(self, rid):
        f = self.flow
        preview = f.queue.preview_all(rid)
        self.assertFalse(preview['requires_backend_choice'])
        self.assertFalse((f.output/'图片').exists())
        f.queue.confirm_all(rid, preview['batch_digest'], '隔离测试模拟整批预览确认；不授权业务图片')
        f.batch(rid)
        self.assertEqual(f.record(rid)['status'], 'completed')
        return preview

    def test_main_five_jpgs_three_real_sizes_deliver_15_images_and_3_psds(self):
        f = self.flow
        paths = []
        for index in range(5):
            path = f.sources/f'photo-{index+1}.jpg'
            Image.new('RGB', (1600, 2000), (30+index*30, 90, 180)).save(path, quality=96)
            paths.append(path)
        hashes = {str(path): profile.file_hash(path) for path in paths}
        sizes = ['800x800', '1440x1440', '750x1000']
        rid = self.start(paths, sizes)
        preview = self.finish(rid)
        self.assertEqual(len(preview['groups']), 3)
        self.assertEqual(len(list((f.output/'图片').rglob('*.jpg'))), 15)
        self.assertEqual(len(list((f.output/'源文件').glob('*.psd'))), 3)
        for size in sizes:
            expected = tuple(map(int, size.split('x')))
            for index in range(1, 6):
                path = f.output/'图片'/size/f'{index}.jpg'
                with Image.open(path) as image:
                    self.assertEqual(image.size, expected)
                self.assertLessEqual(path.stat().st_size, 500000)
            f.assert_psd(f.output/'源文件'/f'KCT-FLOW_{size}.psd', expected, 5)
        self.assertEqual(hashes, {str(path): profile.file_hash(path) for path in paths})
        self.assertEqual({path.suffix.lower() for path in f.sources.iterdir()}, {'.jpg'})
        self.assertTrue((f.output/'使用提示词.txt').is_file())
        self.assertTrue((f.output/'本批处理说明.txt').is_file())

    def test_main_png_preserves_alpha_in_final_png_and_psd(self):
        f = self.flow
        paths = f.pictures(count=2, rgba=True)
        rid = self.start(paths, ['64x64', '60x80'])
        self.finish(rid)
        self.assertEqual(list((f.output/'图片').rglob('*.jpg')), [])
        for size in ['64x64', '60x80']:
            doc = PSDImage.open(f.output/'源文件'/f'KCT-FLOW_{size}.psd')
            for index in range(1, 3):
                path = f.output/'图片'/size/f'{index}.png'
                with Image.open(path) as output:
                    self.assertEqual(output.mode, 'RGBA')
                    self.assertLess(output.getchannel('A').getextrema()[0], 255)
                    layer = next(layer for layer in doc if layer.name == str(index))
                    self.assertEqual(layer.topil(apply_icc=False).convert('RGBA').tobytes(), output.tobytes())
                self.assertLessEqual(path.stat().st_size, 500000)

    def test_main_800_to_1440_recommends_ps_without_choosing_it(self):
        f = self.flow
        source = f.sources/'800.jpg'
        Image.new('RGB', (800, 800), 'navy').save(source)
        rid = self.start([source], ['800x800', '1440x1440'])
        with patch.object(f.engine, '_render', side_effect=AssertionError('no target pixels before choice')) as render:
            result = f.queue.preview_all(rid)
        render.assert_not_called()
        self.assertTrue(result['requires_backend_choice'])
        self.assertFalse(f.output.exists())
        self.assertEqual(len(result['risks']), 1)
        risk = result['risks'][0]['risk']
        self.assertAlmostEqual(risk['scale'], 1.8)
        self.assertIn('变软', risk['message'])
        self.assertIn('建议使用Photoshop', risk['message'])
        self.assertIn('Python', risk['message'])
        self.assertIsNone(risk['backend'])
        record = f.queue.load(rid)
        item = record['items'][result['risks'][0]['index']-1]
        analysis = f.engine.processing_plan(item['job'], require_choice=False)
        ps_job = dict(item['job'])
        ps_job['_backend_choice'] = make_choice(ps_job, analysis['plan'], 'photoshop',
                                                '隔离测试模拟选PS；不调用本机PS、不授权业务图片')
        self.assertEqual(resolve_backend(ps_job, analysis['plan'])['backend'], 'photoshop')
        selection = f.queue.select_backend(rid, 'python', '隔离测试模拟本项继续Python，接受显软风险',
                                          indices=[result['risks'][0]['index']])
        self.assertEqual(selection['choices'][0]['backend'], 'python')
        self.finish(rid)
        record = f.record(rid)
        self.assertEqual(record['items'][0]['source_metadata']['processing']['choice_source'], 'default_python')
        self.assertEqual(record['items'][1]['source_metadata']['processing']['choice_source'], 'human')
        self.assertEqual(record['items'][1]['source_metadata']['processing']['backend'], 'python')


if __name__ == '__main__':
    unittest.main(verbosity=2)
