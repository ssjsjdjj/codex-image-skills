import os
import tempfile
import unittest
from pathlib import Path

from PIL import Image
from test_workflow import snapshot_at
import user_profile as profile
from validate_candidate import validate_snapshot


class RuleContextTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='resize-rule-context-')
        self.root=Path(self.temp.name)
        seed=snapshot_at(self.root/'seed')
        self.store=profile.Store(self.root/'state')
        self.revision=self.store.initialize(seed,'隔离测试规则批准',validate_snapshot(seed,self.root/'previews'))
        self.source=self.root/'source.png';Image.new('RGB',(80,120),'blue').save(self.source)

    def tearDown(self):self.temp.cleanup()

    def feedback(self,kind,category='裤子',scope='general',text='下方保留自然距离'):
        bid=self.store.begin_batch([{'input':str(self.source),'size':'80x80'}],self.revision,
                                   context={'image_kind':kind,'category':category})
        self.store.update_batch(bid,complete=True)
        return self.store.feedback(bid,text,'natural_margin',scope)

    def test_scene_and_main_do_not_share_repeat_threshold(self):
        self.assertEqual(self.feedback('main')['distinct_batches'],1)
        self.assertEqual(self.feedback('scene')['distinct_batches'],1)
        self.assertEqual(self.feedback('main')['distinct_batches'],2)
        self.assertFalse(self.feedback('scene')['eligible'])
        result=self.feedback('main');self.assertTrue(result['eligible'])
        directory,_=self.store.proposal(result['proposal']['id'])
        prompt=(directory/'candidate/personal_prompt.md').read_text(encoding='utf-8')
        self.assertIn('用途 main',prompt);self.assertIn('品类 裤子',prompt)
        self.assertEqual(self.store.active()[0],self.revision)

    def test_product_categories_are_separate_evidence(self):
        self.feedback('scene','帽子');self.feedback('scene','裤子')
        self.assertEqual(self.feedback('scene','帽子')['distinct_batches'],2)
        self.assertEqual(self.feedback('scene','裤子')['distinct_batches'],2)
        self.assertEqual(self.store.proposals(),[])

    def test_satisfied_batch_does_not_generate_long_term_rule(self):
        result=self.feedback('scene',scope='once',text='满意')
        self.assertFalse(result['eligible']);self.assertEqual(self.store.proposals(),[])
        self.assertEqual(self.store.active()[0],self.revision)

    def test_explicit_long_term_still_requires_approval(self):
        result=self.feedback('main',scope='long_term',text='以后主图的商品下方都留自然距离')
        self.assertTrue(result['eligible']);self.assertEqual(result['proposal']['status'],'pending')
        self.assertEqual(self.store.active()[0],self.revision)
