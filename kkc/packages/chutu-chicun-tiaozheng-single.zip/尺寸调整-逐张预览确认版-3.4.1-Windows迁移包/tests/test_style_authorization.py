import json
import tempfile
import unittest
from pathlib import Path

from PIL import Image
import user_profile as profile
from test_workflow import snapshot_at
from review_queue import ReviewQueue
from validate_candidate import load_engine,validate_snapshot,source_size,source_preview,assert_render


class StyleAuthorizationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='resize-style-authorization-')
        self.root=Path(self.temp.name)
        seed=snapshot_at(self.root/'seed');self.store=profile.Store(self.root/'state')
        self.revision=self.store.initialize(seed,'隔离测试批准',validate_snapshot(seed,self.root/'validate'))
        self.queue=ReviewQueue(self.store,load_engine(seed))
        source=self.root/'source.png';Image.new('RGB',(80,120),'blue').save(source)
        spec=self.root/'jobs.json'
        profile.write_json(spec,{'delivery':{'kind':'scene','style_id':'STYLE','out_dir':str(self.root/'out'),
                                             'sizes':['64x64'],'naming':'style_size_index','format':'png'},
                                 'jobs':[{'input':str(source)} for _ in range(4)]})
        self.rid=self.queue.start(spec)['review_id']

    def tearDown(self):self.temp.cleanup()

    def test_no_authorization_without_reference_preview(self):
        with self.assertRaises(ValueError):self.queue.authorize_style(self.rid,'按这个风格继续',1)

    def test_authorization_records_scope_without_auto_approving(self):
        first=self.queue.next(self.rid)
        a=self.queue.authorize_style(self.rid,'后两张按这个风格做',1,2,3)
        record=self.queue.load(self.rid)
        self.assertEqual([i['status'] for i in record['items']],['previewed','pending','pending','pending'])
        self.assertEqual(record['style_authorizations'][0]['reference_digest'],first['digest'])
        self.assertEqual([i['candidate'] for i in record['style_authorizations'][0]['scope']],[2,3])
        self.assertEqual(a['from_candidate'],2)

    def test_scoped_style_does_not_claim_individual_human_viewing(self):
        first=self.queue.next(self.rid)
        self.queue.authorize_style(self.rid,'第2第3候选按这个风格',1,2,3)
        self.queue.confirm(self.rid,first['digest'],'第一张确认')
        for _ in range(2):
            current=self.queue.next(self.rid);self.queue.confirm(self.rid,current['digest'],'第2第3候选按这个风格')
        record=self.queue.load(self.rid)
        self.assertEqual(record['items'][0]['confirmation_kind'],'human_current_preview_confirmation')
        self.assertEqual(record['items'][1]['confirmation_kind'],'human_batch_style_delegation')
        self.assertEqual(record['items'][2]['confirmation_kind'],'human_batch_style_delegation')
        current=self.queue.next(self.rid)
        with self.assertRaises(ValueError):self.queue.confirm(self.rid,current['digest'],'第2第3候选按这个风格')
        self.assertEqual(self.store.status()['revision'],self.revision)

    def test_changing_reference_invalidates_delegation(self):
        first=self.queue.next(self.rid);self.queue.authorize_style(self.rid,'后续沿用',1,2,4)
        changed=self.queue.adjust(self.rid,{'focus':[.5,.4]})
        self.assertNotEqual(changed['digest'],first['digest'])
        self.queue.confirm(self.rid,changed['digest'],'当前新预览确认')
        current=self.queue.next(self.rid)
        with self.assertRaises(ValueError):self.queue.confirm(self.rid,current['digest'],'后续沿用')

    def test_empty_or_out_of_range_authorization_rejected(self):
        self.queue.next(self.rid)
        for text,reference,start,end in [('',1,1,4),('继续',5,1,4),('继续',1,0,4),('继续',1,1,5),('继续',1,3,2)]:
            with self.subTest(text=text,start=start),self.assertRaises(ValueError):
                self.queue.authorize_style(self.rid,text,reference,start,end)


class PSDPreviewDepthTests(unittest.TestCase):
    def test_sixteen_bit_source_dimensions_and_preview_do_not_depend_on_pillow_psd_loader(self):
        from psd_tools import PSDImage
        from psd_tools.api.layers import PixelLayer
        with tempfile.TemporaryDirectory(prefix='resize-depth16-') as directory:
            path=Path(directory)/'source.psd'
            document=PSDImage.new('RGB',(80,80),depth=16)
            PixelLayer.frompil(Image.new('RGB',(80,80),'red'),document,'test',0,0)
            document.save(path)
            self.assertEqual(source_size(path),(80,80))
            with source_preview(path) as preview:self.assertEqual(preview.size,(80,80))
            plan={'source_size':[80,80],'source_domain_px':[0,0,80,80],'source_viewport_px':[0,0,80,80]}
            assert_render(Image.new('RGB',(64,64)),plan,{'input':str(path),'size':'64x64'})
