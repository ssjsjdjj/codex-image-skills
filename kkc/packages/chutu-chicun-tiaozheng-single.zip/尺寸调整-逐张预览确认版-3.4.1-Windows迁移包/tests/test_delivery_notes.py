import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = Path(os.environ.get("RESIZE_TEST_SKILL", ROOT / "skills/chutu-chicun-tiaozheng-single"))
sys.path.insert(0, str(PACKAGE / "scripts"))
from delivery_notes import write_notes


class DeliveryNotesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="delivery-notes-test-")
        self.root = Path(self.temp.name) / "包"
        self.root.mkdir()
        self.image = self.root / "图片/800x800/款号A_800x800_1.jpg"
        self.image.parent.mkdir(parents=True)
        Image.new("RGB", (80, 80), "blue").save(self.image, quality=83)
        self.psd = self.root / "源文件/款号A_800x800.psd"
        self.psd.parent.mkdir()
        self.psd.write_bytes(b"not-a-real-PSD-recorded-without-fabricated-validation")
        self.policy = {"style_id":"款号A", "kind":"main", "sizes":["800x800"],
                       "naming":{"image":"{style_id}_{size}_{index}","psd":"{style_id}_{size}"},
                       "source_type":"image", "format":"jpg", "max_bytes":500000,
                       "out_dir":str(self.root)}
        self.jobs = [{"input":"D:/原图/照片01.jpg", "size":"800x800", "name":"款号A_800x800_1",
                      "_delivery":{"psd_path":str(self.psd)}}]
        self.record = {"id":"b-test", "status":"pending", "items":[{
            "status":"completed", "outputs":[str(self.image)],
            "encoding":{"format":"jpg", "bytes":self.image.stat().st_size,"quality":83,"max_bytes":500000}}],
            "grouped_psds":{str(self.psd):{"status":"completed","outputs":[str(self.psd)],
                "size":[800,800],"layer_names":["1"],"metadata":{"verified":True,"layer_count":1}}}}

    def tearDown(self):
        self.temp.cleanup()

    def write(self, **kwargs):
        return write_notes(self.root, policy=self.policy, jobs=self.jobs, batch_record=self.record, **kwargs)

    def text(self):
        return (self.root/"本批处理说明.txt").read_text(encoding="utf-8")

    def test_creates_two_root_documents_with_reusable_call_template(self):
        paths = self.write()
        self.assertEqual([Path(path).name for path in paths], ["使用提示词.txt","本批处理说明.txt"])
        template = Path(paths[0]).read_text(encoding="utf-8")
        for text in ("主图/场景", "800×800", "1440×1440", "750×1000", "800×1200", "其他尺寸", "多选",
                     "人工", "图片命名", "PSD命名", "500000", "每款", "1份PSD", "1—N",
                     "review_mode=individual", "逐张", "白底图不纳入"):
            self.assertIn(text, template)

    def test_records_actual_single_selected_size_instead_of_all_defaults(self):
        self.write(); report = self.text()
        self.assertIn('"800x800"', report)
        self.assertNotIn("1440x1440", report)
        self.assertNotIn("750x1000", report)
        for text in ("款号A", '"main"', "source_type", '"image"', "{style_id}_{size}_{index}", "照片01.jpg",
                     self.psd.name, str(self.image), "83", str(self.image.stat().st_size)):
            self.assertIn(text, report)

    def test_pending_batch_is_not_promoted_despite_completed_psd(self):
        self.write(); report = self.text()
        self.assertIn("记录时批次状态：pending", report)
        self.assertIn("grouped_psds记录数量：1", report)
        self.assertIn("其中记录completed数量：1", report)
        self.assertIn("PSD图层/组名称", report)
        self.assertNotIn("整批完成：通过", report)
        self.assertIn("不代表恢复原生文字", report)

    def test_identical_repeat_reuses_without_rewriting(self):
        paths = self.write()
        before = [(Path(path).read_bytes(),Path(path).stat().st_mtime_ns) for path in paths]
        self.assertEqual(paths, self.write())
        self.assertEqual(before, [(Path(path).read_bytes(),Path(path).stat().st_mtime_ns) for path in paths])

    def test_conflict_never_overwrites_and_preflights_both_documents(self):
        existing = self.root/"本批处理说明.txt"; existing.write_text("keep original",encoding="utf-8")
        with self.assertRaises(FileExistsError):self.write()
        self.assertEqual(existing.read_text(encoding="utf-8"),"keep original")
        self.assertFalse((self.root/"使用提示词.txt").exists())

    def test_changed_status_conflicts_instead_of_silently_updating(self):
        self.write(); original = self.text(); self.record["status"] = "completed"
        with self.assertRaises(FileExistsError):self.write()
        self.assertEqual(self.text(), original)

    def test_partial_failure_and_group_failure_are_factual(self):
        self.record.update(status="partial", error="第三张编码超预算", group_failures=["第二尺寸PSD缺失"])
        self.record["items"][0].update(status="partial",error="图片保留，PSD失败")
        self.record["grouped_psds"][str(self.psd)].update(status="failed",error="无法创建第二层")
        self.write(); report = self.text()
        for text in ("记录时批次状态：partial", "第三张编码超预算", "图片保留，PSD失败", "无法创建第二层", "第二尺寸PSD缺失"):
            self.assertIn(text, report)
        self.assertIn("其中记录completed数量：0", report)

    def test_source_psd_without_metadata_does_not_claim_layer_retention(self):
        self.policy["source_type"]="psd"; self.jobs[0]["input"]="D:/素材/原生01.psd"
        self.write(); report=self.text()
        self.assertIn("原生01.psd",report)
        self.assertIn("源质量风险",report)
        self.assertIn("未执行源质量及原层专项验收",report)
        self.assertIn("未声明通过",report)
        self.assertNotIn("通过（记录为true）",report)

    def test_native_psd_records_top_and_item_metadata_with_explicit_results(self):
        self.policy["source_type"]="psd"
        self.record["source_metadata"]={"quality_risk":"源图低分辨率需放大","original_layers_preserved":False}
        self.record["items"][0]["source_metadata"]={"source_layers_preserved":True,"layer_names":["文字","商品"]}
        self.write(); report=self.text()
        for text in ("源图低分辨率需放大", "文字", "商品", "未通过（记录为false）", "通过（记录为true）"):
            self.assertIn(text,report)

    def test_native_structure_backend_marker_is_reported_with_limited_scope(self):
        self.policy["source_type"]="psd"
        self.record["items"][0]["source_metadata"]={"native_structure_verified":True}
        self.write(); report=self.text()
        self.assertIn("native_structure_verified：通过（记录为true）",report)
        self.assertIn("结构核验不等于全部素材可编辑或放大后清晰",report)
        self.assertNotIn("未提供明确的原层保留专项标记",report)

    def test_unexecuted_checks_and_missing_outputs_are_not_passed(self):
        self.image.unlink(); self.record["items"][0].pop("encoding")
        self.write(); report=self.text()
        self.assertIn("编码记录bytes：未提供",report)
        self.assertIn("编码记录quality：未记录",report)
        self.assertIn("缺失或不是普通文件；未验收通过",report)

    def test_actual_oversized_image_is_reported_even_if_record_completed(self):
        self.image.write_bytes(b"x"*500001)
        self.write(); report=self.text()
        self.assertIn("实际文件字节：500001",report)
        self.assertIn("超出本批预算",report)
        self.assertIn("图片重开检查异常",report)

    def test_psd_and_notes_do_not_receive_image_cap(self):
        self.psd.write_bytes(b"p"*600000)
        self.record["source_metadata"]={"description":"说明内容"*150000}
        self.write(); report=self.text()
        self.assertIn("实际文件字节：600000",report)
        self.assertIn("非图片交付项，不套用500KB图片限制",report)
        self.assertGreater((self.root/"本批处理说明.txt").stat().st_size,500000)

    def test_other_account_and_feedback_fields_are_not_copied(self):
        self.policy["owner_id"]="unrelated-private-owner"
        self.record["feedback"]="another account private feedback"
        self.record["source_metadata"]={"quality_risk":"keep","owner_id":"unrelated-private-owner"}
        self.write(); report=self.text()
        self.assertNotIn("unrelated-private-owner",report)
        self.assertNotIn("another account private feedback",report)
        self.assertIn("keep",report)

    def test_optional_engine_publisher_is_supported(self):
        called=[]
        def publish(path, writer):
            called.append(path)
            if Path(path).exists():raise FileExistsError(path)
            writer(path)
        self.write(engine=SimpleNamespace(publish_new=publish))
        self.assertEqual(len(called),2)

    def test_manual_custom_size_and_png_quality_none_are_recorded(self):
        self.policy.update(sizes=["1200x1600","800x800"],kind="scene",naming="original")
        self.record["items"][0]["encoding"]={"format":"png","quality":None,"bytes":321,"max_bytes":500000}
        self.write();report=self.text()
        self.assertIn("1200x1600",report)
        self.assertIn('"scene"',report)
        self.assertIn("PNG质量参数不适用",report)

    def test_invalid_input_types_do_not_create_documents(self):
        cases=[{"policy":[]},{"jobs":[1]},{"batch_record":[]}]
        for change in cases:
            kwargs={"policy":self.policy,"jobs":self.jobs,"batch_record":self.record};kwargs.update(change)
            with self.assertRaises(ValueError):write_notes(self.root,**kwargs)
        self.assertFalse((self.root/"使用提示词.txt").exists())

    def test_template_34_distinguishes_batch_review_from_upscale_choice(self):
        self.write()
        template=(self.root/'使用提示词.txt').read_text(encoding='utf-8')
        for text in ('PSD默认用Python', 'source_viewport', 'scale>1', 'requires_backend_choice',
                     '未选前', '不生成该轮任何目标尺寸预览', '不能自动flatten',
                     '不能自动退回Python', 'Photoshop也不保证', '不学成永久自动放大'):
            self.assertIn(text,template)
        self.assertIn('无需再问我填写图片命名',template)
        self.assertIn('每个尺寸从1重新编号',template)
        self.assertNotIn('每批提醒我填写',template)

    def test_actual_python_default_is_not_labeled_human_confirmed(self):
        self.record['items'][0]['processing']={'backend':'python',
            'risk':{'scale':.8,'scale_x':.8,'scale_y':.8,'upscale_risk':False,'basis_digest':'basis-a',
                    'source_viewport_px':[0,0,1000,1000],'target_size':[800,800]},
            'choice':None,'choice_source':'default_python'}
        self.write();report=self.text()
        self.assertIn('实际backend："python"',report)
        self.assertIn('实际scale：0.8',report)
        self.assertIn('选择来源为Python默认；不是本项人工后端确认',report)
        self.assertIn('basis-a',report)
        self.assertIn('任务_backend_choice：未提供',report)

    def test_actual_human_choice_scale_risk_and_basis_are_written(self):
        choice={'backend':'python','confirmation':'这批这个裁切放大到1440用Python','basis_digest':'approved-1440-basis'}
        self.jobs[0]['_backend_choice']=choice
        self.record['items'][0]['processing']={'backend':'python','risk':{'scale':1.8,
            'upscale_risk':True,'source_viewport_px':[0,0,800,800],'target_size':[1440,1440]},
            'choice':choice,'choice_source':'human'}
        self.write();report=self.text()
        for text in ('实际scale：1.8','upscale_risk','source_viewport_px','这批这个裁切放大到1440用Python',
                     'approved-1440-basis','实际choice_source："human"'):
            self.assertIn(text,report)
        self.assertNotIn('选择来源为Python默认；不是本项人工后端确认',report)

    def test_missing_processing_does_not_infer_python_execution(self):
        self.jobs[0]['_backend_choice']={'backend':'python','confirmation':'计划用Python','basis_digest':'planned'}
        self.record['items'][0]['source_metadata']={'backend':'python-pixel-psd','scale':1.8}
        self.write();report=self.text()
        self.assertIn('实际processing：未记录，不能从Python默认规则猜测',report)
        self.assertNotIn('实际backend："python"',report)
        self.assertIn('计划用Python',report)
        self.assertIn('source_metadata.backend标记',report)

    def test_source_metadata_processing_fallback_is_exact_and_sanitized(self):
        self.record['items'][0]['source_metadata']={'backend':'photoshop-native-1','processing':{
            'backend':'photoshop','risk':{'scale':2.0,'basis_digest':'ps-basis','owner_id':'private-old'},
            'choice':{'backend':'photoshop','confirmation':'本批选择PS','basis_digest':'ps-basis'},
            'choice_source':'human'},'owner_id':'private-old'}
        self.write();report=self.text()
        self.assertIn('item.source_metadata.processing',report)
        self.assertIn('实际backend："photoshop"',report)
        self.assertIn('本批选择PS',report)
        self.assertNotIn('private-old',report)

    def test_human_marker_without_actual_choice_does_not_fabricate_text(self):
        self.record['items'][0]['processing']={'backend':'python','risk':{'scale':1.8},'choice_source':'human'}
        self.write();report=self.text()
        self.assertIn('真实选择原文未记录，不补造确认',report)

    def test_batch_grouped_confirmation_preserves_actual_scope_and_text(self):
        self.record.update(review_mode='batch',preview_groups=[
            {'size':'800x800','items':[{'number':1,'index':0,'preview':'previews/800x800/1.jpg'}],
             'overview':'previews/800x800/总览.jpg'}],
            preview_confirmation={'source':'human_batch','confirmation':'本批800方图全部确认',
                'digest':'real-batch-digest','indices':[0]})
        self.write();report=self.text()
        for value in ('review_mode："batch"','previews/800x800/总览.jpg',
                      '本批800方图全部确认','real-batch-digest','human_batch',
                      '不声明人类逐张单独看过','preview_groups实际分尺寸编号与候选映射'):
            self.assertIn(value,report)
        self.assertIn('记录时批次状态：pending',report)
        self.assertNotIn('逐张已确认：通过',report)

    def test_batch_mode_without_confirmation_does_not_claim_human_approval(self):
        self.record.update(review_mode='batch',preview_groups={'800x800':[{'index':0,'number':1}]})
        self.write();report=self.text()
        self.assertIn('preview_confirmation：未记录；不声明本批已获人工整批确认',report)
        self.assertIn('不声明人类逐张单独看过',report)

    def test_actual_scene_presets_size_and_naming_sources_are_configuration(self):
        self.policy.update(kind='scene',presets=['750x1000','800x800','800x1200'],
            size_selections=[{'size':'800x1200','source':'preset'},{'size':'1200x1600','source':'custom'}],
            sizes=['800x1200','1200x1600'],naming='numbered',naming_source='default')
        self.write();report=self.text()
        for value in ('"scene"','800x1200','1200x1600','"custom"','"preset"',
                      '本批naming_source配置来源："default"','"numbered"',
                      '只说明spec配置来源，不等于真人授权或预览确认'):
            self.assertIn(value,report)
        self.assertNotIn('1440x1440',report)

    def test_missing_review_evidence_is_not_inferred_from_defaults(self):
        self.write();report=self.text()
        self.assertIn('未提供有效review_mode',report)
        self.assertIn('preview_groups实际分尺寸编号与候选映射：未提供',report)
        self.assertIn('不声明本批已获人工整批确认',report)

    def test_review_confirmation_privacy_and_legacy_mode_are_preserved(self):
        self.record.update(review_mode='individual',
            preview_confirmation={'confirmation':'仅当前候选','owner_id':'private-review-owner',
                                  'feedback':'private-feedback','digest':'legacy-real'})
        self.write();report=self.text()
        self.assertIn('本批记录为逐张预览确认模式',report)
        self.assertIn('仅当前候选',report)
        self.assertIn('legacy-real',report)
        self.assertNotIn('private-review-owner',report)
        self.assertNotIn('private-feedback',report)


if __name__=="__main__":
    unittest.main(verbosity=2)
