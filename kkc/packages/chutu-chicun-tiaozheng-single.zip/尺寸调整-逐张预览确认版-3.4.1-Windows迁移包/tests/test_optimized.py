import contextlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageDraw, ImageCms
import user_profile as profile
from validate_candidate import assert_render, load_engine, validate_snapshot
from review_queue import ReviewQueue
from task_spec import load_jobs

PACKAGE = Path(os.environ['RESIZE_TEST_SKILL'])
spec = importlib.util.spec_from_file_location('optimized_entry', PACKAGE/'scripts/resize_assets.py')
entry = importlib.util.module_from_spec(spec); spec.loader.exec_module(entry)


class OptimizedTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='resize-optimized-')
        self.root = Path(self.temp.name)
        self.snapshot = self.root/'snapshot'; self.snapshot.mkdir()
        for src, dst in [('renderer.py','renderer.py'), ('settings.example.json','settings.json'),
                         ('personal_prompt.example.md','personal_prompt.md')]:
            shutil.copyfile(PACKAGE/'assets'/src, self.snapshot/dst)
        report=validate_snapshot(self.snapshot, self.root/'validation'); self.assertTrue(report['passed'], report)
        self.store=profile.Store(self.root/'state')
        self.revision=self.store.initialize(self.snapshot,'隔离测试批准；不授权正式账号',report)
        self.engine=load_engine(self.snapshot)
        self.queue=ReviewQueue(self.store,self.engine)
        self.source=self.root/'原图.png'
        im=Image.new('RGBA',(240,400),(0,0,0,0))
        ImageDraw.Draw(im).rectangle((65,130,175,270),fill=(0,120,220,128)); im.save(self.source)

    def tearDown(self):
        self.temp.cleanup()

    def job(self, **kwargs):
        return {'input':str(self.source),'size':'240x240','out_dir':str(self.root/'out'),**kwargs}

    def start(self, count=2, **kwargs):
        spec=self.root/'jobs.json'
        profile.write_json(spec,{'product_focus':{'category':'帽子'},'jobs':[self.job(name=f'图{i}',**kwargs) for i in range(count)]})
        return self.queue.start(spec)['review_id']

    def confirmed(self, count=2, **kwargs):
        rid=self.start(count,**kwargs)
        for _ in range(count):
            current=self.queue.next(rid)
            self.queue.confirm(rid,current['digest'],'模拟用户：当前这一张确认')
        return rid

    def run_entry(self,args):
        out=io.StringIO()
        with contextlib.redirect_stdout(out):
            entry.run(self.store,args,review_required=args[0]!='batch')
        return json.loads(out.getvalue())

    def test_alpha_preserved_for_all_framing_modes(self):
        cases=[{'focus':[.5,.5]}, {'crop_box':[.1,.1,.9,.9]}, {'protect_box':[.3,.35,.7,.65]},
               {'fit':'subject','subject_box':[.3,.35,.7,.65],'subject_fill':.8}]
        for job in cases:
            _,image,_,_=self.engine._render(self.job(**job))
            lo,hi=image.getchannel('A').getextrema()
            self.assertEqual(lo,0); self.assertLess(hi,255); self.assertGreater(hi,0)

    def test_white_padding_does_not_flatten_source_alpha(self):
        _,im,_,_=self.engine._render(self.job(size='400x400',fit='contain',allow_padding=True))
        self.assertEqual(im.getpixel((0,200))[3],255)
        self.assertLess(im.getpixel((200,200))[3],255)

    def test_transparent_padding_preserved(self):
        _,im,_,_=self.engine._render(self.job(size='400x400',fit='contain',allow_padding=True,bg='transparent'))
        self.assertEqual(im.getpixel((0,200))[3],0)

    def test_icc_roundtrip_with_focus(self):
        icc=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB')).tobytes()
        Image.new('RGB',(240,400),'red').save(self.source,icc_profile=icc)
        result=self.engine.make(self.job(focus=[.5,.5]))
        with Image.open(result['outputs'][0]) as image:
            self.assertEqual(image.info.get('icc_profile'),icc)

    def test_cmyk_needs_explicit_conversion(self):
        source=self.root/'cmyk.jpg'; Image.new('CMYK',(240,400)).save(source)
        with self.assertRaisesRegex(ValueError,'CMYK'):
            self.engine._render(self.job(input=str(source)))

    def test_existing_image_is_not_overwritten(self):
        self.engine.make(self.job()); out=self.root/'out/原图.png'; before=profile.file_hash(out)
        with self.assertRaises(ValueError): self.engine.make(self.job(focus=[.5,.3]))
        self.assertEqual(profile.file_hash(out),before)

    def test_existing_psd_blocks_before_image_write(self):
        out=self.root/'out';out.mkdir(); (out/'原图.psd').write_bytes(b'old-psd')
        with self.assertRaises(ValueError): self.engine.make(self.job(psd=True))
        self.assertFalse((out/'原图.png').exists())

    def test_existing_recipe_blocks_before_image_write(self):
        out=self.root/'out';out.mkdir();(out/'原图.framing.json').write_text('old')
        with self.assertRaises(ValueError): self.engine.make(self.job(save_recipe=True))
        self.assertFalse((out/'原图.png').exists())

    def test_concurrent_publication_never_replaces_target(self):
        target=self.root/'race.png'
        def write(value):
            try:
                self.engine.publish_new(target,lambda p:p.write_bytes(value))
                return True
            except FileExistsError: return False
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(write,[b'one',b'two']))
        self.assertEqual(results.count(True),1)
        self.assertIn(target.read_bytes(),(b'one',b'two'))
        self.assertFalse(list(self.root.glob('.resize-*')))

    def test_psd_failure_is_partial_delivery(self):
        with patch.object(self.engine,'write_psd',side_effect=ValueError('模拟PSD失败')):
            with self.assertRaises(self.engine.DeliveryError) as caught:
                self.engine.make(self.job(psd=True))
        self.assertEqual(caught.exception.result['status'],'partial')
        self.assertEqual(len(caught.exception.result['outputs']),1)
        self.assertFalse((self.root/'out/原图.psd').exists())

    def test_batch_renders_once_per_image(self):
        with patch.object(self.engine,'_render',wraps=self.engine._render) as rendered:
            self.engine.batch([self.job()])
        self.assertEqual(rendered.call_count,1)

    def test_validator_rejects_ignored_protection_regression(self):
        text=(self.snapshot/'renderer.py').read_text(encoding='utf-8')
        text+='\n_old_plan=framing_plan\ndef framing_plan(source_size,size,job):\n    return _old_plan(source_size,size,{k:v for k,v in job.items() if k != "protect_box"})\n'
        (self.snapshot/'renderer.py').write_text(text,encoding='utf-8')
        result=validate_snapshot(self.snapshot,self.root/'broken-preview',[self.job(protect_box=[0,0,1,1])])
        self.assertFalse(result['passed']);self.assertIn('protect_box',result['error'])

    def test_validator_rejects_faked_domain(self):
        job=self.job();_,image,plan,_=self.engine._render(job);plan['source_domain_px']=[0,0,999,999]
        with self.assertRaises(ValueError):assert_render(image,plan,job)

    def test_defaults_are_shared_by_validation_cli(self):
        spec=self.root/'defaults.json';profile.write_json(spec,{'defaults':{'size':'240x240'},'jobs':[{'input':str(self.source)}]})
        jobs=load_jobs(spec);self.assertEqual(jobs[0]['size'],'240x240')
        proposal=self.store.propose({'personal_prompt.md':'保留商品全貌\n'},'测试defaults')
        args=['profile','--state',str(self.store.root),'validate','--proposal',proposal['id'],'--spec',str(spec)]
        with patch.object(sys,'argv',args),contextlib.redirect_stdout(io.StringIO()) as out:
            profile.main()
        self.assertTrue(json.loads(out.getvalue())['passed'])

    def test_review_only_renders_current_image_until_confirmation(self):
        rid=self.start(3)
        with patch.object(self.engine,'_render',wraps=self.engine._render) as rendered:
            first=self.queue.next(rid);again=self.queue.next(rid)
            self.assertEqual(first['index'],1);self.assertEqual(again['digest'],first['digest'])
            self.assertEqual(rendered.call_count,1)
            self.assertFalse((self.root/'out').exists())
            self.queue.confirm(rid,first['digest'],'模拟用户确认第一张')
            self.assertEqual(rendered.call_count,1)
            second=self.queue.next(rid);self.assertEqual(second['index'],2)
            self.assertEqual(rendered.call_count,2)

    def test_adjustment_invalidates_old_confirmation(self):
        rid=self.start();first=self.queue.next(rid)
        refined=self.queue.adjust(rid,{'focus':[.5,.4]})
        self.assertEqual(refined['index'],1);self.assertNotEqual(first['digest'],refined['digest'])
        with self.assertRaises(ValueError):self.queue.confirm(rid,first['digest'],'旧预览的批准')
        self.assertEqual(self.queue.next(rid)['index'],1)

    def test_no_confirmation_before_preview_or_with_empty_text(self):
        rid=self.start()
        with self.assertRaises(ValueError):self.queue.confirm(rid,'anything','模拟确认')
        first=self.queue.next(rid)
        with self.assertRaises(ValueError):self.queue.confirm(rid,first['digest'],' ')

    def test_batch_blocked_until_every_image_confirmed(self):
        rid=self.start();first=self.queue.next(rid);self.queue.confirm(rid,first['digest'],'第一张确认')
        with self.assertRaises(ValueError):self.run_entry(['batch','--review',rid])
        self.assertFalse((self.root/'out').exists())

    def test_all_confirmed_deliver_and_feedback_once(self):
        rid=self.confirmed();result=self.run_entry(['batch','--review',rid])
        bid=result[0]['feedback']['batch_id'];self.assertTrue(self.store.mark_asked(bid)['ask_now'])
        self.assertFalse(self.store.mark_asked(bid)['ask_now'])
        self.assertEqual(len(list((self.store.root/'batches').glob('*.json'))),1)
        self.assertEqual(self.queue.load(rid)['product_focus']['category'],'帽子')

    def test_single_make_cannot_bypass_queue(self):
        with self.assertRaises(ValueError):self.run_entry(['make','--input',str(self.source),'--size','240x240'])

    def test_source_change_after_confirmation_blocks_delivery(self):
        rid=self.confirmed();Image.new('RGB',(240,400),'green').save(self.source)
        with self.assertRaises(ValueError):self.run_entry(['batch','--review',rid])
        self.assertFalse((self.root/'out').exists())

    def test_preview_change_after_confirmation_blocks_delivery(self):
        rid=self.confirmed();record=self.queue.load(rid);Path(record['items'][0]['preview']).write_bytes(b'changed')
        with self.assertRaises(ValueError):self.queue.ready(rid)

    def test_parameter_change_after_confirmation_blocks_delivery(self):
        rid=self.confirmed();record=self.queue.load(rid);record['items'][0]['job']['size']='800x800';self.queue.save(record)
        with self.assertRaises(ValueError):self.queue.ready(rid)

    def test_new_personal_revision_invalidates_queue(self):
        rid=self.confirmed();proposal=self.store.propose({'personal_prompt.md':'新规则'},'新规则')
        self.store.validate(proposal['id']);self.store.approve(proposal['id'],proposal['digest'],'测试批准新个人规则')
        with self.assertRaises(ValueError):self.queue.ready(rid)

    def test_interruption_resumes_current_image(self):
        rid=self.start();first=self.queue.next(rid)
        reloaded=ReviewQueue(profile.Store(self.store.root),self.engine)
        self.assertEqual(reloaded.next(rid)['digest'],first['digest'])
        self.assertEqual(reloaded.next(rid)['index'],1)

    def test_partial_batch_lists_outputs_and_resumes_without_rewriting(self):
        rid=self.confirmed();revision,folder,settings=self.store.active();engine=load_engine(folder)
        original=engine.make
        def fail_second(job,**kwargs):
            if job['name']=='图1':raise OSError('模拟第二张写入失败')
            return original(job,**kwargs)
        record=self.queue.ready(rid);jobs=[i['job'] for i in record['items']]
        with patch.object(engine,'make',side_effect=fail_second),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(OSError):entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid)
        batch=self.store.batch_record(self.queue.load(rid)['execution_batch'])
        self.assertEqual(batch['status'],'partial');self.assertEqual(len(batch['outputs']),1)
        completed=Path(batch['outputs'][0]);before=(profile.file_hash(completed),completed.stat().st_mtime_ns)
        result=entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid,resume=True)
        self.assertEqual(len(result),2);self.assertEqual(before,(profile.file_hash(completed),completed.stat().st_mtime_ns))

    def test_partial_psd_can_resume_missing_deliverable(self):
        rid=self.confirmed(1,psd=True);revision,folder,settings=self.store.active();engine=load_engine(folder)
        jobs=[i['job'] for i in self.queue.ready(rid)['items']]
        with patch.object(engine,'write_psd',side_effect=ValueError('模拟PSD失败')),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(ValueError):entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid)
        first=self.root/'out/图0.png';before=first.stat().st_mtime_ns
        entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid,resume=True)
        self.assertEqual(first.stat().st_mtime_ns,before);self.assertTrue((self.root/'out/图0.psd').exists())

    def test_tampered_partial_output_blocks_resume(self):
        rid=self.confirmed(1,psd=True);revision,folder,settings=self.store.active();engine=load_engine(folder)
        jobs=[i['job'] for i in self.queue.ready(rid)['items']]
        with patch.object(engine,'write_psd',side_effect=ValueError('模拟PSD失败')),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(ValueError):entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid)
        (self.root/'out/图0.png').write_bytes(b'tampered')
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaises(ValueError):
            entry.deliver(self.store,engine,jobs,revision,settings,self.queue,rid,resume=True)

    def test_reserved_windows_name_rejected(self):
        with self.assertRaises(ValueError):self.engine.make(self.job(name='CON'))

    def test_real_cli_two_images_require_separate_confirmations(self):
        spec=self.root/'cli-jobs.json'
        profile.write_json(spec,{'delivery':{'kind':'scene','style_id':'CLI','out_dir':str(self.root/'out'),
                                            'sizes':['240x240'],'naming':'style_size_index','format':'png'},
                                 'jobs':[self.job(name='cli1'),self.job(name='cli2')]})
        def call(*args, ok=True):
            result=subprocess.run([sys.executable,str(PACKAGE/'scripts/resize_assets.py'),'--state',str(self.store.root),*args],
                                  capture_output=True,encoding='utf-8',env=dict(os.environ,PYTHONUTF8='1'))
            if ok:self.assertEqual(result.returncode,0,result.stderr)
            else:self.assertNotEqual(result.returncode,0);return None
            return json.loads(result.stdout)
        rid=call('review-start','--spec',str(spec))['review_id']
        first=call('review-next','--review',rid);self.assertEqual(first['index'],1)
        self.assertEqual(call('review-next','--review',rid)['index'],1)
        call('batch','--review',rid,ok=False)
        confirmation=self.root/'确认.txt';confirmation.write_text('模拟人类：当前图片可以',encoding='utf-8')
        call('review-confirm','--review',rid,'--digest',first['digest'],'--confirmation-file',str(confirmation))
        second=call('review-next','--review',rid);self.assertEqual(second['index'],2)
        call('batch','--review',rid,ok=False)
        last=call('review-confirm','--review',rid,'--digest',second['digest'],'--confirmation-file',str(confirmation))
        self.assertTrue(last['ready']);self.assertEqual(len(call('batch','--review',rid)),2)
