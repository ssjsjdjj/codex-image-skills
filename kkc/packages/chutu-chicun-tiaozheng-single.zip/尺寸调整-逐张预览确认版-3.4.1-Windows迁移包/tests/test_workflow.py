import contextlib
import copy
import importlib.util
import io
import json
import os
import subprocess
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
PACKAGE = Path(os.environ.get("RESIZE_TEST_SKILL", ROOT / "skills/chutu-chicun-tiaozheng-single")).resolve()
sys.path.insert(0, str(PACKAGE / "scripts"))
import user_profile as profile
from validate_candidate import validate_snapshot, load_engine, assert_render

spec = importlib.util.spec_from_file_location("resize_entry", PACKAGE / "scripts/resize_assets.py")
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)

def fixture_run(store, argv):
    return entry.run(store, argv, review_required=False)



def snapshot_at(path, allow_padding=False):
    path.mkdir(parents=True)
    settings = json.loads((PACKAGE / "assets/settings.example.json").read_text(encoding="utf-8"))
    if allow_padding:
        settings["defaults"].update(fit="contain", allow_padding=True)
    profile.write_json(path / "settings.json", settings)
    shutil.copyfile(PACKAGE / "assets/renderer.py", path / "renderer.py")
    shutil.copyfile(PACKAGE / "assets/personal_prompt.example.md", path / "personal_prompt.md")
    return path


class WorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = tempfile.TemporaryDirectory(prefix="resize-workflow-fixture-")
        cls.fixture_root = Path(cls.fixture.name)
        cls.seed = snapshot_at(cls.fixture_root / "seed")
        cls.seed_report = validate_snapshot(cls.seed, cls.fixture_root / "seed-validation")
        assert cls.seed_report["passed"], cls.seed_report

    @classmethod
    def tearDownClass(cls):
        cls.fixture.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="resize-workflow-test-")
        self.root = Path(self.temp.name)
        self.store = profile.Store(self.root / "state")
        self.initial = self.store.initialize(self.seed, "测试副本初始化，非正式账号部署", self.seed_report)
        self.source = self.root / "source.png"
        Image.new("RGB", (240, 400), "blue").save(self.source)

    def tearDown(self):
        self.temp.cleanup()

    def batch(self):
        return self.store.register_batch([{"input": str(self.source), "size": "240x240"}], []) ["batch_id"]

    def proposed(self, note="头顶留出适量空间"):
        _, folder, _ = self.store.active()
        return self.store.propose({"personal_prompt.md": (folder / "personal_prompt.md").read_text(encoding="utf-8") + "\n" + note}, note)

    def activate(self, note="已审核"):
        proposal = self.proposed(note)
        report = self.store.validate(proposal["id"])
        self.assertTrue(report["passed"], report)
        return self.store.approve(proposal["id"], proposal["digest"], "测试中明确批准这一草案")["revision"]

    def test_no_automatic_initialization(self):
        empty = profile.Store(self.root / "not-initialized")
        self.assertFalse(empty.status()["initialized"])
        self.assertFalse(empty.root.exists())

    def test_windows_profile_sid_matches_case_and_separators(self):
        expected = "S-1-5-21-1-2-3-500"
        entries = [(expected, "C:/Users/ResizePortableTest"),
                   ("S-1-5-21-1-2-3-1001", "C:/Users/AnotherPerson")]
        self.assertEqual(profile._match_profile_sid("c:\\users\\resizeportabletest\\", entries), expected)

    def test_windows_unmatched_profile_sid_stops_instead_of_reassigning(self):
        with self.assertRaises(ValueError):
            profile._match_profile_sid("C:/Users/NoSuchProfile", [("S-1-5-21-1-2-3-500", "C:/Users/Other")])
        with self.assertRaises(ValueError):
            profile._match_profile_sid(None, [])

    def test_windows_ambiguous_profile_sid_stops(self):
        entries = [("S-1-5-21-1-2-3-500", "C:/Users/Same"),
                   ("S-1-5-21-1-2-3-1001", "C:/Users/Same")]
        with self.assertRaises(ValueError):
            profile._match_profile_sid("C:/Users/Same", entries)

    def test_windows_profile_sid_does_not_use_sandbox_process_identity(self):
        with patch.object(profile, "_profile_sid", return_value="S-1-5-21-1-2-3-500") as resolver:
            with patch.object(profile.subprocess, "run", side_effect=AssertionError("do not query sandbox whoami")):
                self.assertEqual(profile.owner_id(), "S-1-5-21-1-2-3-500")
            resolver.assert_called_once_with(os.environ.get("USERPROFILE"))

    def test_owner_mismatch_cannot_read_or_write(self):
        with patch.object(profile, "owner_id", return_value="S-1-5-21-OTHER"):
            with self.assertRaises(ValueError):
                self.store.status()
            with self.assertRaises(ValueError):
                self.store.mark_asked("b-example")

    def test_two_account_states_have_independent_preferences(self):
        other_seed = snapshot_at(self.root / "other-seed", allow_padding=True)
        report = validate_snapshot(other_seed, self.root / "other-validation")
        self.assertTrue(report["passed"], report)
        with patch.object(profile, "owner_id", return_value="S-1-5-21-OTHER"):
            other = profile.Store(self.root / "other-state")
            other.initialize(other_seed, "另一个模拟账号单独确认", report)
            self.assertTrue(other.active()[2]["defaults"]["allow_padding"])
            self.assertFalse(other.events("feedback.jsonl"))
        self.assertFalse(self.store.active()[2]["defaults"]["allow_padding"])

    def test_one_batch_only_requests_feedback_once(self):
        batch = self.batch()
        self.assertTrue(self.store.mark_asked(batch)["ask_now"])
        self.assertFalse(self.store.mark_asked(batch)["ask_now"])

    def test_ignoring_feedback_is_not_an_answer(self):
        self.store.mark_asked(self.batch())
        self.assertEqual(self.store.events("feedback.jsonl"), [])

    def test_three_distinct_batches_trigger_a_proposal(self):
        first = self.batch()
        for _ in range(4):
            result = self.store.feedback(first, "头顶稍微宽松一点", "headroom", "general")
            self.assertFalse(result["eligible"])
            self.assertEqual(result["distinct_batches"], 1)
        result = self.store.feedback(self.batch(), "头顶稍微宽松一点", "headroom", "general")
        self.assertFalse(result["eligible"])
        result = self.store.feedback(self.batch(), "头顶稍微宽松一点", "headroom", "general")
        self.assertTrue(result["eligible"])
        self.assertEqual(result["proposal"]["status"], "pending")
        self.assertEqual(self.store.active()[0], self.initial)

    def test_explicit_long_term_feedback_immediate_but_pending(self):
        result = self.store.feedback(self.batch(), "以后帽顶多留一些空间", "headroom", "long_term")
        self.assertTrue(result["eligible"])
        self.assertEqual(self.store.active()[0], self.initial)
        stored = self.store.events("feedback.jsonl")[0]
        self.assertEqual(stored["image_paths"], [str(self.source.resolve())])
        self.assertEqual(stored["params"][0]["size"], "240x240")
        self.assertFalse(list(self.store.root.rglob("source.png")))

    def test_once_feedback_never_changes_preferences(self):
        for _ in range(4):
            result = self.store.feedback(self.batch(), "仅这次居中", "position", "once")
            self.assertFalse(result["eligible"])
        self.assertEqual(self.store.proposals(), [])
        self.assertEqual(self.store.active()[0], self.initial)

    def test_approval_requires_validation_digest_and_confirmation(self):
        proposal = self.proposed()
        with self.assertRaises((ValueError, FileNotFoundError)):
            self.store.approve(proposal["id"], proposal["digest"], "同意")
        report = self.store.validate(proposal["id"])
        self.assertTrue(report["passed"], report)
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], "wrong", "同意")
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "")
        self.assertEqual(self.store.active()[0], self.initial)

    def test_post_validation_tampering_is_blocked(self):
        proposal = self.proposed()
        self.store.validate(proposal["id"])
        folder, _ = self.store.proposal(proposal["id"])
        with (folder / "candidate/personal_prompt.md").open("a", encoding="utf-8") as stream:
            stream.write("\n未批准的变更")
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "同意")

    def test_preview_tampering_is_blocked(self):
        proposal = self.proposed()
        report = self.store.validate(proposal["id"])
        Path(report["previews"][0]["path"]).write_bytes(b"modified")
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "同意")

    def test_stale_proposal_is_blocked(self):
        stale = self.proposed("草案B")
        self.store.validate(stale["id"])
        self.activate("草案A")
        with self.assertRaises(ValueError):
            self.store.approve(stale["id"], stale["digest"], "同意")

    def test_failed_script_validation_cannot_activate(self):
        _, folder, _ = self.store.active()
        text = (folder / "renderer.py").read_text(encoding="utf-8")
        text += "\n_original_render = _render\ndef _render(job):\n    s, im, plan, j = _original_render(job)\n    return s, im.resize((13, 17)), plan, j\n"
        proposal = self.store.propose({"renderer.py": text}, "测试错误尺寸脚本")
        report = self.store.validate(proposal["id"])
        self.assertFalse(report["passed"])
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "同意")
        self.assertEqual(self.store.active()[0], self.initial)

    def test_runtime_failure_reports_without_rollback(self):
        _, folder, _ = self.store.active()
        text = (folder / "renderer.py").read_text(encoding="utf-8")
        text += "\n_original_render = _render\ndef _render(job):\n    if job.get('name') == 'trigger':\n        raise ValueError('模拟已生效版本遇到新素材异常')\n    return _original_render(job)\n"
        proposal = self.store.propose({"renderer.py": text}, "测试运行期异常")
        self.assertTrue(self.store.validate(proposal["id"])["passed"])
        revision = self.store.approve(proposal["id"], proposal["digest"], "测试确认")["revision"]
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            fixture_run(self.store, ["make", "--input", str(self.source), "--size", "240x240", "--name", "trigger", "--out-dir", str(self.root / "out")])
        self.assertEqual(self.store.active()[0], revision)
        self.assertFalse(self.store.events("incidents.jsonl")[-1]["automatic_rollback"])
        self.assertFalse((self.root / "out/trigger.png").exists())

    def test_retention_three_and_manual_rollback(self):
        revisions = [self.initial] + [self.activate(f"偏好{i}") for i in range(4)]
        kept = {item["revision"] for item in self.store.version_list()}
        self.assertEqual(kept, set(revisions[-3:]))
        with self.assertRaises(ValueError):
            self.store.rollback(revisions[-2], "")
        self.store.rollback(revisions[-2], "用户确认回退至已展示的上一版")
        self.assertEqual(self.store.active()[0], revisions[-2])
        with self.assertRaises(ValueError):
            self.store.rollback(self.initial, "同意")

    def test_profile_rule_blocks_padding_and_stretch_until_explicit_override(self):
        engine = load_engine(self.seed)
        job = {"input": str(self.source), "size": "240x240", "fit": "contain"}
        with self.assertRaises(ValueError):
            engine._render(job)
        _, image, plan, resolved = engine._render({**job, "allow_padding": True})
        assert_render(image, plan, resolved)
        self.assertEqual(image.getpixel((0, 120)), (255, 255, 255))
        with self.assertRaises(ValueError):
            engine._render({**job, "fit": "stretch"})

    def test_successful_batch_registers_one_feedback_record(self):
        spec = self.root / "jobs.json"
        profile.write_json(spec, {"jobs": [{"input": str(self.source), "size": "240x240", "name": name,
                                           "out_dir": str(self.root / "out")} for name in ("a", "b")]})
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store, ["batch", "--spec", str(spec)])
        batches = list((self.store.root / "batches").glob("*.json"))
        self.assertEqual(len(batches), 1)
        self.assertEqual(len(profile.read_json(batches[0])["jobs"]), 2)
        with Image.open(self.root / "out/a.png") as output:
            self.assertEqual(output.size, (240, 240))

    def test_sample_changed_after_validation_blocks_approval(self):
        proposal = self.proposed()
        report = self.store.validate(proposal["id"], [{"input": str(self.source), "size": "240x240"}])
        self.assertTrue(report["passed"], report)
        Image.new("RGB", (240, 400), "red").save(self.source)
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "同意")

    def test_candidate_refinement_refreshes_review_and_digest(self):
        proposal = self.proposed()
        directory, _ = self.store.proposal(proposal["id"])
        path = directory / "candidate/personal_prompt.md"
        path.write_text(path.read_text(encoding="utf-8") + "\n精修后的实际规则", encoding="utf-8")
        report = self.store.validate(proposal["id"])
        self.assertTrue(report["passed"], report)
        _, refreshed = self.store.proposal(proposal["id"])
        self.assertNotEqual(proposal["digest"], refreshed["digest"])
        self.assertIn("精修后的实际规则", (directory / "changes.diff").read_text(encoding="utf-8"))
        with self.assertRaises(ValueError):
            self.store.approve(proposal["id"], proposal["digest"], "同意旧草案")
        self.store.approve(proposal["id"], refreshed["digest"], "测试确认新草案")

    def test_cli_obeys_personal_output_format(self):
        _, _, settings = self.store.active()
        settings["defaults"]["format"] = "jpg"
        proposal = self.store.propose({"settings.json": settings}, "个人格式偏好")
        self.assertTrue(self.store.validate(proposal["id"])["passed"])
        self.store.approve(proposal["id"], proposal["digest"], "测试确认")
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store, ["make", "--input", str(self.source), "--size", "240x240", "--out-dir", str(self.root / "out")])
        self.assertTrue((self.root / "out/source.jpg").is_file())
        self.assertFalse((self.root / "out/source.png").exists())

    def test_refined_no_change_proposal_does_not_create_version(self):
        proposal = self.proposed()
        directory, _ = self.store.proposal(proposal["id"])
        _, active, _ = self.store.active()
        profile.copy_snapshot(active, directory / "candidate")
        with self.assertRaises(ValueError):
            self.store.validate(proposal["id"])
        self.assertEqual(self.store.active()[0], self.initial)

    def test_runtime_wrong_size_is_blocked_before_output(self):
        _, folder, _ = self.store.active()
        text = (folder / "renderer.py").read_text(encoding="utf-8")
        text += "\n_original_render = _render\ndef _render(job):\n    s, im, plan, j = _original_render(job)\n    if job.get('name') == 'trigger':\n        im = im.resize((13, 17))\n    return s, im, plan, j\n"
        proposal = self.store.propose({"renderer.py": text}, "模拟特定输入尺寸异常")
        self.assertTrue(self.store.validate(proposal["id"])["passed"])
        revision = self.store.approve(proposal["id"], proposal["digest"], "测试确认")["revision"]
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            fixture_run(self.store, ["make", "--input", str(self.source), "--size", "240x240", "--name", "trigger", "--out-dir", str(self.root / "out")])
        self.assertEqual(self.store.active()[0], revision)
        self.assertFalse((self.root / "out/trigger.png").exists())


    def test_portable_powershell_resize_and_profile_wrappers(self):
        env=dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
        prefix=['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File']
        result=subprocess.run(prefix+[str(PACKAGE/'scripts/run_profile.ps1'),'--state',str(self.store.root),'status'],capture_output=True,encoding='utf-8',env=env)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue(json.loads(result.stdout)['initialized'])
        from review_queue import ReviewQueue
        queue=ReviewQueue(self.store,load_engine(self.seed))
        jobs=self.root/'wrapper-jobs.json'
        profile.write_json(jobs,{'delivery':{'kind':'scene','style_id':'包装器测试','out_dir':str(self.root/'中文 成品目录'),
                                            'sizes':['800x800'],'naming':'original','format':'png'},
                                 'jobs':[{'input':str(self.source)}]})
        rid=queue.start(jobs)['review_id']; current=queue.next(rid)
        if current.get('requires_backend_choice'):
            queue.select_backend(rid,'python','隔离包装器测试模拟人工选择Python；仅本图本尺寸')
            current=queue.next(rid)
        queue.confirm(rid,current['digest'],'隔离测试：真实入口逐张批准模拟')
        result=subprocess.run(prefix+[str(PACKAGE/'scripts/run_resize.ps1'),'--state',str(self.store.root),'batch','--review',rid],capture_output=True,encoding='utf-8',env=env)
        self.assertEqual(result.returncode,0,result.stderr)
        with Image.open(self.root/'中文 成品目录/图片/800x800/source.png') as image:
            self.assertEqual(image.size,(800,800))

    def test_optional_single_layer_psd_is_readable(self):
        from psd_tools import PSDImage
        from review_queue import ReviewQueue
        queue=ReviewQueue(self.store,load_engine(self.seed))
        jobs=self.root/'optional-psd-jobs.json'
        profile.write_json(jobs,{'jobs':[{'input':str(self.source),'size':'800x800',
                            'out_dir':str(self.root/'psd-output'),'psd':True}]})
        rid=queue.start(jobs)['review_id']
        current=queue.next(rid)
        self.assertTrue(current['requires_backend_choice'])
        queue.select_backend(rid,'python','隔离可选PSD测试模拟人工选择Python放大；仅本图本尺寸')
        current=queue.next(rid)
        queue.confirm(rid,current['digest'],'隔离可选PSD测试模拟人工确认预览')
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store,['batch','--review',rid])
        psd=PSDImage.open(self.root/'psd-output/source.psd')
        self.assertEqual(psd.size,(800,800))
        self.assertEqual([layer.name for layer in psd],['图像'])
        self.assertIsNotNone(psd.composite())

    def test_recipe_replay_preserves_pixels(self):
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store,['make','--input',str(self.source),'--size','300x180','--focus','0.5,0.3','--out-dir',str(self.root/'first'),'--save-recipe'])
            fixture_run(self.store,['replay','--recipe',str(self.root/'first/source.framing.json'),'--out-dir',str(self.root/'second')])
        with Image.open(self.root/'first/source.png') as first,Image.open(self.root/'second/source.png') as second:
            self.assertEqual(first.tobytes(),second.tobytes())

    def test_preview_registers_no_batch_or_feedback(self):
        spec=self.root/'preview-jobs.json'
        profile.write_json(spec,{'jobs':[{'input':str(self.source),'size':'800x800'}]})
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store,['preview','--spec',str(spec),'--out',str(self.root/'preview.png')])
        self.assertTrue((self.root/'preview.png').is_file())
        self.assertFalse(list((self.store.root/'batches').glob('*.json')))
        self.assertEqual(self.store.events('feedback.jsonl'),[])

    def test_transparent_png_keeps_existing_alpha(self):
        from PIL import ImageDraw
        original=Image.new('RGBA',(240,400),(0,0,0,0))
        ImageDraw.Draw(original).rectangle((45,120,195,280),fill=(0,160,210,255))
        original.save(self.source)
        with contextlib.redirect_stdout(io.StringIO()):
            fixture_run(self.store,['make','--input',str(self.source),'--size','240x240','--out-dir',str(self.root/'alpha')])
        with Image.open(self.root/'alpha/source.png') as image:
            self.assertEqual(image.mode,'RGBA')
            self.assertEqual(image.getchannel('A').getextrema(),(0,255))


if __name__ == "__main__":
    unittest.main(verbosity=2)
