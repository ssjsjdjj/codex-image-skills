import hashlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image
from psd_tools import PSDImage
from psd_tools.api.layers import PixelLayer

PACKAGE=Path(os.environ.get('RESIZE_TEST_SKILL',Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng-single'))
sys.path.insert(0,str(PACKAGE/'scripts'))
import psd_source


def synthetic_psd(path,size=(80,80),name='Pixels'):
    document=PSDImage.new('RGB',size)
    layer=PixelLayer.frompil(Image.new('RGB',size,(30,120,210)),document,'Pixels')
    layer.name=name
    document.save(path)
    return path


def full_plan(side,target):
    return {'source_size':[side,side],'output_size':[target,target],'effective_fit':'cover',
            'source_domain_px':[0,0,side,side],'source_viewport_px':[0,0,side,side],'warnings':[]}


class PSDSourceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='psd-source-unit-');self.root=Path(self.temp.name)
        self.source=synthetic_psd(self.root/'source.psd')
        self.before=psd_source._hash(self.source)

    def tearDown(self):self.temp.cleanup()

    def test_inspection_is_read_only_and_reports_structure(self):
        with patch.object(PSDImage,'save',side_effect=AssertionError('read-only inspection cannot save')):
            details=psd_source.inspect_source(self.source)
        self.assertEqual(details['size'],[80,80]);self.assertEqual(details['sha256'],self.before)
        self.assertEqual(details['counts']['layers'],1);self.assertEqual(details['native_structure'][0]['name'],'Pixels')
        self.assertEqual(psd_source._hash(self.source),self.before)

    def test_photoshop_progid_configuration_is_strict(self):
        self.assertEqual(psd_source._configured_progid({}),'Photoshop.Application')
        self.assertEqual(psd_source._configured_progid({'CHUTU_PHOTOSHOP_PROGID':'Photoshop.Application.190'}),'Photoshop.Application.190')
        for value in ('WScript.Shell','Photoshop.Application.190;Stop-Process',' Photoshop.Application','Photoshop.Application.x','Photoshop.Application.190x'):
            with self.subTest(value=value),self.assertRaises(ValueError):
                psd_source._configured_progid({'CHUTU_PHOTOSHOP_PROGID':value})

    def test_jpeg_cannot_masquerade_as_psd(self):
        fake=self.root/'fake.psd';Image.new('RGB',(80,80),'red').save(fake,format='JPEG')
        with self.assertRaisesRegex(ValueError,'JPG/PNG'):psd_source.inspect_source(fake)
        with self.assertRaises(ValueError):psd_source.inspect_source(self.root/'missing.psd')
        png=self.root/'source.png';Image.new('RGB',(10,10)).save(png)
        with self.assertRaises(ValueError):psd_source.inspect_source(png)

    def test_plan_rejects_stretch_padding_and_aspect_conflicts_before_com(self):
        with patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('COM must not run')):
            for job,plan in [({'input':str(self.source),'size':'144x144','fit':'stretch'},full_plan(80,144)),
                             ({'input':str(self.source),'size':'144x144'},dict(full_plan(80,144),source_viewport_px=[-1,0,79,80])),
                             ({'input':str(self.source),'size':'144x144'},dict(full_plan(80,144),source_viewport_px=[0,0,40,80]))]:
                with self.assertRaises(ValueError):psd_source.render_psd(job,self.root/'cache',plan=plan)
        self.assertEqual(psd_source._hash(self.source),self.before)

    def test_integer_rounding_must_keep_protected_region(self):
        plan=dict(full_plan(80,144),source_viewport_px=[.1,.1,79.9,79.9])
        with self.assertRaises(ValueError):
            psd_source._execution_plan({'size':'144x144','protect_box':[0,0,1,1]},psd_source.inspect_source(self.source),plan)

    def test_missing_photoshop_fails_without_flattened_fallback(self):
        with patch.object(psd_source,'_invoke_photoshop',side_effect=psd_source.PhotoshopUnavailableError('Photoshop unavailable')):
            with self.assertRaises(psd_source.PhotoshopUnavailableError):
                psd_source.render_psd({'input':str(self.source),'size':'144x144'},self.root/'cache',plan=full_plan(80,144))
        self.assertFalse(list((self.root/'cache').rglob('variant.psd')))
        self.assertFalse(list((self.root/'cache').rglob('preview.png')))
        self.assertEqual(psd_source._hash(self.source),self.before)

    def test_com_request_is_a_data_file_not_interpolated_javascript(self):
        directory=self.root/"request with spaces & apostrophe's";directory.mkdir()
        raw='C:/input/quote\"; app.activeDocument.close(); \\ unicode裤子.psd'
        captured={}
        def fake(command,**kwargs):
            captured['command']=command;captured.update(kwargs)
            request_path=Path(command[-1]);request=json.loads(request_path.read_text(encoding='utf-8'))
            self.assertEqual(request['source_copy'],raw)
            Path(request['response_path']).write_text(json.dumps({'ok':True,'owned_documents_closed':True,
                'preferences_restored':True,'active_document_restored':True}),encoding='utf-8')
            return SimpleNamespace(returncode=0,stdout='ok',stderr='')
        with patch.object(psd_source.shutil,'which',return_value='powershell.exe'),patch.object(psd_source.subprocess,'run',side_effect=fake):
            psd_source._invoke_photoshop({'action':'render','source_copy':raw},directory)
        self.assertFalse(captured['shell']);self.assertIn('-File',captured['command'])
        self.assertNotIn('-Command',captured['command']);self.assertNotIn(raw,captured['command'])

    def test_com_unavailable_response_has_specific_error(self):
        directory=self.root/'unavailable';directory.mkdir()
        def fake(command,**kwargs):
            request=json.loads(Path(command[-1]).read_text(encoding='utf-8'))
            Path(request['response_path']).write_text(json.dumps({'ok':False,'code':'PHOTOSHOP_UNAVAILABLE','error':'no Photoshop COM'}),encoding='utf-8')
            return SimpleNamespace(returncode=2,stdout='',stderr='no Photoshop COM')
        with patch.object(psd_source.shutil,'which',return_value='powershell.exe'),patch.object(psd_source.subprocess,'run',side_effect=fake):
            with self.assertRaises(psd_source.PhotoshopUnavailableError):psd_source._invoke_photoshop({'action':'render'},directory)

    def test_cleanup_or_activity_restoration_failure_is_not_success(self):
        for field in ('owned_documents_closed','preferences_restored','active_document_restored'):
            directory=self.root/field;directory.mkdir()
            def fake(command,**kwargs):
                request=json.loads(Path(command[-1]).read_text(encoding='utf-8'))
                response={'ok':True,'owned_documents_closed':True,'preferences_restored':True,'active_document_restored':True}
                response[field]=False
                Path(request['response_path']).write_text(json.dumps(response),encoding='utf-8')
                return SimpleNamespace(returncode=0,stdout='',stderr='')
            with patch.object(psd_source.shutil,'which',return_value='powershell.exe'),patch.object(psd_source.subprocess,'run',side_effect=fake):
                with self.assertRaises(psd_source.NativePSDError):psd_source._invoke_photoshop({'action':'render'},directory)

    def test_source_mutation_during_failure_is_reported(self):
        def changed(*args,**kwargs):
            self.source.write_bytes(b'changed during mock')
            raise psd_source.PhotoshopUnavailableError('mock COM failure')
        with patch.object(psd_source,'_invoke_photoshop',side_effect=changed):
            with self.assertRaisesRegex(psd_source.NativePSDError,'源PSD消失或被改动'):
                psd_source.render_psd({'input':str(self.source),'size':'144x144'},self.root/'cache',plan=full_plan(80,144))

    def test_variant_hash_change_is_rejected_for_grouping(self):
        with self.assertRaisesRegex(psd_source.NativePSDError,'哈希'):
            psd_source.group_psd_sources(self.root/'group.psd',[{'variant_psd':str(self.source),'sha256':'wrong'}])

    def test_group_requires_native_same_size_and_new_destination(self):
        with self.assertRaises(ValueError):psd_source.group_psd_sources(self.root/'group.psd',[])
        with self.assertRaises(ValueError):psd_source.group_psd_sources(self.root/'group.psd',[{'preview_png':'flat.png'}])
        other=synthetic_psd(self.root/'other.psd',(81,80))
        with patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('COM must not run')):
            with self.assertRaises(ValueError):psd_source.group_psd_sources(self.root/'group.psd',[self.source,other])
            destination=self.root/'existing.psd';destination.write_bytes(b'keep original')
            with self.assertRaises(FileExistsError):psd_source.group_psd_sources(destination,[self.source])
            self.assertEqual(destination.read_bytes(),b'keep original')

    def test_external_smart_objects_are_rejected_before_cache_or_com(self):
        details=psd_source.inspect_source(self.source)
        details['linked_smart_objects']=['External product photo']
        with patch.object(psd_source,'inspect_source',return_value=details),patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('COM must not run')):
            with self.assertRaisesRegex(ValueError,'外链智能对象'):
                psd_source.render_psd({'input':str(self.source),'size':'144x144'},self.root/'cache',plan=full_plan(80,144))
            self.assertFalse((self.root/'cache').exists())
            with self.assertRaisesRegex(ValueError,'外链智能对象'):
                psd_source.group_psd_sources(self.root/'group.psd',[{'variant_psd':str(self.source),'sha256':details['sha256']}])
            self.assertFalse((self.root/'group.psd').exists())


@unittest.skipUnless(os.environ.get('RESIZE_NATIVE_PSD_TEST')=='1','Photoshop native integration is explicitly opt-in')
class NativePhotoshopIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='native-psd-integration-');cls.root=Path(cls.temp.name)
        cls.source=cls.root/'complex-source.psd'
        fixture_dir=cls.root/'fixture-call';fixture_dir.mkdir()
        cls.fixture=psd_source._invoke_photoshop({'action':'test_fixture','destination':str(cls.source),'side':800},fixture_dir)
        cls.details=psd_source.inspect_source(cls.source)
        if cls.details['counts']['text']<1 or cls.details['counts']['smart_objects']<1 or cls.details['counts']['masks']<1:
            raise AssertionError('Native fixture did not contain editable text, smart object and mask')
        cls.variant=None

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    @classmethod
    def get_variant(cls):
        if cls.variant is None:
            cls.variant=psd_source.render_psd({'input':str(cls.source),'size':'1440x1440'},cls.root/'cache',plan=full_plan(800,1440))
        return cls.variant

    def test_native_resize_800_to_1440_preserves_real_structure(self):
        image,plan,metadata=self.get_variant()
        self.assertEqual(image.size,(1440,1440));self.assertTrue(metadata['upscale_risk'])
        self.assertTrue(metadata['native_structure_verified']);self.assertEqual(metadata['source_structure'],self.details['native_structure'])
        self.assertEqual(psd_source._hash(self.source),self.details['sha256'])
        after=psd_source.inspect_source(metadata['variant_psd'])
        self.assertEqual(after['counts'],self.details['counts'])
        before_doc,after_doc=PSDImage.open(self.source),PSDImage.open(metadata['variant_psd'])
        before_smart={l.name:l.smart_object.data for l in before_doc.descendants() if l.kind=='smartobject'}
        after_smart={l.name:l.smart_object.data for l in after_doc.descendants() if l.kind=='smartobject'}
        self.assertEqual(before_smart,after_smart)

    def test_native_group_retains_each_source_layers_inside_named_group(self):
        image,plan,metadata=self.get_variant()
        result=psd_source.group_psd_sources(self.root/'grouped.psd',[metadata,metadata],names=['1','2'])
        self.assertEqual(result['panel_order'],['1','2']);self.assertEqual(result['visible_groups'],['1'])
        grouped=psd_source.inspect_source(result['path'])
        self.assertEqual(grouped['counts']['text'],self.details['counts']['text']*2)
        self.assertEqual(grouped['counts']['smart_objects'],self.details['counts']['smart_objects']*2)
        self.assertTrue(result['native_structure_verified'])


if __name__=='__main__':unittest.main(verbosity=2)
