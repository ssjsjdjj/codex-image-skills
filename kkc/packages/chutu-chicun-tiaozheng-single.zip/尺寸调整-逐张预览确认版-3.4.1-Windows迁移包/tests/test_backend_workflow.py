"""Real isolated review/delivery workflows for geometry-bound backend choices."""
import contextlib
import copy
import importlib.util
import io
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
from psd_tools import PSDImage
from psd_tools.api.layers import Group,PixelLayer
from psd_tools.constants import Compression

PACKAGE=Path(os.environ.get('RESIZE_TEST_SKILL',Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng-single'))
sys.path.insert(0,str(PACKAGE/'scripts'))
import psd_source
import python_psd
import user_profile as profile
from backend_policy import BackendChoiceRequired
from review_queue import ReviewQueue
from validate_candidate import load_engine,validate_snapshot

_entry_spec=importlib.util.spec_from_file_location('backend_workflow_entry',PACKAGE/'scripts/resize_assets.py')
entry=importlib.util.module_from_spec(_entry_spec)
_entry_spec.loader.exec_module(entry)


def pixel_psd(path,side=40):
    """Five real pixel layers, intrinsic alpha, independent mask, hidden layer."""
    document=PSDImage.new('RGB',(side,side))
    PixelLayer.frompil(Image.new('RGB',(side,side),'white'),document,'Background')
    for index in range(1,4):
        image=Image.new('RGB',(20,24),(35*index,70,190))
        layer=PixelLayer.frompil(image,document,f'Product{index}',top=8,left=9)
        alpha=Image.new('L',image.size)
        alpha.putdata([50+(i*11)%206 for i in range(image.width*image.height)])
        for info,channel in zip(layer._record.channel_info,layer._channels):
            if int(info.id)==-1:
                channel.compression=Compression.RLE
                channel.set_data(alpha.tobytes(),image.width,image.height,8,1)
                info.length=channel._length
        mask=Image.new('L',image.size)
        mask.putdata([(i*7)%256 for i in range(image.width*image.height)])
        layer.create_mask(mask,top=8,left=9)
        layer.opacity=180+index
    hidden=PixelLayer.frompil(Image.new('RGB',(5,5),'blue'),document,'Hidden',top=2,left=3)
    hidden.visible=False
    document.mark_updated();document.save(path)
    return path


class BackendWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='backend-workflow-')
        self.root=Path(self.temp.name).resolve();self.snapshot=self.root/'snapshot';self.snapshot.mkdir()
        for source,target in [('renderer.py','renderer.py'),('settings.example.json','settings.json'),
                              ('personal_prompt.example.md','personal_prompt.md')]:
            shutil.copyfile(PACKAGE/'assets'/source,self.snapshot/target)
        validation=validate_snapshot(self.snapshot,self.root/'validation')
        self.assertTrue(validation['passed'],validation)
        self.store=profile.Store(self.root/'isolated-state')
        self.store.initialize(self.snapshot,'隔离后端测试模拟初始批准；不涉及正式账号',validation)
        self.engine=load_engine(self.snapshot);self.engine.native_cache_root=self.store.root/'native-psd-cache'
        self.queue=ReviewQueue(self.store,self.engine)
        self.sources=self.root/'sources';self.sources.mkdir()
        self.output=self.root/'delivery';self.spec=self.root/'job.json'

    def tearDown(self):self.temp.cleanup()

    def photo(self,name='photo.png',size=(40,40)):
        path=self.sources/name;Image.new('RGB',size,(65,130,200)).save(path);return path

    def task(self,paths,kind='scene',sizes=('72x72',),**job_options):
        profile.write_json(self.spec,{'delivery':{'kind':kind,'style_id':'BACKEND-TEST',
             'out_dir':str(self.output),'sizes':list(sizes),'naming':'style_size_index','format':'jpg'},
             'product_focus':{'category':'隔离测试商品'},
             'jobs':[{'input':str(path),**job_options} for path in paths]})
        return self.queue.start(self.spec)['review_id']

    def cli(self,args):
        with contextlib.redirect_stdout(io.StringIO()) as stream:entry.run(self.store,args)
        return json.loads(stream.getvalue())

    def confirm(self,rid):
        current=self.queue.next(rid)
        self.assertNotIn('requires_backend_choice',current)
        return self.queue.confirm(rid,current['digest'],'隔离测试模拟人工批准当前预览')

    def assert_no_pixels(self,rid):
        self.assertFalse(self.output.exists())
        self.assertFalse(self.engine.native_cache_root.exists())
        self.assertEqual(list(self.queue.path(rid).parent.glob('*.jpg')),[])
        self.assertEqual(list(self.queue.path(rid).parent.glob('*.png')),[])

    def test_scene_upscale_waits_before_any_target_render_or_preview(self):
        rid=self.task([self.photo()])
        with patch.object(self.engine,'_paint',side_effect=AssertionError('no pixels before choice')) as paint,\
             patch.object(python_psd,'render_python_psd') as py,patch.object(psd_source,'render_psd') as ps:
            current=self.queue.next(rid)
        self.assertTrue(current['requires_backend_choice']);self.assertIsNone(current['preview'])
        self.assertAlmostEqual(current['risk']['scale'],1.8)
        paint.assert_not_called();py.assert_not_called();ps.assert_not_called()
        self.assert_no_pixels(rid)
        item=self.queue.load(rid)['items'][0]
        self.assertEqual(item['status'],'awaiting_backend_choice');self.assertEqual(item['attempts'],[])
        with self.assertRaises(ValueError):self.queue.confirm(rid,'missing','不能把提示当预览批准')

    def test_main_psd_upscale_waits_before_pixel_backend_and_cache(self):
        source=pixel_psd(self.sources/'main.psd');before=profile.file_hash(source)
        rid=self.task([source],kind='main')
        with patch.object(python_psd,'render_python_psd') as py,patch.object(psd_source,'render_psd') as ps:
            current=self.queue.next(rid)
        py.assert_not_called();ps.assert_not_called();self.assert_no_pixels(rid)
        self.assertTrue(current['requires_backend_choice']);self.assertEqual(current['risk']['source_size'],[40,40])
        self.assertEqual(profile.file_hash(source),before)

    def test_scene_python_choice_from_cli_file_then_real_preview_and_delivery(self):
        rid=self.task([self.photo()]);self.assertTrue(self.queue.next(rid)['requires_backend_choice'])
        text='  隔离测试：这张选Python，知道放大可能显软。\n仅本图本尺寸。  '
        confirmation=self.root/'confirmation.txt';confirmation.write_text(text,encoding='utf-8')
        selected=self.cli(['review-select-backend','--review',rid,'--backend','python',
                           '--confirmation-file',str(confirmation)])
        self.assertEqual(selected['from_candidate'],1);self.assertEqual(selected['to_candidate'],1)
        choice=self.queue.load(rid)['items'][0]['job']['_backend_choice']
        self.assertEqual(choice['confirmation'],text);self.assertFalse(self.output.exists())
        with patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('Python must not invoke PS')):
            self.confirm(rid);result=self.cli(['batch','--review',rid])
        self.assertEqual(len(result),1)
        image=self.output/'图片/72x72/BACKEND-TEST_72x72_1.jpg'
        with Image.open(image) as opened:self.assertEqual(opened.size,(72,72))
        self.assertTrue((self.output/'源文件/BACKEND-TEST_72x72.psd').is_file())
        record=self.store.batch_record(self.queue.load(rid)['execution_batch'])
        self.assertEqual(record['status'],'completed')
        self.assertEqual(record['items'][0]['source_metadata']['processing']['backend'],'python')

    def test_main_python_real_group_preserves_five_layers_alpha_mask_and_hidden_state(self):
        source=pixel_psd(self.sources/'main.psd');before=profile.file_hash(source)
        rid=self.task([source],kind='main');self.assertTrue(self.queue.next(rid)['requires_backend_choice'])
        self.queue.select_backend(rid,'python','隔离测试模拟人工选择Python放大主图PSD')
        with patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('Python must not call PS')):
            current=self.queue.next(rid);self.assertTrue(Path(current['preview']).is_file())
            self.queue.confirm(rid,current['digest'],'隔离测试模拟人工确认主图预览')
            self.cli(['batch','--review',rid])
        result=PSDImage.open(self.output/'源文件/BACKEND-TEST_72x72.psd')
        self.assertEqual(result.size,(72,72));self.assertEqual([layer.name for layer in result],['1'])
        group=result[0];self.assertTrue(group.is_group());self.assertEqual(len(group),5)
        self.assertEqual([layer.name for layer in group],['Background','Product1','Product2','Product3','Hidden'])
        self.assertEqual([layer.visible for layer in group],[True,True,True,True,False])
        self.assertEqual([layer.opacity for layer in list(group)[1:4]],[181,182,183])
        record=self.store.batch_record(self.queue.load(rid)['execution_batch'])
        metadata=record['items'][0]['source_metadata'];variant=PSDImage.open(metadata['variant_psd'])
        for index in range(1,4):
            actual=python_psd.read_channels(group[index]);expected=python_psd.read_channels(variant[index])
            self.assertEqual(set(actual),{-1,0,1,2,-2})
            self.assertEqual(actual[-2].tobytes(),expected[-2].tobytes())
            self.assertEqual(actual[-1].tobytes(),expected[-1].tobytes())
            self.assertGreater(len(set(actual[-2].getdata())),10)
        self.assertEqual(metadata['backend'],'python-pixel-psd');self.assertEqual(profile.file_hash(source),before)
        self.assertEqual(record['status'],'completed')

    def test_non_upscale_main_psd_uses_python_default_without_manual_choice(self):
        rid=self.task([pixel_psd(self.sources/'main.psd')],kind='main',sizes=['28x28'])
        with patch.object(psd_source,'_invoke_photoshop',side_effect=AssertionError('default Python')):
            current=self.queue.next(rid)
        self.assertTrue(Path(current['preview']).is_file())
        self.assertNotIn('_backend_choice',current['job'])
        analysis=self.engine.processing_plan(current['job'])
        self.assertEqual(analysis['processing']['backend'],'python')
        self.assertEqual(analysis['processing']['choice_source'],'default_python')
        self.assertFalse(analysis['processing']['risk']['risk'])

    def test_explicit_photoshop_selection_only_calls_ps_backend(self):
        rid=self.task([pixel_psd(self.sources/'main.psd')],kind='main')
        self.queue.select_backend(rid,'photoshop','隔离测试模拟人工选PS')
        def photoshop(job,cache,*,plan):
            self.assertEqual(job['_backend_choice']['backend'],'photoshop')
            return Image.new('RGB',(72,72),'green'),plan,{'backend':'photoshop-test','source':job['input']}
        with patch.object(psd_source,'render_psd',side_effect=photoshop) as ps,\
             patch.object(python_psd,'render_python_psd',side_effect=AssertionError('no Python fallback')) as py:
            current=self.queue.next(rid)
        ps.assert_called_once();py.assert_not_called();self.assertTrue(Path(current['preview']).is_file())
        self.assertFalse(self.output.exists())

    def test_selected_photoshop_unavailable_fails_without_python_fallback(self):
        rid=self.task([pixel_psd(self.sources/'main.psd')],kind='main')
        self.queue.select_backend(rid,'photoshop','隔离测试模拟人工选择PS')
        with patch.object(psd_source,'_invoke_photoshop',side_effect=psd_source.PhotoshopUnavailableError('isolated PS unavailable')) as ps,\
             patch.object(python_psd,'render_python_psd',side_effect=AssertionError('no fallback')) as py:
            with self.assertRaisesRegex(psd_source.PhotoshopUnavailableError,'isolated PS unavailable'):self.queue.next(rid)
        ps.assert_called_once();py.assert_not_called();self.assertFalse(self.output.exists())
        self.assertEqual(list(self.queue.path(rid).parent.glob('*.jpg')),[])
        self.assertEqual(list(self.engine.native_cache_root.rglob('variant.psd')),[])
        self.assertNotEqual(self.queue.load(rid)['items'][0]['status'],'previewed')

    def test_photo_photoshop_route_uses_original_pixels_psd_without_python_render(self):
        source=self.photo();rid=self.task([source])
        self.queue.select_backend(rid,'photoshop','隔离测试模拟照片选择PS')
        def photoshop(job,cache,*,plan):
            staged=Path(job['input']);self.assertNotEqual(staged,source)
            document=PSDImage.open(staged);self.assertEqual(document.size,(40,40))
            self.assertEqual(document[0].topil().convert('RGB').getpixel((0,0)),(65,130,200))
            return Image.new('RGB',(72,72),(65,130,200)),plan,{'backend':'photoshop-test','source':str(staged)}
        with patch.object(psd_source,'render_psd',side_effect=photoshop) as ps,\
             patch.object(self.engine,'_paint',side_effect=AssertionError('no Python pixel render')):
            current=self.queue.next(rid)
        ps.assert_called_once();self.assertTrue(Path(current['preview']).is_file())

    def test_photoshop_selector_receives_only_original_resolution_selected_channels(self):
        # A mock verifies the Photoshop interface contract, not real Photoshop.
        source=pixel_psd(self.sources/'selected-main.psd');before=profile.file_hash(source)
        original=PSDImage.open(source);expected={layer.name:python_psd.read_channels(layer)
                                                for layer in original if layer.name in ('Background','Product2')}
        rid=self.task([source],kind='main',source_layers=['Background','Product2'],crop_box=[.25,.25,.75,.75])
        self.queue.select_backend(rid,'photoshop','隔离测试模拟只选背景与Product2后交PS放大')
        returned={}
        def photoshop(job,cache,*,plan):
            staged=Path(job['input']);self.assertNotEqual(staged,source)
            document=PSDImage.open(staged)
            self.assertEqual(document.size,(40,40));self.assertEqual(plan['output_size'],[72,72])
            self.assertEqual([layer.name for layer in document],['Background','Product2'])
            self.assertNotIn('source_layers',job)
            for layer in document:
                channels=python_psd.read_channels(layer)
                self.assertEqual(set(channels),set(expected[layer.name]))
                for identifier,image in channels.items():
                    self.assertEqual(image.tobytes(),expected[layer.name][identifier].tobytes())
            returned['metadata']={'backend':'photoshop-contract-mock','source':str(staged)}
            return Image.new('RGB',(72,72),'green'),plan,returned['metadata']
        with patch.object(psd_source,'render_psd',side_effect=photoshop) as ps,\
             patch.object(python_psd,'_transform',wraps=python_psd._transform) as transform:
            current=self.queue.next(rid)
        ps.assert_called_once();transform.assert_called_once()
        self.assertEqual(list(transform.call_args.args[1]),[0,0,40,40])
        self.assertEqual(tuple(transform.call_args.args[2]),(40,40))
        self.assertTrue(Path(current['preview']).is_file());self.assertFalse(self.output.exists())
        metadata=returned['metadata']
        self.assertEqual(metadata['source'],str(source));self.assertEqual(metadata['source_sha256'],before)
        self.assertEqual(metadata['source_selection']['master_source'],str(source))
        self.assertEqual(metadata['source_selection']['master_sha256'],before)
        self.assertEqual(metadata['source_selection']['selected_names'],['Background','Product2'])
        self.assertEqual(metadata['selection_preprocessing']['original_size'],[40,40])
        self.assertFalse(metadata['selection_preprocessing']['target_resampling'])
        self.assertTrue(metadata['selection_preprocessing']['preserves_original_channels'])
        self.assertFalse(metadata['all_layers_preserved']);self.assertEqual(profile.file_hash(source),before)

    def test_photoshop_selector_with_complex_source_stops_before_ps_or_flattening(self):
        source=pixel_psd(self.sources/'complex-main.psd')
        document=PSDImage.open(source);Group.new(document,'ComplexGroup');document.mark_updated();document.save(source)
        before=profile.file_hash(source)
        rid=self.task([source],kind='main',source_layers=['Background','Product2'])
        self.queue.select_backend(rid,'photoshop','隔离测试模拟复杂源选择PS，不能忽略选层')
        with patch.object(psd_source,'render_psd',side_effect=AssertionError('must not use full master')) as ps,\
             patch.object(python_psd,'_transform',side_effect=AssertionError('unsupported structure must not rasterize')) as transform:
            with self.assertRaisesRegex(ValueError,'先在PS中拆分.*未自动栅格化'):self.queue.next(rid)
        ps.assert_not_called();transform.assert_not_called();self.assertFalse(self.output.exists())
        self.assertEqual(list(self.queue.path(rid).parent.glob('*.jpg')),[])
        self.assertEqual(list(self.engine.native_cache_root.rglob('variant.psd')),[])
        self.assertEqual(profile.file_hash(source),before)

    def test_photoshop_invalid_selector_does_not_silently_use_full_master(self):
        source=pixel_psd(self.sources/'invalid-selection.psd');before=profile.file_hash(source)
        for selection in [[],['Missing'],['Product2','Product2']]:
            with self.subTest(selection=selection):
                rid=self.task([source],kind='main',source_layers=selection)
                self.queue.select_backend(rid,'photoshop','隔离测试模拟PS选择；无效选层应停止')
                with patch.object(psd_source,'render_psd',side_effect=AssertionError('selector must not be ignored')) as ps,\
                     patch.object(python_psd,'_transform',side_effect=AssertionError('invalid selection must not transform')) as transform:
                    with self.assertRaisesRegex(ValueError,'source_layers'):self.queue.next(rid)
                ps.assert_not_called();transform.assert_not_called();self.assertFalse(self.output.exists())
                self.assertEqual(list(self.queue.path(rid).parent.glob('*.jpg')),[])
        self.assertEqual(profile.file_hash(source),before)

    def test_adjusted_crop_invalidates_choice_and_requires_new_choice_before_render(self):
        rid=self.task([self.photo()]);self.queue.select_backend(rid,'python','隔离测试模拟选择原取景Python')
        first=self.queue.next(rid);preview=Path(first['preview']);before=profile.file_hash(preview)
        with patch.object(self.engine,'_paint',side_effect=AssertionError('changed crop must pause')):
            current=self.queue.adjust(rid,{'crop_box':[.25,.25,.75,.75]})
        self.assertTrue(current['requires_backend_choice']);self.assertIn('失效',current['risk']['choice_error'])
        self.assertEqual(len(list(preview.parent.glob('*.jpg'))),1);self.assertEqual(profile.file_hash(preview),before)
        self.assertFalse(self.output.exists())

    def test_changed_input_blocks_existing_queue_and_backend_reselection(self):
        path=self.photo();rid=self.task([path]);self.queue.select_backend(rid,'python','隔离测试模拟选择Python')
        Image.new('RGB',(40,40),'red').save(path)
        with patch.object(self.engine,'_paint',side_effect=AssertionError('changed input must pause')):
            with self.assertRaisesRegex(ValueError,'原图变化'):self.queue.next(rid)
            with self.assertRaisesRegex(ValueError,'原图已变化'):self.queue.select_backend(rid,'python','新选择')
        self.assert_no_pixels(rid)

    def test_size_and_psd_source_layer_changes_invalidate_bound_selection(self):
        source=pixel_psd(self.sources/'main.psd');rid=self.task([source],kind='main')
        self.queue.select_backend(rid,'python','隔离测试模拟Python选择')
        job=self.queue.load(rid)['items'][0]['job']
        for changed in [dict(job,size='80x80'),dict(job,source_layers=['Product1'])]:
            with self.subTest(change=set(changed)-set(job)),self.assertRaises(BackendChoiceRequired):
                self.engine.processing_plan(changed)
        with self.assertRaisesRegex(ValueError,'新建任务'):self.queue.adjust(rid,{'size':'80x80'})
        self.assert_no_pixels(rid)

    def test_custom_geometry_not_1440_label_decides_risk(self):
        for side,target,crop,expected_scale,risk in [(800,'1440x1440',None,1.8,True),
                  (2000,'1440x1440',None,.72,False),(1000,'800x800',[.2,.2,.8,.8],4/3,True)]:
            path=self.photo(f'{side}.png',(side,side))
            job={'input':str(path),'size':target,'psd':True}
            if crop:job['crop_box']=crop
            report=self.engine.processing_plan(job,require_choice=False)['processing']['risk']
            self.assertAlmostEqual(report['scale'],expected_scale);self.assertEqual(report['risk'],risk)
            if risk:
                with self.assertRaises(BackendChoiceRequired):self.engine.processing_plan(job)
            else:self.assertEqual(self.engine.processing_plan(job)['processing']['backend'],'python')
        self.assertFalse(self.output.exists());self.assertFalse(self.engine.native_cache_root.exists())

    def test_explicit_range_binds_each_current_job_but_not_later_job_or_new_batch(self):
        paths=[self.photo(f'{i}.png') for i in range(3)];rid=self.task(paths)
        before=profile.snapshot_digest(self.store.active()[1])
        text='隔离测试模拟人工授权：本批前两张用Python；只限当前尺寸'
        selected=self.queue.select_backend(rid,'python',text,to_index=2)
        self.assertEqual((selected['from_candidate'],selected['to_candidate']),(1,2))
        items=self.queue.load(rid)['items'];self.assertNotIn('_backend_choice',items[2]['job'])
        self.assertNotEqual(items[0]['job']['_backend_choice']['basis_digest'],items[1]['job']['_backend_choice']['basis_digest'])
        for item in items[:2]:
            self.assertEqual(item['backend_choices'][0]['range_end'],2)
            self.assertEqual(item['job']['_backend_choice']['confirmation'],text)
            self.assertEqual(item['status'],'pending')
        self.confirm(rid);self.confirm(rid)
        self.assertTrue(self.queue.next(rid)['requires_backend_choice'])
        other=self.task(paths)
        self.assertTrue(self.queue.next(other)['requires_backend_choice'])
        self.assertEqual(profile.snapshot_digest(self.store.active()[1]),before)
        self.assertEqual(self.store.events('feedback.jsonl'),[])

    def test_range_validation_is_atomic_and_empty_confirmation_does_not_authorize(self):
        paths=[self.photo('a.png'),self.photo('b.png')];rid=self.task(paths)
        before=copy.deepcopy(self.queue.load(rid))
        for end in [0,3,True]:
            with self.assertRaises(ValueError):self.queue.select_backend(rid,'python','模拟选择',to_index=end)
        with self.assertRaises(ValueError):self.queue.select_backend(rid,'python',' \n ',to_index=2)
        self.assertEqual(self.queue.load(rid),before)
        Image.new('RGB',(40,40),'red').save(paths[1])
        with self.assertRaises(ValueError):self.queue.select_backend(rid,'python','模拟选择',to_index=2)
        self.assertEqual(self.queue.load(rid),before)
        self.assert_no_pixels(rid)

    def test_copying_old_choice_into_new_review_cannot_reuse_authorization(self):
        path=self.photo();rid=self.task([path])
        self.queue.select_backend(rid,'python','隔离测试模拟仅旧队列本张Python选择')
        old=self.queue.load(rid)['items'][0]['job']
        # Emulate a caller copying both internal fields into a new spec. start
        # must bind its own review ID rather than trusting the supplied value.
        new=self.task([path],_backend_choice=old['_backend_choice'],_backend_review=rid)
        self.assertNotEqual(new,rid)
        item=self.queue.load(new)['items'][0]
        self.assertEqual(item['job']['_backend_review'],new)
        with patch.object(self.engine,'_paint',side_effect=AssertionError('old review cannot authorize new pixels')):
            current=self.queue.next(new)
        self.assertTrue(current['requires_backend_choice'])
        self.assertIn('失效',current['risk']['choice_error'])
        self.assertEqual(current['risk']['scope']['review_id'],new)
        self.assert_no_pixels(new)

    def test_current_choice_does_not_cover_next_size_of_same_source(self):
        rid=self.task([self.photo()],sizes=['64x64','72x72'])
        selected=self.queue.select_backend(rid,'python','隔离测试模拟仅当前64尺寸选择Python')
        self.assertEqual(selected['to_candidate'],1)
        self.assertEqual(selected['choices'][0]['scope']['size'],'64x64')
        self.confirm(rid)
        current=self.queue.next(rid)
        self.assertEqual(current['index'],2);self.assertTrue(current['requires_backend_choice'])
        self.assertEqual(current['risk']['scope']['size'],'72x72')
        self.assertNotIn('_backend_choice',self.queue.load(rid)['items'][1]['job'])

    def test_plain_photo_diagnostic_without_psd_keeps_legacy_render_behavior(self):
        job={'input':str(self.photo()),'size':'72x72'}
        _,image,plan,resolved=self.engine._render(job)
        self.assertEqual(image.size,(72,72))
        self.assertTrue(resolved['_processing']['risk']['risk'])
        self.assertFalse(self.engine.processing_plan(job)['gated'])
        self.assertEqual(plan['output_size'],[72,72]);self.assertFalse(self.output.exists())


if __name__=='__main__':unittest.main(verbosity=2)
