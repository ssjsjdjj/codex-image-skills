"""Production entry integration: explicit delivery policy, real review gates, files."""
import contextlib
import importlib.util
import io
import json
import os
import random
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image, ImageDraw
from psd_tools import PSDImage

PACKAGE = Path(os.environ.get('RESIZE_TEST_SKILL', Path(__file__).resolve().parents[1]/'skills/chutu-chicun-tiaozheng-single'))
sys.path.insert(0, str(PACKAGE/'scripts'))
import delivery_pack
import user_profile as profile
from review_queue import ReviewQueue
from validate_candidate import load_engine, validate_snapshot

entry_spec = importlib.util.spec_from_file_location('delivery_flow_entry', PACKAGE/'scripts/resize_assets.py')
entry = importlib.util.module_from_spec(entry_spec)
entry_spec.loader.exec_module(entry)


class DeliveryFlowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='resize-delivery-flow-')
        self.root = Path(self.temp.name).resolve()
        self.snapshot = self.root/'snapshot'
        self.snapshot.mkdir()
        for original, name in [('renderer.py','renderer.py'), ('settings.example.json','settings.json'),
                               ('personal_prompt.example.md','personal_prompt.md')]:
            shutil.copyfile(PACKAGE/'assets'/original, self.snapshot/name)
        validation = validate_snapshot(self.snapshot, self.root/'validation')
        self.assertTrue(validation['passed'], validation)
        self.store = profile.Store(self.root/'isolated-state')
        self.revision = self.store.initialize(self.snapshot, '隔离集成测试：模拟初始批准，不授权正式账号', validation)
        self.engine = load_engine(self.snapshot)
        self.queue = ReviewQueue(self.store, self.engine)
        self.sources = self.root/'素材'
        self.sources.mkdir()
        self.output = self.root/'交付'
        self.spec_path = self.root/'本批.json'

    def tearDown(self):
        self.temp.cleanup()

    def pictures(self, count=1, size=(120,160), rgba=False):
        paths = []
        for index in range(count):
            mode = 'RGBA' if rgba else 'RGB'
            color = (20+index*25,80+index*15,170-index*15,0) if rgba else (20+index*25,80+index*15,170-index*15)
            image = Image.new(mode,size,color)
            drawing = ImageDraw.Draw(image)
            if rgba:
                drawing.rectangle((size[0]//5,size[1]//5,size[0]*4//5,size[1]*4//5), fill=(30,130,210,128))
                drawing.rectangle((size[0]//3,size[1]//3,size[0]*2//3,size[1]*2//3), fill=(90,40,150,255))
            else:
                drawing.rectangle((size[0]//4,size[1]//4,size[0]*3//4,size[1]*3//4),fill=(220,90+index*10,40))
            path = self.sources/f'原图{index+1}.png'
            image.save(path)
            paths.append(path)
        return paths

    def task(self, paths, sizes=('64x64','80x80','60x80'), **delivery):
        spec = {'delivery':{'kind':'scene','style_id':'KCT-FLOW','out_dir':str(self.output),
                            'sizes':list(sizes),'naming':'style_size_index','format':'jpg',**delivery},
                'product_focus':{'category':'测试商品'},
                'jobs':[{'input':str(path),'focus':[.5,.5]} for path in paths]}
        profile.write_json(self.spec_path,spec)
        return spec

    def run_entry(self,args):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            entry.run(self.store,args)
        return json.loads(output.getvalue())

    def confirm_all(self):
        # q.start, then one real preview and simulated human confirmation per task.
        started = self.queue.start(self.spec_path)
        rid = started['review_id']
        for index in range(started['total']):
            current = self.queue.next(rid)
            if current.get('requires_backend_choice'):
                self.queue.select_backend(rid,'python','隔离测试模拟人工选择Python；仅报告的风险项',indices=[row['index'] for row in current['risks']])
                current = self.queue.next(rid)
            self.assertEqual(current['index'],index+1)
            self.queue.confirm(rid,current['digest'],f'隔离生产入口验收：模拟用户批准当前任务{index+1}')
        self.assertTrue(self.queue.ready(rid))
        return rid

    def batch(self,rid,resume=False):
        return self.run_entry(['batch','--review',rid,*(['--resume'] if resume else [])])

    def record(self,rid):
        return self.store.batch_record(self.queue.load(rid)['execution_batch'])

    def stamp(self,path):
        path = Path(path)
        stat = path.stat()
        return (profile.file_hash(path),stat.st_mtime_ns,stat.st_size)

    def assert_psd(self,path,size,count):
        doc = PSDImage.open(path)
        self.assertEqual(doc.size,tuple(size))
        self.assertEqual([layer.name for layer in reversed(list(doc))],[str(i) for i in range(1,count+1)])
        self.assertEqual([layer.name for layer in doc if layer.visible],['1'])
        self.assertIsNotNone(doc.composite(apply_icc=False))

    def fail_second_group(self,rid):
        writer = delivery_pack.write_layered_psd
        calls = []
        def injected(path,images,**options):
            calls.append(str(path))
            if len(calls)==2:
                raise OSError('模拟第二组PSD写入失败')
            return writer(path,images,**options)
        with patch.object(delivery_pack,'write_layered_psd',side_effect=injected),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(OSError,'第二组PSD写入失败'):
                self.batch(rid)
        self.assertEqual(len(calls),2)
        record = self.record(rid)
        self.assertEqual(record['status'],'partial')
        self.assertEqual(sum(g['status']=='completed' for g in record['grouped_psds'].values()),1)
        self.assertEqual(self.store.active()[0],self.revision)
        return record

    def test_five_photos_three_sizes_create_fifteen_images_three_psds_and_two_notes(self):
        paths = self.pictures(5)
        before = {str(path):profile.file_hash(path) for path in paths}
        self.task(paths)
        rid = self.confirm_all()
        self.assertFalse(self.output.exists())
        result = self.batch(rid)
        self.assertEqual(len(result),15)
        self.assertEqual(len(list((self.output/'图片').rglob('*.jpg'))),15)
        self.assertEqual(len(list((self.output/'源文件').glob('*.psd'))),3)
        self.assertEqual({p.name for p in self.output.iterdir()},{'图片','源文件','使用提示词.txt','本批处理说明.txt'})
        for size in ['64x64','80x80','60x80']:
            width,height = map(int,size.split('x'))
            for index in range(1,6):
                path = self.output/'图片'/size/f'KCT-FLOW_{size}_{index}.jpg'
                with Image.open(path) as image:
                    self.assertEqual(image.size,(width,height));self.assertEqual(image.mode,'RGB');self.assertEqual(image.format,'JPEG')
                self.assertLessEqual(path.stat().st_size,500000)
            self.assert_psd(self.output/'源文件'/f'KCT-FLOW_{size}.psd',(width,height),5)
        record = self.record(rid)
        self.assertEqual(record['status'],'completed')
        self.assertEqual(len(record['delivery_notes']),2)
        self.assertEqual(len(record['outputs']),18)
        for item in record['items']:
            self.assertEqual(item['status'],'completed')
            for path,sha in item['output_sha256'].items():self.assertEqual(profile.file_hash(path),sha)
        self.assertEqual({str(path):profile.file_hash(path) for path in paths},before)
        self.assertEqual(self.store.events('feedback.jsonl'),[])
        report = (self.output/'本批处理说明.txt').read_text(encoding='utf-8')
        self.assertIn('completed',report);self.assertIn('KCT-FLOW',report)
        self.assertEqual(self.store.mark_asked(record['id'])['ask_now'],True)
        self.assertEqual(self.store.mark_asked(record['id'])['ask_now'],False)

    def test_real_800_1440_and_750x1000_output_sizes(self):
        self.task(self.pictures(),sizes=['800x800','1440x1440','750x1000'])
        rid = self.confirm_all();result = self.batch(rid)
        self.assertEqual(len(result),3)
        for size in ['800x800','1440x1440','750x1000']:
            expected = tuple(map(int,size.split('x')))
            image_path = self.output/'图片'/size/f'KCT-FLOW_{size}_1.jpg'
            with Image.open(image_path) as image:self.assertEqual(image.size,expected)
            self.assertLessEqual(image_path.stat().st_size,500000)
            self.assert_psd(self.output/'源文件'/f'KCT-FLOW_{size}.psd',expected,1)

    def test_custom_size_and_explicit_complete_templates(self):
        naming = {'image':'商品_{style_id}_{size}_{index:02d}.jpg','psd':'源_{style_id}_{size}.psd'}
        self.task(self.pictures(),sizes=['113x157'],naming=naming)
        rid = self.confirm_all();self.batch(rid)
        image_path = self.output/'图片/113x157/商品_KCT-FLOW_113x157_01.jpg'
        with Image.open(image_path) as image:self.assertEqual(image.size,(113,157))
        self.assert_psd(self.output/'源文件/源_KCT-FLOW_113x157.psd',(113,157),1)
        self.assertFalse((self.output/'图片/800x800').exists())

    def test_missing_naming_defaults_to_source_numbers_per_size(self):
        spec = self.task(self.pictures());spec['delivery'].pop('naming');profile.write_json(self.spec_path,spec)
        result=self.run_entry(['review-start','--spec',str(self.spec_path)])
        record=self.queue.load(result['review_id'])
        self.assertEqual(record['delivery_policy']['naming'],'numbered')
        self.assertEqual([item['job']['name'] for item in record['items']],['1','1','1'])
        self.assertFalse(self.output.exists())

    def test_missing_sizes_does_not_create_a_queue_or_outputs(self):
        spec = self.task(self.pictures());spec['delivery'].pop('sizes');profile.write_json(self.spec_path,spec)
        with self.assertRaisesRegex(ValueError,'人工选择输出尺寸'):
            self.run_entry(['review-start','--spec',str(self.spec_path)])
        self.assertEqual(list((self.store.root/'reviews').glob('r-*')),[])
        self.assertFalse(self.output.exists())

    def test_white_operation_is_rejected_without_creating_queue(self):
        self.task(self.pictures(),kind='white',sizes=['800x800'])
        with self.assertRaises(ValueError):self.run_entry(['review-start','--spec',str(self.spec_path)])
        self.assertEqual(list((self.store.root/'reviews').glob('r-*')),[])
        self.assertFalse(self.output.exists())

    def test_main_accepts_jpg_input_and_defers_target_pixels_until_review(self):
        path = self.sources/'photo.jpg';Image.new('RGB',(120,160),'red').save(path)
        before=profile.file_hash(path)
        self.task([path],kind='main',sizes=['800x800'])
        result=self.run_entry(['review-start','--spec',str(self.spec_path)])
        record=self.queue.load(result['review_id'])
        self.assertEqual(result['total'],1)
        self.assertEqual(record['delivery_policy']['kind'],'main')
        self.assertEqual(record['delivery_policy']['source_type'],'photos')
        self.assertEqual(record['items'][0]['job']['input'],str(path.resolve()))
        self.assertEqual(record['items'][0]['status'],'pending')
        self.assertEqual(profile.file_hash(path),before)
        self.assertFalse(self.output.exists())

    def test_legacy_spec_is_rejected_at_production_review_entry(self):
        path = self.pictures()[0]
        profile.write_json(self.spec_path,{'jobs':[{'input':str(path),'size':'64x64','out_dir':str(self.output)}]})
        with self.assertRaisesRegex(ValueError,'delivery'):
            self.run_entry(['review-start','--spec',str(self.spec_path)])
        self.assertEqual(list((self.store.root/'reviews').glob('r-*')),[])
        self.assertFalse(self.output.exists())

    def test_legacy_confirmed_queue_is_rejected_at_production_batch_entry(self):
        path = self.pictures()[0]
        profile.write_json(self.spec_path,{'jobs':[{'input':str(path),'size':'64x64','out_dir':str(self.output)}]})
        rid = self.confirm_all()
        with self.assertRaisesRegex(ValueError,'旧裁切队列'):self.batch(rid)
        self.assertFalse(self.output.exists())
        self.assertEqual(list((self.store.root/'batches').glob('*.json')),[])

    def test_png_semialpha_stays_exact_in_image_and_grouped_psd(self):
        path = self.pictures(size=(64,64),rgba=True)[0]
        with Image.open(path) as opened:expected = opened.copy()
        spec=self.task([path],sizes=['64x64'])
        spec['delivery'].pop('format')
        profile.write_json(self.spec_path,spec)
        rid = self.confirm_all();result = self.batch(rid)
        with Image.open(result[0]['outputs'][0]) as saved:
            self.assertEqual(saved.mode,'RGBA');self.assertEqual(saved.tobytes(),expected.tobytes())
            self.assertEqual(saved.getchannel('A').getextrema(),(0,255))
            self.assertIn(128,set(saved.getchannel('A').getdata()))
        psd = PSDImage.open(self.output/'源文件/KCT-FLOW_64x64.psd')
        layer = next(layer for layer in psd if layer.name=='1')
        self.assertEqual(layer.topil(apply_icc=False).convert('RGBA').tobytes(),expected.tobytes())
        self.assertLessEqual(Path(result[0]['outputs'][0]).stat().st_size,500000)

    def test_cache_unlink_failure_does_not_downgrade_completed_delivery(self):
        self.task(self.pictures(),sizes=['64x64']);rid=self.confirm_all()
        unlink=Path.unlink
        def injected(path,*args,**kwargs):
            if path.parent.name=='psd-render-cache' and path.suffix=='.png' and path.stem.isdecimal():
                raise PermissionError('模拟无损PNG缓存unlink失败')
            return unlink(path,*args,**kwargs)
        with patch.object(Path,'unlink',injected),contextlib.redirect_stderr(io.StringIO()):
            result=self.batch(rid)
        record=self.record(rid)
        self.assertEqual(record['status'],'completed')
        self.assertTrue(record['feedback_due'])
        self.assertIn('unlink失败',record['cleanup_warnings'][0])
        self.assertIn('unlink失败',result[0]['cleanup_warnings'][0])
        self.assertEqual(len(list((self.output/'图片').rglob('*.jpg'))),1)
        self.assertEqual(len(list((self.output/'源文件').glob('*.psd'))),1)
        self.assertIn('记录时批次状态：completed',(self.output/'本批处理说明.txt').read_text(encoding='utf-8'))

    def pending_after_publication_receipt_failure(self):
        self.task(self.pictures(),sizes=['64x64']);rid=self.confirm_all()
        write=delivery_pack.write_json
        injected=[False]
        def fail_receipt(path,value):
            groups=value.get('grouped_psds',{})
            if not injected[0] and any(group.get('status')=='completed' for group in groups.values()):
                injected[0]=True
                raise OSError('模拟PSD已发布后成功记录写入失败')
            return write(path,value)
        with patch.object(delivery_pack,'write_json',side_effect=fail_receipt),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(OSError,'已发布后成功记录写入失败'):
                self.batch(rid)
        self.assertTrue(injected[0])
        record=self.record(rid)
        self.assertEqual(record['status'],'partial')
        group=next(iter(record['grouped_psds'].values()))
        self.assertEqual(group['status'],'pending_publication')
        self.assertTrue(Path(group['destination']).is_file())
        self.assertTrue(Path(group['staged_path']).is_file())
        self.assertEqual(profile.file_hash(group['destination']),group['sha256'])
        self.assertEqual(profile.file_hash(group['staged_path']),group['sha256'])
        self.assertEqual(group['published_outputs'],[group['destination']])
        self.assertFalse((self.output/'本批处理说明.txt').exists())
        return rid,group

    def test_published_psd_receipt_failure_resumes_without_rebuilding_or_rewriting(self):
        rid,group=self.pending_after_publication_receipt_failure()
        psd_stamp=self.stamp(group['destination'])
        image_stamps={str(p):self.stamp(p) for p in (self.output/'图片').rglob('*.jpg')}
        with patch.object(delivery_pack,'write_layered_psd',side_effect=AssertionError('不能重建已验证暂存PSD')):
            self.batch(rid,resume=True)
        self.assertEqual(self.record(rid)['status'],'completed')
        self.assertEqual(self.stamp(group['destination']),psd_stamp)
        self.assertEqual({str(p):self.stamp(p) for p in (self.output/'图片').rglob('*.jpg')},image_stamps)
        self.assertTrue((self.output/'本批处理说明.txt').is_file())

    def test_pending_psd_changed_stage_refuses_resume_without_rewriting_outputs(self):
        rid,group=self.pending_after_publication_receipt_failure()
        psd_stamp=self.stamp(group['destination'])
        image_stamps={str(p):self.stamp(p) for p in (self.output/'图片').rglob('*.jpg')}
        Path(group['staged_path']).write_bytes(b'changed verified stage')
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaisesRegex(ValueError,'暂存版本缺失或哈希变化'):
            self.batch(rid,resume=True)
        self.assertEqual(self.stamp(group['destination']),psd_stamp)
        self.assertEqual({str(p):self.stamp(p) for p in (self.output/'图片').rglob('*.jpg')},image_stamps)

    def test_pending_psd_unknown_target_is_not_adopted_or_overwritten(self):
        rid,group=self.pending_after_publication_receipt_failure()
        Path(group['destination']).write_bytes(b'unknown different PSD')
        before=self.stamp(group['destination'])
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaisesRegex(ValueError,'不匹配可信暂存版本'):
            self.batch(rid,resume=True)
        self.assertEqual(self.stamp(group['destination']),before)

    def test_jpg_budget_does_not_limit_psd_and_psd_uses_lossless_cache(self):
        size = (800,800)
        expected = random.Random(20261029).randbytes(size[0]*size[1]*3)
        path = self.sources/'随机RGB.png';Image.frombytes('RGB',size,expected).save(path)
        self.task([path],sizes=['800x800'])
        rid = self.confirm_all()
        original_writer = delivery_pack.write_layered_psd
        captured = []
        def inspect_cache(target,images,**options):
            captured.extend(image.convert('RGB').tobytes() for image in images)
            return original_writer(target,images,**options)
        with patch.object(delivery_pack,'write_layered_psd',side_effect=inspect_cache):result = self.batch(rid)
        image_path = Path(result[0]['outputs'][0])
        self.assertLessEqual(image_path.stat().st_size,500000)
        self.assertLess(result[0]['encoding']['quality'],95)
        self.assertEqual(captured,[expected])
        with Image.open(image_path) as jpg:self.assertNotEqual(jpg.convert('RGB').tobytes(),expected)
        psd_path = self.output/'源文件/KCT-FLOW_800x800.psd'
        self.assertGreater(psd_path.stat().st_size,500000)
        psd = PSDImage.open(psd_path);layer = next(layer for layer in psd if layer.name=='1')
        self.assertEqual(layer.topil(apply_icc=False).convert('RGB').tobytes(),expected)
        self.assertEqual(self.record(rid)['status'],'completed')

    def test_second_psd_failure_resume_keeps_successful_psd_and_all_jpgs(self):
        self.task(self.pictures(2))
        rid = self.confirm_all();record = self.fail_second_group(rid)
        images = list((self.output/'图片').rglob('*.jpg'))
        self.assertEqual(len(images),6)
        before_images = {str(path):self.stamp(path) for path in images}
        completed_group = next(group for group in record['grouped_psds'].values() if group['status']=='completed')
        successful = completed_group['outputs'][0];before_psd = self.stamp(successful)
        self.assertFalse((self.output/'本批处理说明.txt').exists())
        self.batch(rid,resume=True)
        self.assertEqual(before_images,{str(path):self.stamp(path) for path in images})
        self.assertEqual(before_psd,self.stamp(successful))
        self.assertEqual(len(list((self.output/'源文件').glob('*.psd'))),3)
        self.assertEqual(self.record(rid)['status'],'completed')
        self.assertTrue((self.output/'使用提示词.txt').is_file());self.assertTrue((self.output/'本批处理说明.txt').is_file())

    def test_changed_completed_psd_hash_blocks_resume(self):
        self.task(self.pictures(2));rid = self.confirm_all();record = self.fail_second_group(rid)
        successful = next(group['outputs'][0] for group in record['grouped_psds'].values() if group['status']=='completed')
        Path(successful).write_bytes(b'changed-psd')
        images = {str(path):self.stamp(path) for path in (self.output/'图片').rglob('*.jpg')}
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaisesRegex(ValueError,'PSD变化或缺失'):
            self.batch(rid,resume=True)
        self.assertEqual(Path(successful).read_bytes(),b'changed-psd')
        self.assertEqual(images,{str(path):self.stamp(path) for path in (self.output/'图片').rglob('*.jpg')})
        self.assertEqual(self.record(rid)['status'],'partial')

    def test_changed_lossless_cache_hash_blocks_resume(self):
        self.task(self.pictures(2));rid = self.confirm_all();record = self.fail_second_group(rid)
        failed_key=next(key for key,group in record['grouped_psds'].items() if group['status']=='failed')
        jobs=[item['job'] for item in self.queue.load(rid)['items']]
        needed=next(index for index,job in enumerate(jobs) if Path(job['_delivery']['psd_path'])==Path(failed_key))
        cache = Path(record['items'][needed]['source_cache']['path'])
        self.assertTrue(cache.is_file());cache.write_bytes(b'changed-lossless-cache')
        images = {str(path):self.stamp(path) for path in (self.output/'图片').rglob('*.jpg')}
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaisesRegex(ValueError,'无损源缓存'):
            self.batch(rid,resume=True)
        self.assertEqual(images,{str(path):self.stamp(path) for path in (self.output/'图片').rglob('*.jpg')})
        self.assertEqual(self.record(rid)['status'],'partial')
        self.assertEqual(len(list((self.output/'源文件').glob('*.psd'))),1)

    def test_preexisting_psd_blocks_review_before_any_image_write(self):
        self.task(self.pictures(),sizes=['64x64'])
        path = self.output/'源文件/KCT-FLOW_64x64.psd';path.parent.mkdir(parents=True);path.write_bytes(b'original')
        before = self.stamp(path)
        with self.assertRaises(ValueError):self.run_entry(['review-start','--spec',str(self.spec_path)])
        self.assertEqual(self.stamp(path),before)
        self.assertFalse((self.output/'图片').exists())
        self.assertEqual(list((self.store.root/'reviews').glob('r-*')),[])

    def test_psd_conflict_after_confirmation_blocks_before_image_delivery(self):
        self.task(self.pictures(),sizes=['64x64']);rid = self.confirm_all()
        path = self.output/'源文件/KCT-FLOW_64x64.psd';path.parent.mkdir(parents=True);path.write_bytes(b'original')
        before = self.stamp(path)
        with contextlib.redirect_stderr(io.StringIO()),self.assertRaisesRegex(ValueError,'PSD目标已存在'):
            self.batch(rid)
        self.assertEqual(self.stamp(path),before)
        self.assertFalse((self.output/'图片').exists())
        self.assertEqual(self.record(rid)['status'],'failed')


if __name__ == '__main__':
    unittest.main(verbosity=2)
