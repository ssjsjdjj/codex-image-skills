"""Single-preview variant: real isolated output and no batch-approval bypass."""
import json
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
import test_delivery_flow as flow_helpers
import user_profile as profile


class SingleVariantTests(unittest.TestCase):
    def setUp(self):
        self.f = flow_helpers.DeliveryFlowTests(methodName='runTest')
        self.f.setUp()

    def tearDown(self):
        self.f.tearDown()

    def task(self, sizes=('64x64', '60x80'), count=2):
        f = self.f
        paths = f.pictures(count=count, size=(160, 200))
        spec = f.task(paths, sizes=sizes, kind='main', naming='numbered')
        profile.write_json(f.spec_path, spec)
        return f.queue.start(f.spec_path)

    def test_start_defaults_to_individual_and_repeated_next_does_not_advance(self):
        f = self.f
        started = self.task()
        rid = started['review_id']
        self.assertIn('review-next', started['next'])
        self.assertEqual(f.queue.load(rid)['review_mode'], 'individual')
        with patch.object(f.engine, '_render', wraps=f.engine._render) as render:
            first = f.queue.next(rid)
            again = f.queue.next(rid)
        self.assertEqual(render.call_count, 1)
        self.assertEqual(first['index'], 1)
        self.assertEqual(first['digest'], again['digest'])
        self.assertEqual(first['preview'], again['preview'])
        record = f.queue.load(rid)
        self.assertEqual([item['status'] for item in record['items']], ['previewed', 'pending', 'pending', 'pending'])
        self.assertFalse(f.output.exists())

    def test_current_digest_changes_after_adjustment_and_old_confirmation_is_rejected(self):
        f = self.f
        rid = self.task()['review_id']
        first = f.queue.next(rid)
        f.queue.adjust(rid, {'focus': [.5, .4]})
        with self.assertRaises(ValueError):
            f.queue.confirm(rid, first['digest'], '隔离测试旧预览确认必须被拒绝')
        refreshed = f.queue.next(rid)
        self.assertNotEqual(first['digest'], refreshed['digest'])
        self.assertEqual(refreshed['index'], 1)
        self.assertTrue(all(item['status'] == 'pending' for item in f.queue.load(rid)['items'][1:]))

    def test_batch_preview_batch_confirmation_and_style_delegation_are_disabled(self):
        f = self.f
        rid = self.task()['review_id']
        for operation in [lambda: f.queue.preview_all(rid),
                          lambda: f.queue.confirm_all(rid, 'no-batch-digest', '隔离模拟整批确认'),
                          lambda: f.queue.authorize_style(rid, '隔离模拟风格授权', 1)]:
            with self.assertRaisesRegex(ValueError, '逐张版禁止'):
                operation()
        self.assertTrue(all(item['status'] == 'pending' for item in f.queue.load(rid)['items']))

    def test_full_risk_preflight_blocks_even_a_safe_current_preview(self):
        f = self.f
        rid = self.task(sizes=('64x64', '288x288'), count=2)['review_id']
        with patch.object(f.engine, '_render', side_effect=AssertionError('no pixels before all choices')) as render:
            result = f.queue.next(rid)
        render.assert_not_called()
        self.assertTrue(result['requires_backend_choice'])
        self.assertEqual([row['index'] for row in result['risks']], [3, 4])
        self.assertTrue(all('建议使用Photoshop' in row['risk']['message'] for row in result['risks']))
        self.assertFalse(f.output.exists())
        self.assertTrue(all(not item['attempts'] for item in f.queue.load(rid)['items']))
        f.queue.select_backend(rid, 'python', '隔离测试选择所有报告风险项使用Python', indices=[3, 4])
        current = f.queue.next(rid)
        self.assertEqual(current['index'], 1)
        self.assertTrue(all(item['status'] != 'confirmed' for item in f.queue.load(rid)['items']))

    def test_each_preview_requires_confirmation_before_next_and_final_delivery(self):
        f = self.f
        rid = self.task()['review_id']
        for index in range(1, 5):
            current = f.queue.next(rid)
            self.assertEqual(current['index'], index)
            with self.assertRaises(ValueError):
                f.queue.ready(rid)
            self.assertTrue(all(not item.get('preview') for item in f.queue.load(rid)['items'][index:]))
            f.queue.confirm(rid, current['digest'], f'隔离测试模拟逐张确认第{index}张；不批准实际业务')
        self.assertTrue(f.queue.next(rid)['ready'])
        record = f.queue.ready(rid)
        self.assertTrue(all(item['confirmation_kind'] == 'human_current_preview_confirmation' for item in record['items']))
        f.batch(rid)
        batch = f.record(rid)
        self.assertEqual(batch['status'], 'completed')
        self.assertEqual(len(list((f.output/'图片').rglob('*.jpg'))), 4)
        self.assertEqual(len(list((f.output/'源文件').glob('*.psd'))), 2)
        evidence = batch['preview_confirmation']
        self.assertEqual(evidence['kind'], 'human_individual_preview_confirmations')
        self.assertEqual(len(evidence['items']), 4)
        for index, row in enumerate(evidence['items'], 1):
            self.assertIn(f'第{index}张', row['text'])
            self.assertEqual(len(row['digest']), 64)
        for size in ['64x64', '60x80']:
            f.assert_psd(f.output/'源文件'/f'KCT-FLOW_{size}.psd', tuple(map(int, size.split('x'))), 2)
            for path in (f.output/'图片'/size).glob('*.jpg'):
                self.assertLessEqual(path.stat().st_size, 500000)

    def test_direct_png_keeps_alpha_and_psd_without_changing_format(self):
        f = self.f
        spec = f.task(f.pictures(count=1, rgba=True), sizes=['64x64'], kind='main', naming='numbered')
        spec['delivery'].pop('format')
        profile.write_json(f.spec_path, spec)
        rid = f.queue.start(f.spec_path)['review_id']
        preview = f.queue.next(rid)
        f.queue.confirm(rid, preview['digest'], '隔离测试模拟确认透明PNG当前预览')
        f.batch(rid)
        path = f.output/'图片/64x64/1.png'
        with Image.open(path) as image:
            self.assertEqual(image.mode, 'RGBA')
            self.assertLess(image.getchannel('A').getextrema()[0], 255)
        f.assert_psd(f.output/'源文件/KCT-FLOW_64x64.psd', (64, 64), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
