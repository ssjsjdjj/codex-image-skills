import contextlib
import importlib.util
import io
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from PIL import Image
import user_profile as profile
from validate_candidate import validate_snapshot

BUNDLE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('tested_deployment',BUNDLE/'deployment.py')
deployment=importlib.util.module_from_spec(spec);spec.loader.exec_module(deployment)


# Exact policy sentences from the shipped 3.3 personal_prompt.example.md. Keep
# the fixture here so this portable test never reads an installed account.
V33_PREVIEW='- 默认按源图及所选尺寸逐候选预览和调整，当前候选经真实确认后才开始下一项；未回复不算确认。用户明确授权本批按已确认风格生成后续时，记录真实原文、参考和适用范围，逐图复核后执行，不声称人类逐张看过；该授权不跨批、不改变长期规则。单次构图确认不自动形成长期偏好。'
V33_SIZES='- 每批人工选择800×800、1440×1440、750×1000或人工输入尺寸，可多选，只出所选项。'
V33_NAMING='- 每批收集图片与PSD命名，不自行猜款号或套默认；用户明确授权本批自动命名时可采用生成方案并告知，不编造人工输入。'
V33_SELECTION='- 一份PSD含多图不自动拆job。用户明确取01—05等图层/颜色范围后，每张建立同一input、不同source_layers的job；白底选对应商品层和真实背景层，透明不加背景，逐张预览。未选范围不能自动拆；保留的是所选源层子集，metadata说明不是master全部层。'
CUSTOM_PREFERENCES='本账号自定义帽檐留空间\n自定义参数：左边距12像素；帽顶保护框[0.1,0.1,0.9,0.8]；不要固定居中。\n反馈规则：三个不同批次后提出草案，审批后生效。\n'
FORMAT_RULE='- 未明确改格式时，已有PNG仍输出PNG保留原alpha，JPG/JPEG仍输出JPG；已有PSD未指定成品图片格式时默认JPG并告知。'


class DeploymentTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='resize-install-')
        self.root=Path(self.temp.name);self.runtime=self.root/'runtime';self.runtime.mkdir()
        self.target=self.runtime/'installed-skill';self.target.mkdir();(self.target/'old.txt').write_text('preserve original skill')
        self.candidate=self.runtime/'candidate';shutil.copytree(deployment.SOURCE,self.candidate)
        self.python=str(Path(sys.executable).resolve())
        profile.write_json(self.candidate/'runtime.json',{'schema':1,'python':self.python,'runtime':str(self.runtime)})
        self.draft=self.runtime/'draft';snapshot=self.draft/'snapshot';snapshot.mkdir(parents=True)
        for src,dst in [('settings.example.json','settings.json'),('personal_prompt.example.md','personal_prompt.md'),('renderer.py','renderer.py')]:
            shutil.copyfile(deployment.SOURCE/'assets'/src,snapshot/dst)
        self.source=self.runtime/'source.png';Image.new('RGB',(240,400),'blue').save(self.source)
        self.spec=self.runtime/'jobs.json';profile.write_json(self.spec,{'defaults':{'size':'240x240'},'jobs':[{'input':str(self.source)}]})
        report=validate_snapshot(snapshot,self.draft/'previews',[{'input':str(self.source),'size':'240x240'}])
        self.assertTrue(report['passed'],report);profile.write_json(self.draft/'validation.json',report)
        self.log=self.runtime/'workflow.txt';self.log.write_text('fixture; full tests run separately')
        self.plan_path=self.runtime/'plan.json';self.profile=self.runtime/'profile'
        self.plan={'schema':1,'status':'prepared','kind':'initial','base_revision':None,'owner_id':profile.owner_id(),
                   'python':self.python,'runtime':str(self.runtime),'target':str(self.target),'profile':str(self.profile),
                   'isolated_test':True,'candidate':str(self.candidate),'payload':deployment.payload(deployment.SOURCE),
                   'draft':str(self.draft),'spec':str(self.spec),'workflow_report':str(self.log),'session':str(self.runtime),
                   'digest':profile.snapshot_digest(snapshot),'validation_passed':True}
        profile.write_json(self.plan_path,self.plan)
        self.confirmation=self.runtime/'confirmation.txt';self.confirmation.write_text('隔离安装测试批准；不授权正式账号',encoding='utf-8')
        self.args=SimpleNamespace(plan=str(self.plan_path),digest=self.plan['digest'],confirmation_file=str(self.confirmation))

    def tearDown(self):self.temp.cleanup()

    def activate(self):
        with contextlib.redirect_stdout(io.StringIO()) as out:
            deployment.activate(self.args)
        return json.loads(out.getvalue())

    def seed_existing_business_history(self):
        snapshot=self.root/'old-snapshot';shutil.copytree(self.draft/'snapshot',snapshot)
        (snapshot/'personal_prompt.md').write_text('本账号自定义帽檐留空间',encoding='utf-8')
        store=profile.Store(self.profile)
        revision=store.initialize(snapshot,'隔离旧版批准',validate_snapshot(snapshot,self.root/'old-previews'))
        (self.profile/'feedback.jsonl').write_text(json.dumps({'id':'f-existing','batch_id':'b-existing','text':'原反馈请保留'},ensure_ascii=False)+'\n',encoding='utf-8')
        profile.write_json(self.profile/'batches/b-existing.json',{'id':'b-existing','status':'completed','original':'原批次'})
        profile.write_json(self.profile/'reviews/r-existing/review.json',{'id':'r-existing','approved':True,'original':'原审核'})
        Image.new('RGB',(8,8),'red').save(self.profile/'reviews/r-existing/preview.png')
        self.plan.update(kind='upgrade',base_revision=revision);profile.write_json(self.plan_path,self.plan)
        return {path.relative_to(self.profile).as_posix():path.read_bytes() for path in [
            self.profile/'feedback.jsonl',self.profile/'batches/b-existing.json',
            self.profile/'reviews/r-existing/review.json',self.profile/'reviews/r-existing/preview.png']}

    def test_prepared_plan_has_no_formal_profile(self):
        self.assertFalse(self.profile.exists());self.assertEqual(profile.read_json(self.plan_path)['status'],'prepared')

    def test_empty_confirmation_is_rejected(self):
        self.confirmation.write_text(' ')
        with self.assertRaises(ValueError):self.activate()
        self.assertFalse(self.profile.exists())

    def test_wrong_digest_is_rejected(self):
        self.args.digest='wrong'
        with self.assertRaises(ValueError):self.activate()
        self.assertFalse(self.profile.exists())

    def test_changed_preview_is_rejected(self):
        record=profile.read_json(self.draft/'validation.json');Path(record['previews'][0]['path']).write_bytes(b'changed')
        with self.assertRaises(ValueError):self.activate()

    def test_changed_source_is_rejected(self):
        Image.new('RGB',(240,400),'green').save(self.source)
        with self.assertRaises(ValueError):self.activate()

    def test_changed_snapshot_is_rejected(self):
        (self.draft/'snapshot/personal_prompt.md').write_text('changed')
        with self.assertRaises(ValueError):self.activate()

    def test_changed_candidate_is_rejected(self):
        (self.candidate/'SKILL.md').write_text('changed')
        with self.assertRaises(ValueError):self.activate()

    def test_changed_candidate_runtime_is_rejected(self):
        profile.write_json(self.candidate/'runtime.json',{'python':'other'})
        with self.assertRaises(ValueError):self.activate()

    def test_other_account_is_rejected(self):
        with patch.object(deployment,'owner_id',return_value='S-1-5-21-OTHER'):
            with self.assertRaises(ValueError):self.activate()

    def test_test_profile_cannot_escape_runtime(self):
        self.plan['profile']=str(self.root/'outside');profile.write_json(self.plan_path,self.plan)
        with self.assertRaises(ValueError):self.activate()

    def test_refresh_merges_defaults_and_updates_digest(self):
        (self.draft/'snapshot/personal_prompt.md').write_text('新的提示词\n',encoding='utf-8')
        result=deployment.refresh(self.plan_path)
        self.assertTrue(result['validation_passed']);self.assertNotEqual(result['digest'],self.args.digest)

    def test_success_backup_preview_payload_and_no_business_feedback(self):
        result=self.activate();self.assertTrue(result['passed'])
        self.assertTrue((Path(result['backup'])/'old.txt').exists())
        self.assertTrue(Path(result['preview']).exists())
        self.assertFalse((self.target/'old.txt').exists())
        self.assertEqual(deployment.payload(self.target),deployment.payload(deployment.SOURCE))
        store=profile.Store(self.profile);self.assertEqual(store.status()['digest'],self.args.digest)
        self.assertEqual(store.events('feedback.jsonl'),[]);self.assertEqual(list((self.profile/'batches').glob('*.json')),[])
        self.assertEqual(profile.read_json(self.plan_path)['status'],'activated')
        plan=profile.read_json(self.plan_path);baseline=profile.read_json(plan['history_baseline'])
        self.assertEqual(baseline['files'],{});self.assertTrue(result['business_history_unchanged'])
        self.assertTrue(Path(plan['history_baseline']).is_relative_to((self.runtime/'installation-plan-private').resolve()))
        self.assertFalse(Path(plan['history_baseline']).is_relative_to(deployment.BUNDLE))

    def test_upgrade_with_business_history_preserves_all_bytes(self):
        original=self.seed_existing_business_history();result=self.activate()
        self.assertTrue(result['passed']);plan=profile.read_json(self.plan_path)
        baseline=profile.read_json(plan['history_baseline'])
        self.assertEqual(set(baseline['files']),set(original))
        for relative,data in original.items():self.assertEqual((self.profile/relative).read_bytes(),data)
        self.assertEqual(deployment.business_history(self.profile),baseline['files'])

    def test_resume_keeps_original_history_baseline_and_detects_modified_review(self):
        original=self.seed_existing_business_history()
        with patch.object(deployment,'run',side_effect=RuntimeError('隔离预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        plan=profile.read_json(self.plan_path);baseline_path=Path(plan['history_baseline']);baseline_bytes=baseline_path.read_bytes()
        review=self.profile/'reviews/r-existing/review.json';review.write_text('外部改动应保留',encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'业务历史被修改'):self.activate()
        self.assertEqual(baseline_path.read_bytes(),baseline_bytes);self.assertEqual(review.read_text(encoding='utf-8'),'外部改动应保留')
        self.assertEqual((self.profile/'feedback.jsonl').read_bytes(),original['feedback.jsonl'])

    def test_install_preview_cannot_add_business_batch_or_review(self):
        original=self.seed_existing_business_history();run=deployment.run
        def preview_adds_business_history(*args,**kwargs):
            result=run(*args,**kwargs)
            profile.write_json(self.profile/'batches/b-should-not-be-created.json',{'id':'unexpected'})
            profile.write_json(self.profile/'reviews/r-unexpected/review.json',{'id':'unexpected'})
            return result
        with patch.object(deployment,'run',side_effect=preview_adds_business_history):
            with self.assertRaisesRegex(ValueError,'业务历史被修改/删除或新增'):self.activate()
        for relative,data in original.items():self.assertEqual((self.profile/relative).read_bytes(),data)
        self.assertTrue((self.profile/'batches/b-should-not-be-created.json').exists())
        self.assertNotEqual(profile.read_json(self.plan_path)['status'],'activated')

    def test_install_preview_cannot_append_feedback_even_when_preview_fails(self):
        self.seed_existing_business_history()
        def append_then_fail(*args,**kwargs):
            with (self.profile/'feedback.jsonl').open('a',encoding='utf-8') as stream:stream.write('{"id":"unexpected"}\n')
            raise RuntimeError('隔离预览失败')
        with patch.object(deployment,'run',side_effect=append_then_fail):
            with self.assertRaisesRegex(ValueError,'业务历史被修改/删除或新增'):self.activate()
        self.assertIn('unexpected',(self.profile/'feedback.jsonl').read_text(encoding='utf-8'))

    def test_resume_detects_lost_existing_batch_without_clearing_other_history(self):
        original=self.seed_existing_business_history()
        with patch.object(deployment,'run',side_effect=RuntimeError('隔离预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        (self.profile/'batches/b-existing.json').unlink()
        with self.assertRaisesRegex(ValueError,'业务历史被修改/删除或新增'):self.activate()
        self.assertEqual((self.profile/'reviews/r-existing/review.json').read_bytes(),original['reviews/r-existing/review.json'])

    def test_prompt_upgrade_only_replaces_routing_and_is_idempotent(self):
        personal='本账号自定义帽檐留空间\n自定义参数：左边距12像素。\n原始PSD均用Photoshop原生副本，保留原层结构并检查清晰度；Photoshop不可用不降级平面重建。\n原生PSD尚未通过实机验收，因此全部停止\n'
        upgraded=deployment.upgrade_prompt(personal)
        self.assertIn('本账号自定义帽檐留空间\n自定义参数：左边距12像素。',upgraded)
        self.assertNotIn('原始PSD均用Photoshop原生副本',upgraded);self.assertNotIn('因此全部停止',upgraded)
        self.assertIn('PSD默认由Python输出',upgraded);self.assertIn('实际source_viewport',upgraded)
        self.assertIn('人工选Python或Photoshop',upgraded);self.assertIn('不自动flatten',upgraded)
        self.assertIn('不阻断已支持的Python路径',upgraded);self.assertIn('Photoshop也不保证恢复缺失细节',upgraded)
        self.assertEqual(deployment.upgrade_prompt(upgraded),upgraded)
        later=deployment.upgrade_prompt(upgraded+'\n新加个人构图：留出帽檐\n')
        self.assertIn('新加个人构图：留出帽檐',later);self.assertEqual(later.count(deployment.ROUTING_START),1)

    def test_real_v33_prompt_upgrade_replaces_preview_generic_sizes_and_image_naming(self):
        personal='# 尺寸调整个人规则初始模板（3.3，需本账号确认）\n\n'+CUSTOM_PREFERENCES
        personal+='\n'.join([V33_PREVIEW,V33_SIZES,V33_NAMING,V33_SELECTION,FORMAT_RULE])+'\n'
        upgraded=deployment.upgrade_prompt(personal)
        for obsolete in [V33_PREVIEW,V33_SIZES,V33_NAMING,V33_SELECTION]:
            with self.subTest(obsolete=obsolete):self.assertNotIn(obsolete,upgraded)
        self.assertNotIn('当前候选经真实确认后才开始下一项',upgraded)
        self.assertNotIn('透明不加背景，逐张预览',upgraded)
        self.assertIn('主图选800x800、1440x1440、750x1000或自定义',upgraded)
        self.assertIn('场景图选750x1000、800x800、800x1200或自定义',upgraded)
        self.assertIn('同尺寸图片默认按原图顺序命名1—N',upgraded)
        self.assertIn('只生成当前张预览',upgraded)
        self.assertIn('不能把旧任务模板继承当成新的人工覆盖',upgraded)
        self.assertIn(CUSTOM_PREFERENCES,upgraded);self.assertIn(FORMAT_RULE,upgraded)
        self.assertEqual(deployment.upgrade_prompt(upgraded),upgraded)

    def test_real_v33_prompt_with_existing_routing_marker_preserves_custom_rules_and_is_idempotent(self):
        personal=CUSTOM_PREFERENCES+'\n'+V33_PREVIEW+'\n'+V33_SIZES+'\n'+V33_NAMING+'\n'
        personal+='\n'+deployment.ROUTING_START+'\n'+deployment.ROUTING_RULES+deployment.ROUTING_END+'\n'
        upgraded=deployment.upgrade_prompt(personal)
        self.assertEqual(upgraded.count(deployment.ROUTING_START),1)
        self.assertEqual(upgraded.count(deployment.WORKFLOW_START),1)
        self.assertIn(deployment.ROUTING_RULES,upgraded)
        self.assertIn(CUSTOM_PREFERENCES,upgraded)
        self.assertEqual(deployment.upgrade_prompt(upgraded),upgraded)
        appended='\n后续自定义构图：保留绑带；subject_fill=0.78。\n'
        updated=deployment.upgrade_prompt(upgraded+appended)
        self.assertIn(appended.strip(),updated)
        self.assertEqual(deployment.upgrade_prompt(updated),updated)

    def test_review_keeps_backend_v33_and_describes_workflow_v34_without_changing_settings(self):
        settings=(self.draft/'snapshot/settings.json').read_bytes()
        deployment.review(self.plan)
        text=(self.draft/'待确认初始规则.md').read_text(encoding='utf-8')
        self.assertIn('3.3默认用Python输出PSD',text);self.assertIn('这只限制PS路由',text)
        self.assertIn('由3.4规则替代',text);self.assertIn('默认一张一张预览确认',text)
        self.assertIn('主图提供800×800、1440×1440、750×1000或自定义',text)
        self.assertIn('场景图提供750×1000、800×800、800×1200或自定义',text)
        self.assertIn('同尺寸图片默认1—N编号',text)
        self.assertEqual((self.draft/'snapshot/settings.json').read_bytes(),settings)

    def test_activation_retires_old_skill_outside_discovery_root_on_same_volume(self):
        discovery=self.runtime/'skills';discovery.mkdir()
        target=discovery/'chutu-chicun-tiaozheng-single'
        self.target.rename(target);self.target=target
        old_skill=b'---\nname: old-resize-skill\n---\nOld skill must remain recoverable.\n'
        (target/'SKILL.md').write_bytes(old_skill)
        neighbor=discovery/'unrelated-skill';neighbor.mkdir();(neighbor/'SKILL.md').write_bytes(b'unrelated skill')
        self.plan['target']=str(target);profile.write_json(self.plan_path,self.plan)
        result=self.activate();plan=profile.read_json(self.plan_path)
        retired=Path(plan['retired_path']).resolve()
        self.assertTrue(retired.is_relative_to((target.parent.parent/'chutu-resize-retired').resolve()))
        self.assertFalse(retired.is_relative_to(discovery.resolve()))
        self.assertEqual(retired.anchor.casefold(),target.resolve().anchor.casefold())
        self.assertEqual(retired.name,target.name)
        self.assertEqual((retired/'SKILL.md').read_bytes(),old_skill)
        self.assertEqual((retired/'old.txt').read_text(),'preserve original skill')
        self.assertEqual((Path(result['backup'])/'SKILL.md').read_bytes(),old_skill)
        self.assertEqual(Path(result['retired_skill']).resolve(),retired)
        self.assertEqual(deployment.payload(target),deployment.payload(deployment.SOURCE))
        discovered={path.parent.resolve() for path in discovery.rglob('SKILL.md')}
        self.assertEqual(discovered,{target.resolve(),neighbor.resolve()})
        self.assertEqual((neighbor/'SKILL.md').read_bytes(),b'unrelated skill')

    def test_repeated_activation_is_rejected(self):
        self.activate()
        with self.assertRaises(ValueError):self.activate()

    def test_preview_failure_resumes_without_second_initialization(self):
        original=deployment.run
        with patch.object(deployment,'run',side_effect=RuntimeError('模拟安装后预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        revision=profile.Store(self.profile).status()['revision']
        self.assertEqual(profile.read_json(self.plan_path)['status'],'published')
        result=self.activate();self.assertEqual(result['revision'],revision)
        self.assertEqual(len(profile.Store(self.profile).version_list()),1)

    def test_partial_staging_copy_can_resume(self):
        original=shutil.copytree
        def fail_pending(src,dst,*args,**kwargs):
            if '.pending-' in str(dst):
                Path(dst).mkdir(parents=True);shutil.copyfile(Path(src)/'SKILL.md',Path(dst)/'SKILL.md')
                raise OSError('模拟暂存复制中断')
            return original(src,dst,*args,**kwargs)
        with patch.object(deployment.shutil,'copytree',side_effect=fail_pending):
            with self.assertRaises(OSError):self.activate()
        revision=profile.Store(self.profile).status()['revision']
        result=self.activate();self.assertEqual(result['revision'],revision)

    def test_rename_interruption_can_resume_with_old_skill_preserved(self):
        original=Path.rename
        def fail_publish(path,target):
            if '.pending-' in path.name:raise OSError('模拟目录切换中断')
            return original(path,target)
        with patch.object(Path,'rename',fail_publish):
            with self.assertRaises(OSError):self.activate()
        plan=profile.read_json(self.plan_path);retired=Path(plan['retired_path'])
        self.assertTrue((retired/'old.txt').exists())
        self.assertTrue(retired.is_relative_to(self.target.parent.parent/'chutu-resize-retired'))
        self.assertFalse(retired.is_relative_to(self.target.parent))
        result=self.activate();self.assertTrue(result['passed'])

    def test_resume_rejects_changed_confirmation(self):
        with patch.object(deployment,'run',side_effect=RuntimeError('模拟预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        self.confirmation.write_text('另一份确认',encoding='utf-8')
        with self.assertRaises(ValueError):self.activate()

    def test_upgrade_uses_proposal_and_preserves_settings(self):
        snapshot=self.root/'old-snapshot';shutil.copytree(self.draft/'snapshot',snapshot)
        (snapshot/'personal_prompt.md').write_text('本账号自定义偏好',encoding='utf-8')
        report=validate_snapshot(snapshot,self.root/'old-previews')
        store=profile.Store(self.profile);before=store.initialize(snapshot,'旧版模拟批准',report)
        self.plan.update(kind='upgrade',base_revision=before);profile.write_json(self.plan_path,self.plan)
        result=self.activate();self.assertNotEqual(result['revision'],before)
        self.assertEqual(len(store.version_list()),2)
        self.assertTrue(profile.read_json(self.plan_path).get('upgrade_proposal'))
        self.assertEqual(store.active()[2],profile.read_json(snapshot/'settings.json'))

    def test_prepare_with_real_regressions_and_refresh(self):
        runtime=self.root/'real-prepare'
        args=SimpleNamespace(runtime=str(runtime),target=str(runtime/'skill'),test_profile=str(runtime/'profile'))
        with contextlib.redirect_stdout(io.StringIO()):deployment.prepare(args)
        plan=profile.read_json(runtime/'installation-plan.json')
        self.assertEqual(plan['status'],'prepared');self.assertFalse((runtime/'profile').exists())
        self.assertTrue(deployment.refresh(runtime/'installation-plan.json')['validation_passed'])

    def test_upgrade_resumes_after_preview_failure(self):
        snapshot=self.root/'old-snapshot';shutil.copytree(self.draft/'snapshot',snapshot)
        (snapshot/'personal_prompt.md').write_text('旧个人偏好',encoding='utf-8')
        store=profile.Store(self.profile)
        before=store.initialize(snapshot,'模拟旧批准',validate_snapshot(snapshot,self.root/'old-previews'))
        self.plan.update(kind='upgrade',base_revision=before);profile.write_json(self.plan_path,self.plan)
        with patch.object(deployment,'run',side_effect=RuntimeError('模拟升级发布后预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        revision=store.status()['revision'];self.assertNotEqual(revision,before)
        self.assertEqual(self.activate()['revision'],revision);self.assertEqual(len(store.version_list()),2)

    def test_prepare_existing_account_preserves_custom_settings_and_prompt(self):
        settings=profile.read_json(self.draft/'snapshot/settings.json');settings['defaults']['format']='jpg'
        profile.write_json(self.draft/'snapshot/settings.json',settings)
        addition='本账号在交付节追加：帽檐左边保留12像素，subject_fill=0.78；不继承上一批款号。'
        old_delivery='逐张预览确认；明确本批沿用风格授权可按范围直接完成。尺寸人工多选800x800、1440x1440、750x1000或自定义；图片和PSD命名每批人工输入。JPG/PNG不超过500000字节，每款每尺寸1个PSD。'
        personal='本账号自定义帽檐留空间\n原始PSD均用Photoshop原生副本，保留原层结构并检查清晰度；Photoshop不可用不降级平面重建。'
        personal+='\n\n## 本版数据包交付\n'+old_delivery+'\n'+addition+'\n'
        (self.draft/'snapshot/personal_prompt.md').write_text(personal,encoding='utf-8')
        report=validate_snapshot(self.draft/'snapshot',self.root/'old-previews')
        before=profile.Store(self.profile).initialize(self.draft/'snapshot','模拟旧账号确认',report)
        args=SimpleNamespace(runtime=str(self.runtime),target=str(self.target),test_profile=str(self.profile))
        with contextlib.redirect_stdout(io.StringIO()):deployment.prepare(args)
        plan=profile.read_json(self.runtime/'installation-plan.json');self.assertEqual(plan['kind'],'upgrade')
        snapshot=Path(plan['draft'])/'snapshot'
        self.assertEqual(profile.read_json(snapshot/'settings.json')['defaults']['format'],'jpg')
        self.assertIn('本账号自定义帽檐留空间',(snapshot/'personal_prompt.md').read_text(encoding='utf-8'))
        prompt=(snapshot/'personal_prompt.md').read_text(encoding='utf-8')
        self.assertIn('PSD默认由Python输出',prompt);self.assertNotIn('原始PSD均用Photoshop原生副本',prompt)
        self.assertEqual(prompt.count('## 本版数据包交付'),1)
        self.assertIn(addition,prompt);self.assertNotIn(old_delivery,prompt)
        self.assertEqual(prompt.count(deployment.WORKFLOW_START),1)
        self.assertIn('一张一张预览，逐张确认后再进入下一张',prompt)
        self.assertIn('同尺寸图片默认按原图顺序命名1—N',prompt)
        self.assertIn('场景图选750x1000、800x800、800x1200或自定义',prompt)
        self.assertEqual(deployment.upgrade_prompt(prompt),prompt)
        review=(Path(plan['draft'])/'待确认初始规则.md').read_text(encoding='utf-8')
        self.assertIn('3.3默认用Python输出PSD',review);self.assertIn('这只限制PS路由',review)
        self.assertEqual(profile.Store(self.profile).status()['revision'],before)
        self.assertTrue((Path(plan['draft'])/'changes.diff').exists())

    def test_unknown_staging_file_is_not_deleted(self):
        with patch.object(deployment,'run',side_effect=RuntimeError('模拟预览失败')):
            with self.assertRaises(RuntimeError):self.activate()
        plan=profile.read_json(self.plan_path);pending=Path(plan['publish_path']);pending.mkdir()
        (pending/'unknown.txt').write_text('preserve')
        (self.target/'SKILL.md').write_text('changed')
        with self.assertRaises(ValueError):self.activate()
        self.assertTrue((pending/'unknown.txt').exists())
