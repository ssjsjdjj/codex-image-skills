"""Public CLI contract for purpose menus, numbered previews and one batch approval."""
from pathlib import Path
import contextlib
import io
import sys
import unittest
from unittest.mock import patch

from PIL import Image
import test_delivery_flow as delivery_flow_fixture
import user_profile as profile


class BatchPreviewCLITests(unittest.TestCase):
    def setUp(self):
        self.case=delivery_flow_fixture.DeliveryFlowTests('test_real_800_1440_and_750x1000_output_sizes')
        self.case.setUp()
    def tearDown(self):self.case.tearDown()

    def start(self,count=5,sizes=('64x64','80x80','60x80'),source_size=(1000,1400)):
        c=self.case
        spec=c.task(c.pictures(count,size=source_size),sizes=sizes)
        spec['delivery'].pop('naming')
        profile.write_json(c.spec_path,spec)
        return c.run_entry(['review-start','--spec',str(c.spec_path)])['review_id']

    def test_type_menus_are_separate_and_custom_remains_available(self):
        main=self.case.run_entry(['delivery-options','--kind','main'])
        scene=self.case.run_entry(['delivery-options','--kind','scene'])
        self.assertEqual(main['presets'],['800x800','1440x1440','750x1000'])
        self.assertEqual(scene['presets'],['750x1000','800x800','800x1200'])
        self.assertTrue(main['custom']['enabled']);self.assertTrue(scene['custom']['enabled'])

    def test_cli_help_never_opens_default_or_isolated_store(self):
        entry=delivery_flow_fixture.entry
        with patch.object(entry,'Store',side_effect=AssertionError('help must not open a Store')):
            with patch.object(sys,'argv',['resize_assets.py','--help']),contextlib.redirect_stdout(io.StringIO()) as output:
                entry.main()
            self.assertTrue(output.getvalue())
            with patch.object(sys,'argv',['resize_assets.py','review-preview-all','--help']),contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(SystemExit) as stopped:entry.main()
            self.assertEqual(stopped.exception.code,0)

    def test_five_by_three_grouped_numbered_preview_approval_and_real_delivery(self):
        c=self.case;rid=self.start()
        previews=c.run_entry(['review-preview-all','--review',rid])
        self.assertEqual(len(previews['groups']),3)
        for group in previews['groups']:
            self.assertEqual([item['number'] for item in group['items']],list(range(1,6)))
            paths=[Path(item['preview']) for item in group['items']]
            self.assertEqual([p.name for p in paths],['1.jpg','2.jpg','3.jpg','4.jpg','5.jpg'])
            self.assertEqual(len({p.parent for p in paths}),1)
            self.assertEqual(paths[0].parent.name,group['size'])
            self.assertTrue(all(Path(p).is_file() for p in group['contact_sheets']))
        self.assertFalse((c.output/'图片').exists())
        self.assertFalse((c.output/'源文件').exists())
        approved=c.run_entry(['review-confirm-all','--review',rid,'--digest',previews['batch_digest'],
                              '--confirmation','隔离CLI验收：模拟确认当前全部合成预览，非实际业务批准'])
        self.assertTrue(approved['ready'])
        self.assertTrue(c.queue.ready(rid))
        result=c.batch(rid)
        self.assertEqual(len(result),15)
        for size in ('64x64','80x80','60x80'):
            for index in range(1,6):
                path=c.output/'图片'/size/f'{index}.jpg'
                with Image.open(path) as image:self.assertEqual(image.size,tuple(map(int,size.split('x'))))
                self.assertLessEqual(path.stat().st_size,500000)
            c.assert_psd(c.output/'源文件'/f'KCT-FLOW_{size}.psd',tuple(map(int,size.split('x'))),5)
        record=c.record(rid)
        self.assertEqual(record['review_mode'],'batch')
        self.assertEqual(record['preview_confirmation']['kind'],'human_batch_preview_confirmation')

    def test_size_backend_selection_then_point_adjustment_requires_new_batch_digest(self):
        c=self.case;rid=self.start(count=2,sizes=('64x64','80x80'),source_size=(20,20))
        blocked=c.run_entry(['review-preview-all','--review',rid])
        self.assertTrue(blocked['requires_backend_choice'])
        self.assertEqual(len(blocked['risks']),4)
        c.run_entry(['review-select-backend','--review',rid,'--backend','python','--size','64x64',
                     '--confirmation','隔离测试模拟本批64尺寸选择Python，非实际业务批准'])
        still=c.run_entry(['review-preview-all','--review',rid])
        self.assertTrue(still['requires_backend_choice'])
        self.assertEqual({item['size'] for item in still['risks']},{'80x80'})
        c.run_entry(['review-select-backend','--review',rid,'--backend','python','--indices','3,4',
                     '--confirmation','隔离测试模拟候选3和4选择Python，非实际业务批准'])
        first=c.run_entry(['review-preview-all','--review',rid])
        patch=c.root/'adjust.json';profile.write_json(patch,{'zoom':1.1})
        c.run_entry(['review-adjust-item','--review',rid,'--index','3','--patch',str(patch)])
        with self.assertRaises(ValueError):
            c.run_entry(['review-confirm-all','--review',rid,'--digest',first['batch_digest'],'--confirmation','隔离旧摘要模拟确认'])
        changed=c.run_entry(['review-preview-all','--review',rid])
        self.assertTrue(changed['requires_backend_choice'])
        self.assertEqual([row['index'] for row in changed['risks']],[3])
        c.run_entry(['review-select-backend','--review',rid,'--backend','python','--indices','3',
                     '--confirmation','隔离测试模拟确认新倍率后选择Python，非实际业务批准'])
        updated=c.run_entry(['review-preview-all','--review',rid])
        self.assertNotEqual(updated['batch_digest'],first['batch_digest'])


if __name__=='__main__':unittest.main(verbosity=2)
