"""Prepare a tested initial draft; activate only the exact draft approved by this user."""
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

BUNDLE = Path(__file__).resolve().parent
SOURCE = BUNDLE / "skills/chutu-chicun-tiaozheng-single"
sys.dont_write_bytecode = True
sys.path.insert(0,str(SOURCE / "scripts"))
from user_profile import Store, file_hash, owner_id, read_json, snapshot_digest, write_json
from validate_candidate import validate_snapshot
from task_spec import load_jobs


def payload(folder):
    return {p.relative_to(folder).as_posix():file_hash(p) for p in sorted(Path(folder).rglob('*'))
            if p.is_file() and p.name != 'runtime.json' and '__pycache__' not in p.parts}


def identifier():
    return datetime.now().strftime('%Y%m%d-%H%M%S-%f')


ROUTING_START='<!-- chutu-routing-3.3:start -->'
ROUTING_END='<!-- chutu-routing-3.3:end -->'
ROUTING_RULES='''## 3.3 PSD后端与放大选择
以下只替代旧版关于PSD后端、放大选择与Photoshop验收范围的路由规则；其他个人settings、构图与反馈规则继续保留。
- PSD默认由Python输出；已支持的平坦RGB8纯像素图层、intrinsic alpha及独立位图蒙版须保留并重开验收。已有group、文字、智能对象、矢量、效果或未支持资源等无法安全保留时先说明，让用户选择后续；不自动flatten，不自动切换Photoshop，也不能把从JPG重建的PSD说成恢复原编辑结构。
- 对PSD输入或含PSD交付的业务任务，按实际source_viewport计算scale=max(目标宽/取景宽,目标高/取景高)。scale>1先展示倍率并提示可能模糊或细节变软，建议使用Photoshop（PS）放大，由人工选Python或Photoshop；未选前停止目标尺寸预览和正式生成。裁切到800也可能放大，大源到1440也可能缩小；Photoshop也不保证恢复缺失细节。
- 人工选择只适用于已确认的当前输入及内容、裁切和目标尺寸；记录真实原文、basis和范围。任一条件变化后重新选择，不能学成长期自动放大。Python默认和沿用风格授权都不替代未作出的放大选择。
- 本机Photoshop COM实机验收未通过只限制Photoshop路由，不阻断已支持的Python路径。用户明确选PS后，环境不可用则如实失败，不自动退回Python。
'''

WORKFLOW_START='<!-- chutu-workflow-3.4:start -->'
WORKFLOW_END='<!-- chutu-workflow-3.4:end -->'
WORKFLOW_RULES='''## 3.4 用途、编号和整批预览
本节替代旧的通用尺寸菜单、旧预览流程和图片命名要求；其余个人构图参数、反馈和后端规则保留。
- 主图和场景图均可直接使用JPG、PNG或已有PSD；默认Python调整尺寸并额外交付每款每尺寸汇总PSD，无需先将照片转PSD。
- 先选主图或场景图，分别建单和数据包。主图选800x800、1440x1440、750x1000或自定义；场景图选750x1000、800x800、800x1200或自定义。尺寸可多选，仅输出明确所选尺寸，数量按实际输入，不固定每组5张。
- 同尺寸图片默认按原图顺序命名1—N，放到对应尺寸目录，无需再询问图片命名；PSD仍每款每尺寸1份，默认款号_尺寸或本批明确命名，内部层/组1—N。不能把旧任务模板继承当成新的人工覆盖。
- 逐图独立规划后，只生成当前张预览，当前张经真实确认后才生成下一张；全部候选逐张确认后正式导出。当前张修改后刷新预览与摘要；不把生成预览或规则修改当成图像批准。未回复不算确认。
- 先统一评估全批实际放大与结构风险，汇总需人工选择Python或PS的项目；未完成该轮必要选择前不生成目标预览。批量看图不取消后端选择，也不声称人类逐张看过。
'''


def upgrade_prompt(prompt):
    """Change only known obsolete routing text and our own marked rule block."""
    import re
    prompt=re.sub(re.escape(ROUTING_START)+r'.*?'+re.escape(ROUTING_END),'',prompt,flags=re.S)
    prompt=re.sub(re.escape(WORKFLOW_START)+r'.*?'+re.escape(WORKFLOW_END),'',prompt,flags=re.S)
    replacements={
        '尺寸调整个人规则初始模板（逐张确认版，需本账号确认）':'尺寸调整个人规则（整批预览确认版）',
        '先生成代表性预览供用户确认':'一次生成全部预览，按尺寸集中供用户确认',
        '- 默认按源图及所选尺寸逐候选预览和调整，当前候选经真实确认后才开始下一项；未回复不算确认。用户明确授权本批按已确认风格生成后续时，记录真实原文、参考和适用范围，逐图复核后执行，不声称人类逐张看过；该授权不跨批、不改变长期规则。单次构图确认不自动形成长期偏好。':'- 逐图独立规划后一次生成全部预览，按尺寸集中展示编号总览；本批完整预览经真实集中确认后正式导出，未回复不算确认，不声称逐张人看，也不把本批确认学成长期构图偏好。',
        '- 每批人工选择800×800、1440×1440、750×1000或人工输入尺寸，可多选，只出所选项。':'- 先选主图或场景，按本版3.4各自尺寸菜单多选或自定义，只输出明确所选项。',
        '- 每批收集图片与PSD命名，不自行猜款号或套默认；用户明确授权本批自动命名时可采用生成方案并告知，不编造人工输入。':'- 图片默认每尺寸1—N编号，无需再收集固定图片命名；款号不猜测，PSD采用本批明确命名或款号_尺寸。',
        '透明不加背景，逐张预览。':'透明不加背景，预览按尺寸集中生成和确认。',
        '一张张预览和调整：当前张经真实确认后才开始下一张；全批确认后生成正式成品，未回复不算确认。单张构图确认不自动形成长期偏好。':'逐图独立规划后一次生成全部预览，同尺寸集中展示；整批真实确认后生成正式成品，未回复不算确认。本批确认不自动形成长期偏好。',
        '一张张预览、调整并确认，确认当前张后才开始下一张':'逐图规划，一次生成全部预览并按尺寸集中确认',
        '逐张预览确认；明确本批沿用风格授权可按范围直接完成。尺寸人工多选800x800、1440x1440、750x1000或自定义；图片和PSD命名每批人工输入。':'一次生成全部预览，按尺寸集中确认；尺寸按本版主图/场景分支明确多选；图片每尺寸默认1—N，PSD采用本批明确命名或款号_尺寸。',
        '原始PSD均用Photoshop原生副本，保留原层结构并检查清晰度；Photoshop不可用不降级平面重建。':'PSD按本版3.3路由规则处理，保留可安全支持的原图层和独立蒙版并检查清晰度。',
        '主图必须从已有PSD经Photoshop原生处理并检查编辑结构':'主图从已有PSD按本版3.3路由处理并检查编辑结构',
        '原生PSD尚未通过实机验收，因此全部停止':'Photoshop路由尚未通过实机验收时停止该路由；已支持的Python路径可用',
    }
    replacements.update({'main使用已有PSD；scene可同单照片或PSD，不混合。': 'main和scene均可直接使用JPG、PNG或已有PSD，同单照片与PSD不混合；PSD是额外交付。', '主图只使用PSD，场景可照片或PSD且同单不混合。': '主图和场景均可直接用JPG、PNG或已有PSD，同单照片与PSD不混合，额外交付对应尺寸PSD。', 'main使用已有PSD；scene可同单纯照片或纯PSD，不混合。': 'main和scene均可直接使用照片或已有PSD，额外交付对应尺寸PSD。', '主图使用已有PSD，默认Python处理并检查编辑结构': '主图可直接用JPG、PNG或已有PSD，默认Python调整尺寸并额外交付PSD', '主图从已有PSD按本版3.3路由处理并检查编辑结构': '主图可直接用JPG、PNG或已有PSD，按本版路由调整尺寸并额外交付PSD'})
    for old,new in replacements.items():prompt=prompt.replace(old,new)
    for old,new in {'- 默认review_mode=batch，取得所需后端选择后一次生成整批全部预览，同尺寸放一起，每size给1—N编号总览。用户可集中确认或点名某尺寸第N张调整，按groups映射全局index后修改并刷新预览/digest；最新整批真实确认后才正式生成，不伪称逐张人看。旧单张流程仅用户明确要求时用。单次确认不自动形成长期偏好。': '- 默认review_mode=individual；只预览当前张，真实确认后才预览下一张，全部候选逐张确认后正式导出；禁止整批确认或风格授权代替逐张确认。单次确认不成为长期偏好。', '逐图独立规划后一次生成全部预览，同尺寸集中展示；整批真实确认后生成正式成品，未回复不算确认。': '逐图独立规划后，一张一张预览确认；当前张确认后再生成下一张预览，全部候选确认后正式交付。', '一次生成全部预览，按尺寸集中确认': '一张一张预览，逐张确认后再进入下一张', '逐图独立规划后一次生成全部预览，按尺寸集中展示编号总览；本批完整预览经真实集中确认后正式导出，未回复不算确认，不声称逐张人看，也不把本批确认学成长期构图偏好。': '逐图规划后一张一张预览确认；当前张确认后再进入下一张，全部候选确认后正式交付，不自动形成长期偏好。'}.items():prompt=prompt.replace(old,new)
    return prompt.rstrip()+'\n\n'+ROUTING_START+'\n'+ROUTING_RULES+ROUTING_END+'\n\n'+WORKFLOW_START+'\n'+WORKFLOW_RULES+WORKFLOW_END+'\n'


def business_history(profile):
    """Hash business evidence only; installation audit/version files may change."""
    root=Path(profile).resolve();paths=[]
    if (root/'feedback.jsonl').is_file():paths.append(root/'feedback.jsonl')
    paths.extend(path for path in (root/'batches').glob('*.json') if path.is_file())
    paths.extend(path for path in (root/'reviews').rglob('*') if path.is_file())
    return {path.relative_to(root).as_posix():file_hash(path) for path in sorted(paths)}


def assert_history_unchanged(plan):
    baseline_path=Path(plan['history_baseline']).resolve()
    private=(Path(plan['runtime']).resolve()/'installation-plan-private').resolve()
    if not baseline_path.is_relative_to(private) or baseline_path.is_symlink() or not baseline_path.is_file():
        raise ValueError('安装业务历史基线缺失或位置异常；保留个人数据并停止')
    if file_hash(baseline_path)!=plan['history_baseline_sha256']:
        raise ValueError('安装业务历史基线被修改；保留个人数据并停止')
    baseline=read_json(baseline_path)
    if baseline.get('owner_id')!=plan['owner_id'] or baseline.get('profile')!=str(Path(plan['profile']).resolve()):
        raise ValueError('安装业务历史基线不属于本账号配置')
    current=business_history(plan['profile']);expected=baseline['files']
    if current!=expected:
        changed=sorted(key for key in set(current)|set(expected) if current.get(key)!=expected.get(key))
        raise ValueError('安装期间业务历史被修改/删除或新增；不清空、不覆盖，停止：'+', '.join(changed[:10]))
    return baseline


def ensure_history_baseline(plan,path):
    if plan.get('history_baseline'):
        return assert_history_unchanged(plan)
    private=Path(plan['runtime']).resolve()/'installation-plan-private'
    if private.is_relative_to(BUNDLE):
        raise ValueError('私有安装runtime须位于迁移包目录之外，避免业务历史摘要进入迁移包')
    private.mkdir(parents=True,exist_ok=True)
    baseline_path=private/('history-'+identifier()+'.json')
    baseline={'schema':1,'owner_id':plan['owner_id'],'profile':str(Path(plan['profile']).resolve()),
              'files':business_history(plan['profile'])}
    write_json(baseline_path,baseline)
    plan['history_baseline']=str(baseline_path);plan['history_baseline_sha256']=file_hash(baseline_path)
    write_json(path,plan)
    return assert_history_unchanged(plan)


def run(arguments, log, environment=None):
    result = subprocess.run([str(a) for a in arguments],capture_output=True,encoding='utf-8',errors='replace',
        env=environment or dict(os.environ,PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1'))
    with Path(log).open('a',encoding='utf-8') as stream:
        stream.write(json.dumps([str(a) for a in arguments],ensure_ascii=False)+'\n'+result.stdout+result.stderr+'\n')
    if result.returncode:
        raise RuntimeError(result.stderr[-6000:] or result.stdout[-6000:])
    return result.stdout


def load_plan(path):
    plan=read_json(path)
    if plan['owner_id'] != owner_id():
        raise ValueError('该安装计划属于另一Windows账号，请在本账号重新准备')
    runtime=Path(plan['runtime']).resolve()
    profile=Path(plan['profile']).resolve()
    skill=Path(plan['target']).resolve()
    if plan['isolated_test']:
        if not profile.is_relative_to(runtime) or not skill.is_relative_to(runtime):
            raise ValueError('隔离测试的配置和技能目录必须位于指定测试runtime内')
    elif profile != Store().root:
        raise ValueError('正式安装必须使用当前账号默认个人配置目录')
    if payload(SOURCE) != plan['payload'] or payload(Path(plan['candidate'])) != plan['payload']:
        raise ValueError('技能代码或候选副本已变化，请重新准备和审阅')
    if Path(sys.executable).resolve() != Path(plan['python']).resolve():
        raise ValueError('请用安装计划记录的专用Python执行')
    return plan


def review(plan):
    draft=Path(plan['draft'])
    mode='现有账号升级' if plan.get('kind')=='upgrade' else '新账号初始化'
    text=f"""# 当前Windows账号：{mode}待确认

这是{mode}候选草案，尚未发布。本次固定入口和验证器改动见本版变更.diff。
升级账号保留现有settings及其余个人偏好，尺寸/图片命名/预览流程由3.4规则替代；renderer替换差异见draft/changes.diff，需核对已有自定义裁切逻辑。
3.3默认用Python输出PSD，在安全支持的RGB8纯像素与独立位图蒙版范围内保留并验收。复杂结构不支持时说明原因，让用户决定后续；不能自动flatten或切换PS。Photoshop路由的专项实机验收仍受本机COM启动失败阻断，默认回归跳过该2项测试；这只限制PS路由，不阻断已支持的Python路径。用户选PS后须补跑专项并核对实际商品PSD，环境不可用如实失败，不自动退回Python。详见迁移包“重要-原生PSD验收状态.txt”。

- 技能目录：`{plan['target']}`
- 个人配置目录：`{plan['profile']}`
- 专用Python：`{plan['python']}`
- 核心功能测试：[查看结果](<{Path(plan['workflow_report']).as_posix()}>)
- 初始验证报告：[查看报告](<{(draft/'validation.json').as_posix()}>)
- 本版完整变更：[代码差异](<{(BUNDLE/'本版变更.diff').as_posix()}>)。包含用途菜单、编号、整批预览确认与安装恢复改动，应与初始规则一并审阅。
- 账号兼容修正：[具体代码差异](<{(BUNDLE/'账号兼容修正.diff').as_posix()}>)。使用USERPROFILE与Windows ProfileList匹配账号SID，避免沙箱进程SID误判；审批逻辑不变，不自动接管已有不同SID配置。本次确认包含此项固定控制文件的兼容修改及以下初始规则。
- 几何预览位于draft/previews；图像是安装测试示意图，不代表真实商品审美效果。

本版本默认一张一张预览确认，真实确认当前张后才生成下一张；全部候选逐张确认后正式交付。每张确认原文与digest分别记录，禁止整批确认或风格授权代替。安装几何示意图不是业务批次确认。

主图提供800×800、1440×1440、750×1000或自定义；场景图提供750×1000、800×800、800×1200或自定义。用途分开建单、单独数据包；允许多选且只输出明确所选尺寸。同尺寸图片默认1—N编号，PSD默认款号_尺寸或按本批明确方案。JPG/PNG实际文件不超过500000字节，PNG默认保留格式和透明通道，无法达标时报告，不缩尺寸或擅改格式。数据包分图片和源文件，每款每尺寸一个含1—N可切换层/组的PSD，默认仅1可见，另附使用提示词和本批说明。主图和场景均可直接使用JPG、PNG或已有PSD，默认Python调整尺寸并额外交付对应尺寸PSD；不将放大JPG包装成恢复编辑结构的源PSD。本次不新增白底图生成操作。

涉及PSD输入或PSD交付的业务任务，按实际source_viewport计算放大比例；scale>1先展示倍率并提示可能模糊或细节变软，建议使用PS，由用户选择PS或Python，未选前不生成目标尺寸预览或正式输出。该选择只覆盖本次明确的源内容、实际裁切与尺寸，任一变化须重选；不学成永久自动放大，风格沿用也不替代放大选择。Photoshop不保证恢复已经缺失的像素细节。安装几何诊断样图不作为业务放大选择。

本版本包含每批商品主体选择与各品类取景规则：上衣／外套、裤子、眼镜／雪镜、帽子、鞋／靴、全身及自定义。已明确品类时直接采用；单批选择不自动成为长期默认。由Codex逐图观察并规划，不是脚本新增品类检测或固定坐标。

以下3份新文件将构成同一个版本：settings.json、personal_prompt.md、renderer.py。

```json
{(draft/'snapshot/settings.json').read_text(encoding='utf-8').strip()}
```

{(draft/'snapshot/personal_prompt.md').read_text(encoding='utf-8')}

每批成功完成询问一次；文字、参数、用途/品类和图片路径存入本账号。明确长期偏好立即提议，其余同用途同品类的同类意见来自3个不同批次再提议。同一批重复不累加。

长期修改先展示具体差异和测试预览，由本账号用户批准后生效；测试失败不生效，运行异常由用户选择是否回退。保留总共3个已生效版本，含当前版。

初始摘要：`{plan['digest']}`

请用户查看本草案和预览后明确批准，再调用Activate。测试程序里的确认文字不能用作正式账号批准。
"""
    (draft/'待确认初始规则.md').write_text(text,encoding='utf-8')


def refresh(path):
    plan=load_plan(path)
    if plan['status'] != 'prepared':
        raise ValueError('只能验证尚未激活的草案')
    if plan.get('activation_confirmation'):
        raise ValueError('本计划已开始激活，不能复用批准修改草案；请重新Prepare并审阅')
    if plan.get('kind')=='upgrade':
        status=Store(plan['profile']).status()
        if status['revision'] != plan['base_revision']:
            raise ValueError('个人版本已变化，请重新准备升级')
    report=validate_snapshot(Path(plan['draft'])/'snapshot',Path(plan['draft'])/'previews',load_jobs(plan['spec']))
    write_json(Path(plan['draft'])/'validation.json',report)
    plan['digest']=snapshot_digest(Path(plan['draft'])/'snapshot')
    plan['validation_passed']=report['passed']
    write_json(path,plan)
    if plan.get('kind')=='upgrade':
        import difflib
        active=Path(status['renderer']).parent
        diff=[]
        for name in ('settings.json','personal_prompt.md','renderer.py'):
            diff.extend(difflib.unified_diff((active/name).read_text(encoding='utf-8').splitlines(True),
                        (Path(plan['draft'])/'snapshot'/name).read_text(encoding='utf-8').splitlines(True),
                        fromfile='before/'+name,tofile='after/'+name))
        (Path(plan['draft'])/'changes.diff').write_text(''.join(diff),encoding='utf-8')
    review(plan)
    if not report['passed']:
        raise ValueError('初始规则验证失败：'+report.get('error','未知错误'))
    return plan


def prepare(args):
    from PIL import Image,ImageDraw
    runtime=Path(args.runtime).resolve()
    target=Path(args.target).resolve()
    runtime.mkdir(parents=True,exist_ok=True)
    session=runtime/'logs'/('prepare-'+identifier())
    session.mkdir(parents=True)
    profile=Path(args.test_profile).resolve() if args.test_profile else Store().root
    test_mode=bool(args.test_profile)
    if test_mode and (not profile.is_relative_to(runtime) or not target.is_relative_to(runtime)):
        raise ValueError('测试配置和技能必须位于同一隔离runtime内')
    previous_status=Store(profile).status()
    candidate=runtime/'staging'/identifier()/'chutu-chicun-tiaozheng-single'
    shutil.copytree(SOURCE,candidate)
    import yaml
    metadata=yaml.safe_load((candidate/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1])
    if metadata.get('name') != 'chutu-chicun-tiaozheng-single' or not metadata.get('description'):
        raise ValueError('技能frontmatter缺少正确name或description')
    write_json(candidate/'runtime.json',{'schema':1,'python':str(Path(sys.executable).resolve()),'runtime':str(runtime)})
    environment=dict(os.environ,RESIZE_TEST_SKILL=str(candidate),PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    result_file=session/'workflow-tests.txt'
    print('Running resize, feedback, approval and rollback regression tests...',flush=True)
    run([sys.executable,BUNDLE/'tests/run_tests.py','--group','workflow'],result_file,environment)
    src=session/'sources';src.mkdir()
    portrait=Image.new('RGB',(600,900),'#94bed7')
    draw=ImageDraw.Draw(portrait)
    draw.ellipse((240,140,360,260),fill='#edbc98')
    draw.rounded_rectangle((175,265,425,750),35,fill='#dc7984')
    draw.rectangle((0,780,600,900),fill='#547b93')
    portrait.save(src/'竖版示意.jpg',quality=95)
    wide=Image.new('RGB',(1000,500),'#a0c1bd')
    draw=ImageDraw.Draw(wide);draw.rounded_rectangle((330,85,690,430),45,fill='#4f8bb0')
    wide.save(src/'横版示意.png')
    jobs=[{'input':str(src/'竖版示意.jpg'),'name':'portrait-square','size':'800x800','focus':[.5,.39],'protect_box':[.30,.15,.70,.65]},
          {'input':str(src/'竖版示意.jpg'),'name':'portrait-vertical','size':'750x1000','focus':[.5,.5]},
          {'input':str(src/'横版示意.png'),'name':'landscape-square','size':'1440x1440','focus':[.51,.5]}]
    spec=session/'preview-jobs.json';write_json(spec,{'jobs':jobs})
    draft=runtime/'drafts'/identifier()
    print('Creating a separate initial draft and previews; not activating the account.',flush=True)
    run([sys.executable,candidate/'scripts/prepare_initial.py','--out',draft,'--spec',spec],session/'prepare-draft.log')
    if previous_status['initialized']:
        # Preserve account-specific settings and prompt; review renderer changes explicitly.
        current_folder=Path(previous_status['renderer']).parent
        shutil.copyfile(current_folder/'settings.json',draft/'snapshot/settings.json')
        prompt=(current_folder/'personal_prompt.md').read_text(encoding='utf-8')
        if not any(line.strip()=='## 本版数据包交付' for line in prompt.splitlines()):
            prompt+='\n\n## 本版数据包交付\n逐张预览确认；明确本批沿用风格授权可按范围直接完成。尺寸人工多选800x800、1440x1440、750x1000或自定义；图片和PSD命名每批人工输入。JPG/PNG不超过500000字节，每款每尺寸1个PSD，内含1—N图层/组；保留原PSD编辑结构，图片与源文件分目录，附使用提示词和本批处理说明。本轮不操作白底图。长期构图仍按经验提取、验证与批准流程。\n'
        prompt=upgrade_prompt(prompt)
        (draft/'snapshot/personal_prompt.md').write_text(prompt,encoding='utf-8')
        write_json(draft/'validation.json',validate_snapshot(draft/'snapshot',draft/'previews',load_jobs(spec)))
    plan={'schema':1,'status':'prepared','owner_id':owner_id(),'python':str(Path(sys.executable).resolve()),
          'runtime':str(runtime),'target':str(target),'profile':str(profile),'isolated_test':test_mode,
          'candidate':str(candidate),'payload':payload(SOURCE),'draft':str(draft),'spec':str(spec),
          'workflow_report':str(result_file),'session':str(session),'digest':snapshot_digest(draft/'snapshot'),
          'validation_passed':read_json(draft/'validation.json')['passed']}
    plan['kind']='upgrade' if previous_status['initialized'] else 'initial'
    plan['base_revision']=previous_status.get('revision')
    if previous_status['initialized']:
        import difflib
        diff=[]
        for name in ('settings.json','personal_prompt.md','renderer.py'):
            diff.extend(difflib.unified_diff((current_folder/name).read_text(encoding='utf-8').splitlines(True),
                        (draft/'snapshot'/name).read_text(encoding='utf-8').splitlines(True),fromfile='before/'+name,tofile='after/'+name))
        (draft/'changes.diff').write_text(''.join(diff),encoding='utf-8')
    if not plan['validation_passed']:
        raise ValueError('保留个人规则后的候选验证失败；保留草案，请诊断后再准备，不发布')
    plan_path=runtime/'installation-plan.json';write_json(plan_path,plan);review(plan)
    print(json.dumps({'prepared':True,'activated':False,'plan':str(plan_path),'digest':plan['digest'],
        'review':str(draft/'待确认初始规则.md'),'previews':str(draft/'previews'),
        'next':'向该账号用户展示规则和预览，得到真实批准后Activate'},ensure_ascii=False,indent=2))


def activate(args):
    plan=load_plan(args.plan)
    if plan['status'] not in ('prepared','profile-initialized','publishing','published'):
        raise ValueError('安装计划已完成或状态不支持续跑，不重复初始化')
    confirmation=Path(args.confirmation_file).read_text(encoding='utf-8-sig').strip()
    if not confirmation:
        raise ValueError('缺少用户本次查看草案后的真实确认原文')
    if plan.get('activation_confirmation') and plan['activation_confirmation'] != confirmation:
        raise ValueError('恢复必须使用原批准原文；新草案需重新审阅')
    draft=Path(plan['draft'])
    if args.digest != plan['digest'] or args.digest != snapshot_digest(draft/'snapshot'):
        raise ValueError('确认摘要与初始草案不同，重新验证和审阅')
    from user_profile import require_validation
    require_validation(draft/'snapshot',read_json(draft/'validation.json'))
    session=Path(plan['session']);target=Path(plan['target']);candidate=Path(plan['candidate'])
    expected_runtime={'schema':1,'python':plan['python'],'runtime':plan['runtime']}
    if read_json(candidate/'runtime.json') != expected_runtime:
        raise ValueError('候选运行入口已变化，请重新准备')
    # Persist before personal-version or installation mutation; resumed runs
    # verify the original baseline rather than accepting their current state.
    ensure_history_baseline(plan,args.plan)
    if not plan.get('activation_confirmation'):
        plan['activation_confirmation']=confirmation
        if target.exists():
            backup=Path(plan['runtime'])/'backups'/identifier()/'chutu-chicun-tiaozheng-single'
            shutil.copytree(target,backup)
            plan['backup']=str(backup)
        else:
            plan['backup']=None
        plan['publish_path']=str(target.with_name(target.name+'.pending-'+identifier()))
        # Keep the atomic retirement on the target volume, outside the skill
        # discovery root so a backup cannot appear as a second active skill.
        plan['retired_path']=str(target.parent.parent/'chutu-resize-retired'/identifier()/target.name)
        write_json(args.plan,plan)
    store=Store(plan['profile'])
    status=store.status()
    if plan.get('kind')=='upgrade':
        proposal_id=plan.get('upgrade_proposal')
        if proposal_id:
            _,proposal=store.proposal(proposal_id)
        else:
            if status.get('revision') != plan['base_revision']:
                raise ValueError('个人基线版本已变化，请重新准备和审阅升级')
            changes={name:read_json(draft/'snapshot'/name) if name=='settings.json' else (draft/'snapshot'/name).read_text(encoding='utf-8')
                     for name in ('settings.json','personal_prompt.md','renderer.py')}
            proposal=store.propose(changes,'升级3.4；保留个人参数，主图与场景图分开选尺寸，同尺寸默认1—N编号，逐张预览确认，保留Python默认及放大人工选择，以已展示差异为准')
            proposal_id=proposal['id'];plan['upgrade_proposal']=proposal_id;write_json(args.plan,plan)
        if proposal['status']=='applied':
            revision=proposal['revision']
            if status['revision'] != revision or status['digest'] != args.digest:
                raise ValueError('升级后版本已变化，停止恢复')
        else:
            # Store.propose formats JSON; restore the exact already-reviewed bytes before validation.
            from user_profile import copy_snapshot
            proposal_directory,_=store.proposal(proposal_id)
            copy_snapshot(draft/'snapshot',proposal_directory/'candidate')
            report=store.validate(proposal_id,load_jobs(plan['spec']))
            if not report['passed']:
                raise ValueError('升级提案验证失败')
            revision=store.approve(proposal_id,args.digest,confirmation)['revision']
    elif not status['initialized']:
        revision=store.initialize(draft/'snapshot',confirmation,read_json(draft/'validation.json'))
    else:
        # Covers a crash between initialization and recording its checkpoint.
        revision=status['revision']
        metadata=read_json(Path(status['renderer']).parent/'version.json')
        if status['digest'] != args.digest or metadata.get('proposal_id') != 'initial-install' or metadata.get('confirmation') != confirmation:
            raise ValueError('已有配置不是本次已批准初始化，停止，不覆盖或自动回退')
    plan.update(revision=revision)
    if plan['status']=='prepared':
        plan['status']='profile-initialized';write_json(args.plan,plan)
    pending=Path(plan['publish_path']);retired=Path(plan['retired_path'])
    assert_history_unchanged(plan)
    # Recover a crash just after rename but before its plan checkpoint.
    published=target.is_dir() and payload(target)==plan['payload'] and read_json(target/'runtime.json')==expected_runtime
    if not published:
        if pending.parent.resolve() != target.parent.resolve() or pending.is_symlink():
            raise ValueError('发布暂存目录位置异常，停止')
        if pending.exists() and set(payload(pending))-set(plan['payload']):
            raise ValueError('发布暂存目录含未知文件，保留现场并停止')
        shutil.copytree(candidate,pending,dirs_exist_ok=True)
        if payload(pending) != plan['payload'] or read_json(pending/'runtime.json') != expected_runtime:
            raise ValueError('发布暂存目录不完整；保留现场，请诊断后重新建立暂存，不重复init')
        plan['status']='publishing';write_json(args.plan,plan)
        if target.exists():
            if retired.exists():
                raise ValueError('旧技能保留目录已存在，停止避免覆盖')
            retired.parent.mkdir(parents=True,exist_ok=True)
            target.rename(retired)
        pending.rename(target)
    plan['status']='published';write_json(args.plan,plan)
    preview=session/('installed-preview-'+identifier()+'.png')
    command=['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',target/'scripts/run_resize.ps1']
    if plan['isolated_test']:
        command+=['--state',plan['profile']]
    command+=['preview','--spec',plan['spec'],'--out',preview,'--limit','0']
    assert_history_unchanged(plan)
    try:
        run(command,session/'installed-preview.log')
    finally:
        assert_history_unchanged(plan)
    status=store.status()
    if status['digest'] != args.digest or status['revision'] != revision:
        raise ValueError('已安装个人版本与批准快照不一致')
    assert_history_unchanged(plan)
    receipt={'passed':True,'activated':True,'revision':revision,'digest':args.digest,'profile':plan['profile'],
             'skill':str(target),'python':str(Path(sys.executable).resolve()),'preview':str(preview),
             'workflow_report':plan['workflow_report'],'initial_validation':str(draft/'validation.json'),
             'confirmation':confirmation,'backup':plan['backup'],'retired_skill':plan['retired_path'],
             'isolated_test':plan['isolated_test']}
    receipt['business_history_unchanged']=True
    write_json(Path(plan['runtime'])/'installation.json',receipt)
    plan['status']='activated';write_json(args.plan,plan)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='mode',required=True)
    p=sub.add_parser('prepare');p.add_argument('--runtime',required=True);p.add_argument('--target',required=True);p.add_argument('--test-profile')
    p=sub.add_parser('refresh');p.add_argument('--plan',required=True)
    p=sub.add_parser('activate');p.add_argument('--plan',required=True);p.add_argument('--digest',required=True);p.add_argument('--confirmation-file',required=True)
    args=parser.parse_args()
    if args.mode=='prepare':prepare(args)
    elif args.mode=='refresh':
        plan=refresh(args.plan);print(json.dumps({'passed':True,'digest':plan['digest'],'draft':plan['draft']},ensure_ascii=False))
    else:activate(args)


if __name__=='__main__':
    main()
