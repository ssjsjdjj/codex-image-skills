﻿[CmdletBinding()]
param(
    [ValidateSet('Prepare','Refresh','Activate')][string]$Mode='Prepare',
    [string]$PythonExe='',
    [string]$RuntimeRoot='',
    [string]$SkillRoot='',
    [string]$PlanPath='',
    [string]$Digest='',
    [string]$ConfirmationFile='',
    [string]$TestProfileRoot='',
    [string]$IndexUrl='https://pypi.org/simple'
)
$ErrorActionPreference='Stop'
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:PYTHONDONTWRITEBYTECODE='1'
$BundleRoot=$PSScriptRoot
$Utf8=New-Object System.Text.UTF8Encoding($false)
if (-not [Environment]::Is64BitOperatingSystem) { throw '本包需要64位Windows和兼容的Python 3.12/3.13。' }
if (-not $env:LOCALAPPDATA) { throw '无法定位当前账号LOCALAPPDATA。' }
if (-not $RuntimeRoot) { $RuntimeRoot=Join-Path $env:LOCALAPPDATA 'ChutuResizeSingleRuntime' }
if (-not $SkillRoot) { $SkillRoot=Join-Path $HOME '.agents\skills\chutu-chicun-tiaozheng-single' }
$RuntimeRoot=[IO.Path]::GetFullPath($RuntimeRoot)
$SkillRoot=[IO.Path]::GetFullPath($SkillRoot)
function Step([string]$Text) { Write-Host $Text -ForegroundColor Cyan }
function Confirm-Payload {
    $ManifestFile = Join-Path $BundleRoot 'MANIFEST.json'
    if (-not (Test-Path -LiteralPath $ManifestFile)) { throw '迁移包缺少MANIFEST.json，请重新传入完整安装包。' }
    $Manifest = Get-Content -LiteralPath $ManifestFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($Property in $Manifest.files.PSObject.Properties) {
        $Candidate = [IO.Path]::GetFullPath((Join-Path $BundleRoot $Property.Name))
        $Boundary = [IO.Path]::GetFullPath($BundleRoot).TrimEnd('\') + '\'
        if (-not $Candidate.StartsWith($Boundary,[StringComparison]::OrdinalIgnoreCase)) { throw '文件清单路径越界。' }
        if (-not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { throw "迁移包缺少文件：$($Property.Name)" }
        $Hasher = [Security.Cryptography.SHA256]::Create()
        $FileStream = [IO.File]::OpenRead($Candidate)
        try { $Actual = [BitConverter]::ToString($Hasher.ComputeHash($FileStream)).Replace('-','').ToLowerInvariant() }
        finally { $FileStream.Dispose(); $Hasher.Dispose() }
        if ($Actual -ne $Property.Value) { throw "文件校验失败：$($Property.Name)" }
    }
}
function Test-Python([string]$Candidate) {
    if (-not $Candidate -or -not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { return $false }
    $Probe = "import sys,struct,venv,ensurepip,platform; assert sys.version_info[:2] in [(3,12),(3,13)]; assert struct.calcsize('P')==8; assert platform.machine().lower() in ('amd64','x86_64'); print(sys.executable)"
    $PreviousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $ProbeOutput = & $Candidate -c $Probe 2>&1
        return ($LASTEXITCODE -eq 0)
    }
    finally { $ErrorActionPreference = $PreviousPreference }
}
function Find-Python {
    $Candidates = @()
    if ($PythonExe) { $Candidates += $PythonExe }
    $Candidates += (Join-Path $HOME '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
    foreach ($Version in @('3.12','3.13')) {
        $Candidates += (Join-Path $env:LOCALAPPDATA ('Programs\Python\Python' + $Version.Replace('.','') + '\python.exe'))
        foreach ($Hive in @('HKCU:','HKLM:')) {
            $Key = "$Hive\Software\Python\PythonCore\$Version\InstallPath"
            if (Test-Path -LiteralPath $Key) {
                $Value = (Get-Item -LiteralPath $Key).GetValue('')
                if ($Value) { $Candidates += (Join-Path $Value 'python.exe') }
            }
        }
    }
    foreach ($CommandName in @('python.exe','python3.exe')) {
        $Command = Get-Command $CommandName -ErrorAction SilentlyContinue
        if ($Command -and $Command.Source -notmatch '\\WindowsApps\\') { $Candidates += $Command.Source }
    }
    foreach ($Candidate in ($Candidates | Select-Object -Unique)) {
        if (Test-Python $Candidate) { return [IO.Path]::GetFullPath($Candidate) }
    }
    return $null
}
function Run-Python([string]$Executable,[string[]]$Arguments) {
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Python命令失败，退出码${LASTEXITCODE}：$($Arguments -join ' ')" }
}

Confirm-Payload
$Helper=Join-Path $BundleRoot 'deployment.py'
if ($Mode -ne 'Prepare') {
    if (-not $PlanPath -or -not (Test-Path -LiteralPath $PlanPath)) { throw '需要Prepare返回的安装计划绝对路径。' }
    $Prepared=Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if (-not (Test-Python $Prepared.python)) { throw '计划中的专用Python不可用，请修复环境。' }
    if ($Mode -eq 'Refresh') {
        Run-Python $Prepared.python @($Helper,'refresh','--plan',$PlanPath)
    } else {
        if (-not $Digest -or -not $ConfirmationFile -or -not (Test-Path -LiteralPath $ConfirmationFile)) { throw 'Activate必须提供已审阅摘要和含用户真实批准原文的UTF-8文件。' }
        Run-Python $Prepared.python @($Helper,'activate','--plan',$PlanPath,'--digest',$Digest,'--confirmation-file',$ConfirmationFile)
    }
    exit 0
}
New-Item -ItemType Directory -Path $RuntimeRoot -Force | Out-Null
$LogDirectory=Join-Path $RuntimeRoot ('logs\dependencies-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
$TranscriptStarted=$false
try {
    Start-Transcript -LiteralPath (Join-Path $LogDirectory 'install.log') | Out-Null
    $TranscriptStarted=$true
    Step '1/4 定位兼容的64位Python，不依赖py和PATH刷新'
    $BasePython = Find-Python
    if (-not $BasePython) {
        if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) {
            throw '没有可用Python，也没有winget。请Codex从python.org安装当前兼容的64位Python 3.12/3.13，再用-PythonExe传入绝对路径续跑。'
        }
        & winget.exe install --id Python.Python.3.13 -e --scope user --silent --disable-interactivity --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -notin @(0,3010)) { throw "Python安装失败，winget退出码$LASTEXITCODE；请Codex诊断后从官方安装源补齐。" }
        $BasePython = Find-Python
        if (-not $BasePython) { throw 'Python安装后仍未找到可用解释器。请Codex定位实际python.exe并以-PythonExe续跑，不必让用户手动设置PATH。' }
    }
    Step '2/4 创建当前账号的独立环境并安装依赖'
    $EnvironmentDirectory = Join-Path $RuntimeRoot 'venv'
    $DedicatedPython = Join-Path $EnvironmentDirectory 'Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $DedicatedPython)) {
        Run-Python $BasePython @('-m','venv',$EnvironmentDirectory)
    }
    if (-not (Test-Python $DedicatedPython)) { throw '现有专用环境不兼容；保留现场，请Codex诊断，不自动删除。' }
    $env:PIP_CACHE_DIR = Join-Path $RuntimeRoot 'cache\pip'
    Run-Python $DedicatedPython @('-m','pip','install','--disable-pip-version-check','pip','--index-url',$IndexUrl,'--timeout','60','--retries','2')
    $RequirementFile = Join-Path $BundleRoot 'requirements-lock.txt'
    if (-not (Test-Path -LiteralPath $RequirementFile)) { $RequirementFile = Join-Path $BundleRoot 'requirements.txt' }
    Run-Python $DedicatedPython @('-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--index-url',$IndexUrl,'--timeout','60','--retries','2','-r',$RequirementFile)
    Run-Python $DedicatedPython @('-m','pip','check')
    Step '3/4 验证完整个人反馈流程并创建新账号初始草案'
    $PrepareArgs=@($Helper,'prepare','--runtime',$RuntimeRoot,'--target',$SkillRoot)
    if ($TestProfileRoot) { $PrepareArgs+=@('--test-profile',[IO.Path]::GetFullPath($TestProfileRoot)) }
    Run-Python $DedicatedPython $PrepareArgs
    Step '4/4 准备完成：展示初始规则、摘要和预览，用户批准后Activate'
    Write-Host '依赖和草案已准备，正式个人版本尚未初始化。不要把测试确认文字用作真实批准。' -ForegroundColor Green
}
catch {
    $Failure=@{passed=$false;error=$_.Exception.Message;log=$LogDirectory;at=(Get-Date).ToString('o')}
    [IO.File]::WriteAllText((Join-Path $LogDirectory 'failure.json'),($Failure | ConvertTo-Json),$Utf8)
    [Console]::Error.WriteLine($_.ToString())
    exit 1
}
finally { if ($TranscriptStarted) { Stop-Transcript | Out-Null } }
